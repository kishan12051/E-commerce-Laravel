<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\User;
use Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\URL;

class UpdateLastActivity
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    
    public function handle(Request $request, Closure $next)

    {
        // if (auth()->check()) {
        //     $user = User::find(auth()->user()->id);
        //     $user->last_activity_at = now();
        //     $user->save();
        // }
        
        // $idleThreshold = now()->subMinutes(1); 
        // $user = Auth::user();

        // if ($user && $user->last_activity_at < $idleThreshold) {
        //     // User is idle for longer than the threshold
        //     // auth()->logout(); // Log out the idle user forcefully    
            // Session::put('idle_url', $request->url());
        //     return redirect()->route('password.confirm')->withCookie(cookie('confirm_password', '1', 60));
        // }
        
        $url = url()->full();
        if (strpos($url, "/password/confirm") === false && strpos($url, "/fetch-audit-center") === false) {
            Session::put('idle_url', $url);
        }
        return $next($request);
    }
}