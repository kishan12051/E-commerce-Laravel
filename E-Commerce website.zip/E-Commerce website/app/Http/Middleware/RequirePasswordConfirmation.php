<?php

namespace App\Http\Middleware;

use Closure;
//use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;
use Auth;
use Illuminate\Support\Facades\Session;

class RequirePasswordConfirmation
{
    public function handle($request, Closure $next)
    {
      
        // Check if the user is authenticated
        if (Auth::check()) {
            // Check if the user has already confirmed their password in this session
            if (!session('password_confirmed')) {
                // Redirect to the "confirm password" page if not confirmed
                return Redirect::route('password.confirm');
            }
        }

        return $next($request);
    }
}
