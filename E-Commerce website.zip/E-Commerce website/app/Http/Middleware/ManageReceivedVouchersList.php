<?php

namespace App\Http\Middleware;

use Closure;

class ManageReceivedVouchersList
{
    public function handle($request, Closure $next)
    {
        return $next($request);
    }
}
