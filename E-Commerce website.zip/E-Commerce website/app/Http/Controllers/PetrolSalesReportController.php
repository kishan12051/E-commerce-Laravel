<?php
namespace App\Http\Controllers;

use App\Exports\PetrolSalesReportExport;
use App\Http\Controllers\Controller;
use App\Models\Employees;
use App\Models\ShiftReport;
use App\Models\User;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;
use Maatwebsite\Excel\Facades\Excel;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use App\Models\ShiftBottledOilFillingReadings;
use App\Models\Language;
use App\Models\TimeZone;
use DataTables;
use Carbon\Carbon;
use App\Exports\ExportShiftBottledOilFillingReadings;
use App\Models\PetrolPumps;
use App\Models\PetrolTypes;
use Spatie\SimpleExcel\SimpleExcelWriter;
use Illuminate\Support\Facades\Storage;
use Barryvdh\DomPDF\PDF;
use Dompdf\Dompdf;
use Dompdf\Options;
use TCPDF;

class PetrolSalesReportController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
    	$this->middleware('permission:shift-bottled-oil', ['only' => ['index','show']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(){

    }
    public function petrolSalesReport(Request $request)
    {
        if (auth()->user()->type == 1) {
            $adminId = auth()->user()->sub_emp_id == 0 ? auth()->user()->id : auth()->user()->sub_emp_id;
            $petrolPumpCon = [
                'users.type' => 3,
                'users.sub_emp_id' => 0,
                'users.id_parent_organisation' => $adminId,
                'users.status' => 'Y',
            ];

    		$petrolPumps = Employees::whereHas('user', function ($query) use ($petrolPumpCon) {
    			$query->where($petrolPumpCon);
    		})
    		->orderBy('organization_name', 'ASC')
    		->with('user')
    		->get()->pluck( 'organization_name', 'id');
    		return view('petrol-sales-report.index', compact('petrolPumps'));
    	} elseif (auth()->user()->type == 3) {
    		$adminId = auth()->user()->sub_emp_id == 0 ? auth()->user()->id : auth()->user()->sub_emp_id;
    		$condition = ['user_id' => $adminId];
    	} else {
    		return redirect()->route('dashboard.index')->with('error', 'You are not authorized to view this record.');
    	}

        $condition['status'] = ['A', 'C']; // Add 'R' if needed

        //if (request()->isMethod('post') || request()->isMethod('put')) {

        if (request()->filled('start_date_time')) {
            $condition['shift_date'] = ['>=', request()->input('start_date_time')];
        }
        if (request()->filled('end_date_time')) {
            $condition['shift_end_date_time'] = ['<=', request()->input('end_date_time')];
        }
        if (request()->filled('petrol_station_id')) {
            $condition['user_id'] = request()->input('petrol_station_id');
        }

        $start_date_PetrolPumpReports = ShiftReport::where($condition)
            ->orderBy('shift_date', 'ASC')
            ->orderBy('shift_start_date_time', 'ASC')
            ->first();


        $end_date_PetrolPumpReports = ShiftReport::where($condition)
            ->orderBy('shift_date', 'DESC')
            ->orderBy('shift_start_date_time', 'DESC')
            ->first();

        $find_petrol_station_details = Employees::where('user_id', $adminId)->first();


        if ($start_date_PetrolPumpReports && isset($start_date_PetrolPumpReports->id)) {
            $find_petrol_type_data = DB::table('petrol_pumps')
            ->select('petrol_pumps.petrol_type_id', 'petrol_types.petrol_type_en', 'petrol_types.petrol_type_ru', 'petrol_types.petrol_type_tu')
            ->join('petrol_types', 'petrol_pumps.petrol_type_id', '=', 'petrol_types.id')
            ->where('petrol_pumps.user_id', $adminId)
            ->orderBy('petrol_types.petrol_type_en', 'ASC')
            ->groupBy('petrol_pumps.petrol_type_id', 'petrol_types.petrol_type_en', 'petrol_types.petrol_type_ru', 'petrol_types.petrol_type_tu')
            ->limit(10000)
            ->get();
            // view()->share("find_petrol_type_data", $find_petrol_type_data);
        }

            $currentDate = date('Y-m-d');

            // $formattedBegin = $currentDate;
            // $formattedEnd = $currentDate;

            $formattedBegin = isset($request->start_date) ? $request->start_date : '';
            $formattedEnd = isset($request->end_date) ? $request->end_date :'';
            $startDateTime = $request->input('start_date');
            $endDateTime = $request->input('end_date');

            $begin = \Carbon\Carbon::parse($startDateTime);
            $end = \Carbon\Carbon::parse($endDateTime);

            $dateRange = [];
            while ($begin->lte($end)) {
            $dateRange[] = $begin->format("Y-m-d");
            $begin->addDay();
        }

        return view('petrol-sales-report.index', compact('start_date_PetrolPumpReports', 'end_date_PetrolPumpReports', 'find_petrol_station_details', 'find_petrol_type_data','formattedBegin','formattedEnd', 'dateRange'));
    }

    public function petrolSalesReportExcelExport(Request $request)
    {

    $formattedBegin = $request->formattedBegin;
    $formattedEnd   = $request->formattedEnd;
    $currentUrl   = $request->url;
    $dateRange   = $request->dateRange;
    $htmlContent =array();
    if ($request->isMethod('post')) {
        $htmlContent    = '<div class="table-responsive-lg" style="overflow-x: auto;">';
        if (isset($formattedBegin) && $formattedBegin && isset($formattedEnd) && $formattedEnd) {
            $htmlContent .= '<table class="table table-bordered" width="100%" cellspacing="0" style="border:1px solid #000">';
            $htmlContent .= '<tr style="border:1px solid #000">';
            $htmlContent .= '<td colspan="3" style="border:1px solid #000;text-align:center" colspan="100%">Petrol Station ID: ' . $request->find_petrol_station_details['organization_name'] . '</td>';
            $htmlContent .= '</tr>';
            $htmlContent .= '<tr style="border:1px solid #000;with:100%">';
            $htmlContent .= '<td style="border:1px solid #000;width:33.3%">Petrol Sales Monthly Report</td>';
            $htmlContent .= '<td style="border:1px solid #000;width:33.3%">From Date: ' . $formattedBegin . '</td>';
            $htmlContent .= '<td style="border:1px solid #000;width:33.3%">To Date: ' . $formattedEnd . '</td>';
            $htmlContent .= '</tr>';
            $htmlContent .= '</table>';

            $default_language = get_default_language();

            if ($default_language == 'ru') {
                $default_language_key = 1;
            } elseif ($default_language == 'tu') {
                $default_language_key = 2;
            } else {
                $default_language_key = 0;
            }

            $htmlContent .= '<table style="border:1px solid #000" class="table table-bordered" width="100%" cellspacing="0">';
            $htmlContent .= '<thead style="border:1px solid #000">';
            $htmlContent .= '<tr class="tdpetrolTypetitle">';
            $htmlContent .= '<td rowspan="2" style="text-align:center;vertical-align: middle;border:1px solid #000">Date</td>';

            foreach ($request['find_petrol_type_data'] as $pt_val) {
                $index_name = 'petrol_type_' . $default_language;
                $htmlContent .= '<td class="tdpetrolType1" colspan="2" style="text-align:center;border:1px solid #000">' . $pt_val[$index_name] . '</td>';
                $htmlContent .= '<td class="tdpetrolType" colspan="2" style="text-align:center;border:1px solid #000">' . $pt_val[$index_name] . '</td>';
            }

            $htmlContent .= '<td class="LitersTotalAll" rowspan="2" style="text-align:center;vertical-align: middle;border:1px solid #000">Total Cash</td>';
            $htmlContent .= '<td rowspan="2" style="text-align:center;vertical-align: middle;border:1px solid #000">Total Terminal</td>';

                if (preg_match('/version=v1/i', $currentUrl)) {
                    $htmlContent .= '<td rowspan="2" style="text-align:center;vertical-align: middle;">Bank Bag Number</td>';
                }

            $htmlContent .= '</tr>';
            $htmlContent .= '<tr class="sections">';

            foreach ($request['find_petrol_type_data'] as $pt_val) {
                $htmlContent .= '<td style="border:1px solid #000">Total Liters</td>';
                $htmlContent .= '<td style="border:1px solid #000">Total Cash</td>';
                $htmlContent .= '<td style="border:1px solid #000">Total Liters</td>';
                $htmlContent .= '<td style="border:1px solid #000">Total Bank</td>';
            }

            $htmlContent .= '</tr>';
            $htmlContent .= '</thead>';
            $htmlContent .= '<tbody style="border:1px solid #000">';

            $begin = $formattedBegin;
            $end = $formattedEnd;

            foreach ($dateRange as $date) {
                $htmlContent .= '<tr style="border:1px solid #000">';
                $htmlContent .= '<td style="border:1px solid #000">' . $date . '</td>';
                $total_liter = $total_amount = 0;
                $totalAmountLiterCAS = 0;
                $current_day = $date;

                foreach ($request['find_petrol_type_data'] as $pt_val) {
                $find_total_each_day_sale = find_total_each_day_sale($date, $request->find_petrol_station_details['user_id'], $pt_val['petrol_type_id'], 'Cash');
                $find_total_each_daySaleBnk = find_total_each_day_sale($date, $request->find_petrol_station_details['user_id'], $pt_val['petrol_type_id'], 'Bank');
                $find_petrol_bank_bag_number = find_each_bank_bag_number($date, $request->find_petrol_station_details['user_id']);
                $total_amount += $find_total_each_daySaleBnk['amount'];
                $totalAmountLiterCAS += $find_total_each_day_sale['amount'];

                $htmlContent .= '<td class="tbliter" style="text-align:right;border:1px solid #000">';
                $htmlContent .= $find_total_each_day_sale['liter'] == 0 ? '0' : $find_total_each_day_sale['liter'];
                $htmlContent .= '</td>';

                $htmlContent .= '<td class="tbliterCAS" style="text-align:right;border:1px solid #000">';
                $htmlContent .= $find_total_each_day_sale['amount'] == 0 ? '0' : $find_total_each_day_sale['amount'];
                $htmlContent .= '</td>';

                $htmlContent .= '<td class="tbBnkliter" style="text-align:right;border:1px solid #000">';
                $htmlContent .= $find_total_each_daySaleBnk['liter'] == 0 ? '0' : $find_total_each_daySaleBnk['liter'];
                $htmlContent .= '</td>';

                $htmlContent .= '<td class="tbBnkliterCAS" style="text-align:right;border:1px solid #000">';
                $htmlContent .= $find_total_each_daySaleBnk['amount'] == 0 ? '0' : $find_total_each_daySaleBnk['amount'];
                $htmlContent .= '</td>';
            }

            $htmlContent .= '<td style="text-align:right;border:1px solid #000">' . number_format($totalAmountLiterCAS, 2) . '</td>';
            $htmlContent .= '<td style="text-align:right;border:1px solid #000">' . number_format($total_amount, 2) . '</td>';

                    if (preg_match('/version=v1/i', $currentUrl)) {
                        $htmlContent .= '<td>' . $find_petrol_bank_bag_number . '</td>';
                    }

            $htmlContent .= '</tr>';
        }

                $htmlContent .= '<tr>';
                $htmlContent .= '<td style="border:1px solid #000">Total</td>';
                $all_total_liter = 0;
                $all_total_amount = 0;
                $allTotalAmountCAS = 0;

        foreach ($request['find_petrol_type_data'] as $pt_val) {
            $find_total_period_daySalebnk = find_total_period_day_sale($formattedBegin, $formattedEnd, $request->find_petrol_station_details['user_id'], $pt_val['petrol_type_id'], 'Bank');
            $find_total_period_day_sale = find_total_period_day_sale($formattedBegin, $formattedEnd, $request->find_petrol_station_details['user_id'], $pt_val['petrol_type_id'], 'Cash');
            $all_total_amount += $find_total_period_daySalebnk['amount'];
            $allTotalAmountCAS += $find_total_period_day_sale['amount'];

                    $htmlContent .= '<td style="text-align:right;border:1px solid #000" class="tbliter" style="text-align:right;">';
                    $htmlContent .= $find_total_period_day_sale['liter'] == 0 ? '0' : $find_total_period_day_sale['liter'];
                    $htmlContent .= '</td>';

                    $htmlContent .= '<td style="text-align:right;border:1px solid #000" class="tbliterCAS" style="text-align:right;">';
                    $htmlContent .= $find_total_period_day_sale['amount'] == 0 ? '0' : $find_total_period_day_sale['amount'];
                    $htmlContent .= '</td>';

                    $htmlContent .= '<td style="text-align:right;border:1px solid #000" class="tbBnkliter" style="text-align:right;">';
                    $htmlContent .= $find_total_period_daySalebnk['liter'] == 0 ? '0' : $find_total_period_daySalebnk['liter'];
                    $htmlContent .= '</td>';

                    $htmlContent .= '<td style="text-align:right;border:1px solid #000" class="tbBnkliterCAS" style="text-align:right;">';
                    $htmlContent .= $find_total_period_daySalebnk['amount'] == 0 ? '0' : $find_total_period_daySalebnk['amount'];
                    $htmlContent .= '</td>';
                }

                $htmlContent .= '<td style="text-align:right;border:1px solid #000" style="text-align:right;">' . number_format($allTotalAmountCAS, 2) . '</td>';
                $htmlContent .= '<td style="text-align:right;border:1px solid #000" style="text-align:right;">' . number_format($all_total_amount, 2) . '</td>';
                $htmlContent .= '</tr>';
                $htmlContent .= '</tbody>';
                $htmlContent .= '</table>';
            } elseif ($formattedBegin == '' && $formattedEnd == '') {
                $htmlContent .= '<table class="table table-bordered text-danger text-center ttttttt" width="100%" cellspacing="0">';
                $htmlContent .= '<tr>';
                $htmlContent .= '<td colspan="100%">No record found</td>';
                $htmlContent .= '</tr>';
                $htmlContent .= '</table>';
            }

    $htmlContent .= '</div>';
    // $file_name = "Petrol_Sales_Report_" . str_replace(" ", "_",  $request->find_petrol_station_details['organization_name']). "_" . $formattedBegin . "_" . $formattedEnd . ".xlsx";
    $file_name = "pf.xlsx";

    $pdf_file_name = "Petrol_Sales_Report_" . str_replace(" ", "_",  $request->find_petrol_station_details['organization_name']). "_" . $formattedBegin . "_" . $formattedEnd . ".pdf";
    if ($request->exportTo == "Excel") {
        // $export = new PetrolSalesReportExport($htmlContent);
        // return Excel::store($export, $file_name);
    } else {
        $pdf = new TCPDF();

        // Set document information
        // $pdf->SetCreator('Your Name');
        // $pdf->SetAuthor('Your Name');
        $pdf->SetTitle($pdf_file_name);
    	// $pdf->SetSubject('Your PDF Subject');

        // Set default header and footer fonts
        $pdf->setHeaderFont(Array('helvetica', '', 12));
        $pdf->setFooterFont(Array('helvetica', '', 12));

        // Set margins
        $pdf->SetMargins(10, 10, 10);
        $pdf->SetHeaderMargin(5);
        $pdf->SetFooterMargin(5);

        // Set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // Add a page
        // $pdf->SetPageOrientation('L');
        $width = $pdf->pixelsToUnits(1211);
        $height = $pdf->pixelsToUnits(1211);

        $resolution= array($width, $height);
        $pdf->AddPage('L', $resolution);
        // $pdf->AddPage();
        $pdf->SetLineWidth(0.1); // Set the border line width (adjust as needed)
        $pdf->SetDrawColor(0);

        // Your HTML content goes here
        //$htmlContent = '<h1>Hello, World!</h1>';
        $pdf->writeHTML($htmlContent, true, false, true, false, '');

        // Output the PDF as a download or save it to a file
        // $filePath = public_path('pdfs/' . $pdf_file_name);
        $directory = public_path('pdfs');
        $filePath = $directory . '/' . $pdf_file_name;

        if (!File::exists($directory)) {
            File::makeDirectory($directory, 0777, true, true); // Create the directory if it doesn't exist
        }
        $pdf->Output($filePath, 'F'); // 'F' saves the PDF to a file

        // Define the base URL for the PDF file
        $baseUrl = url('/public/pdfs/' . $pdf_file_name);

        // Return the base URL
        return $baseUrl;

    }
  }
 }
}
