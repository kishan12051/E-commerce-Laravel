<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;
use DB;
use File;
use App\Http\Controllers\Controller;
use App\Models\Language;
use Spatie\Permission\Models\Permission;
use App\Models\User;
use Illuminate\Support\Facades\Response;
/* use Spatie\Permission\Models\Language; */



class  LanguageController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:lang-list', ['only' => ['index','show']]);
        $this->middleware('permission:lang-create', ['only' => ['create','store']]);
        $this->middleware('permission:lang-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:lang-delete', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function index(Request $request)
    {
        $page_title = "Lists Of Languages";
        $languages = Language::orderBy('id', 'DESC')->get();
        return view('languages.index', compact('languages', 'page_title'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $statusArray = [
            'Y' => 'Active',
            'N' => 'Inactive',
        ];
        $isDefaultArray = [
            'N' => 'No',
            'Y' => 'Yes',
        ];
        return view('languages.create',compact('statusArray','isDefaultArray'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'name' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingLanguage = Language::where('name', $value)->first();
                    if ($existingLanguage) {
                        $fail('Language already exists');
                    }
                },
            ],
            'short_code' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingLanguage = Language::where('short_code', $value)->first();
                    if ($existingLanguage) {
                        $fail('Short Code for Language already exists');
                    }
                },
            ],

            'serial_no' => 'required',
            'status'=>'required',
            'is_default' => 'required',
        ], [
            'name.required' =>  $errormsg,
            'short_code.required' =>  $errormsg,
            'serial_no.required' =>  $errormsg,
            'status.required' =>  $errormsg,
            'is_default.required' =>  $errormsg,

        ]);

        try {
            $Language = new Language();
            $Language->name = $request->name;
            $Language->short_code = $request->short_code;
            $Language->serial_no = $request->serial_no;
            $Language->status = $request->status;
            $Language->is_default = $request->is_default;
            $Language->created_at = now();
            if ($Language->save()) {
                if ($request->input('is_default') === 'Y') {
                    Language::where('id', '<>', $Language->id)->update(['is_default' => 'N']);
                }
                return redirect()->route('languages.index')->with('message', 'The record has been saved successfully');
            }
            return redirect()->route('languages.index')->with('message', 'The record has been saved successfully');

        } catch (\Exception $e) {
            return redirect()->route('languages.index')->with('error', 'An error occurred while creating the language.');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $statusArray = [
            'Y' => 'Active',
            'N' => 'Inactive',
        ];
        $isDefaultArray = [
            'Y' => 'Yes',
            'N' => 'No',
        ];
        if(isset($id)){
            $record = Language::findOrFail($id);
            $data = $record->toArray();
            return view('languages.edit',compact('record','statusArray','isDefaultArray') );
        }else{
            $data = "No data Found";
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'name' => 'required|unique:languages,name,'.$id,
            'short_code' => 'required|unique:languages,short_code,'.$id,
            'serial_no' => 'required',
            'status'=>'required',
            'is_default' => 'required',
        ], [
            'name.required' =>  $errormsg,
            'short_code.required' =>  $errormsg,
            'serial_no.required' =>  $errormsg,
            'status.required' =>  $errormsg,
            'is_default.required' =>  $errormsg,
            'name.unique' => 'Language already exists',
            'short_code.unique' => 'Short Code for Language already exists',

        ]);

        $Language = Language::findOrFail($id);
        $Language->name = $request->name;
        $Language->short_code = $request->short_code;
        $Language->serial_no = $request->serial_no;
        $Language->status = $request->status;
        $Language->is_default = $request->is_default;
        $Language->created_at = now();
        if ($Language->save()) {
            if ($request->input('is_default') === 'Y') {
                Language::where('id', '<>', $Language->id)->update(['is_default' => 'N']);
            }
            return redirect()->route('languages.index')->with('message', 'The record has been saved successfully');
        }

        return redirect()->route('languages.index')->with('message','The record has been updated successfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = Language::find($request->status);
            if ($record) {
                $record->delete();
                $allData = Language::select('id', 'name', 'short_code', 'serial_no', 'status', 'is_default')->orderBy('id', 'DESC')->get();
                // dd($allData);
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('languages.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="languages" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $status = '<button class="btn btn-' . ($allDataRow->status == 'Y' ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="languages" data-id="' . $allDataRow->id . '">' . ($allDataRow->status == 'Y' ? 'Activate' : 'Deactivate') . '</button>';

                    $default = '<style>.btn.cursor-default {cursor: default !important;}.content-header{padding: 7px 0.5rem;}</style>
                               <p class="btn btn-' . ($allDataRow->is_default == 'Y' ? 'success' : 'danger') . ' cursor-default ">' . ($allDataRow->is_default == 'Y' ? 'Yes' : 'No') . '</p>';

                    $allDataRow->status = $status;
                    $allDataRow->is_default = $default;
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData, 'message' => 'The record has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Language not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function change(Request $request)
    {
        App::setLocale($request->lang);
        session()->put('locale', $request->lang);

        if ($request->isMethod('GET')) {
            $user = User::find(auth()->user()->id);
            if ($user) {
                $user->default_language = $request->lang;
                if ($user->save()) {
                    return redirect()->back()->with('success', 'Record updated successfully.');
                } else {
                    return redirect()->back()->with('error', 'We are having some problem. Please try later.');
                }
            } else {
                return redirect()->back()->with('error', 'Invalid user id.');
            }
        } else {
            return redirect()->route('dashboard.index')->with('error', 'Invalid request.');
        }

        return redirect()->back();
    }

    public function changeLanguageStatus(Request $request)
    {
        $languageId = $request->id;
        $language = Language::find($languageId);
        if (!$language) {
            return response()->json(['message' => 'Language not found'], 404);
        }
        /* Toggle the Language's status */
        $language->status = ($language->status === 'Y') ? 'N' : 'Y';
        $newStatus = $language->status === 'Y' ? 'Active' : 'Deactivate';
        if ($language->save()) {
            return response()->json(['success' => true, 'newStatus' => $newStatus, 'message' => 'Status has been updated successfully']);
        } else {
            return response()->json(['success' => false, 'newStatus' => $newStatus, 'message' => 'Something Wents wrong']);
        }
    }

}
