<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\ShiftBottledOilFillingReadings;
use App\Models\Employees;
use App\Models\Language;
use App\Models\TimeZone;
use Illuminate\Http\Request;
use DataTables;
use DB;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportShiftBottledOilFillingReadings;

class BottledOilDeliveryReportController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:shift-bottled-oil', ['only' => ['index','show']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {   
        $response['draw'] = $request->draw;
        $offset = $request->start;
        $length             = $request->length;
        $order = $request->order;
        if (request()->ajax()) {
            $query = DB::table('shift_bottled_oil_filling_readings')
            ->join('shift_report', 'shift_report.id', '=', 'shift_bottled_oil_filling_readings.shift_report_id')
            ->join('bottled_oil_types', 'bottled_oil_types.id', '=', 'shift_bottled_oil_filling_readings.bottled_oil_type_id');

            if (!empty($request->distributecenter)) {
                $query->where('shift_bottled_oil_filling_readings.rdc_user_id', $request->distributecenter);
            } elseif (!empty($request->from_date)) {
                $from_date = Carbon::createFromFormat('d/m/Y', $request->from_date)->format('Y-m-d');
                $to_date = Carbon::createFromFormat('d/m/Y', $request->to_date)->format('Y-m-d');
                $query->whereBetween('shift_bottled_oil_filling_readings.created_at', [$from_date, $to_date]);
            }
            $count = $query->count();
            $filteredCount = $count; // This may need to be adjusted if you want to apply additional filtering.

         // Get the data for the current page
         $data = $query->skip($offset)->take($length)->get();

    // Format the response in the structure expected by DataTables
    $formattedData = [
        'draw' => $request->draw,
        'recordsTotal' => $count,
        'recordsFiltered' => $filteredCount,
        'data' => $data->toArray(), // Convert the data collection to an array
    ];
    return response()->json($formattedData);
}

$emp_con = ['users.type' => 4];
$distribute_center = Employees::whereHas('user', function ($query) use ($emp_con) {
    $query->where($emp_con);
})
->with(['user'])
->orderBy('id', 'ASC')->pluck('organization_name','user_id');   

return view('shift-bottled-oil.index', compact('distribute_center'));
}

    public function exportCSVFile() 
    {
        return Excel::download(new ExportShiftBottledOilFillingReadings, 'shift_bottled_oil_filling_readings.xlsx');
    }    

}

