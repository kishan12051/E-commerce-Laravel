<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\GeneralSettings;
use Session;


class LoginAuthController extends Controller
{
    public function index()
    {
        $generalsettings= GeneralSettings::first();
        if(Auth::check()){
            return view('welcome');
        }else{
            return view('auth.login',compact('generalsettings'));
        }
    }

    public function customLogin(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        $credentials = $request->only('username', 'password');

        if (Auth::attempt($credentials)) {
            // session(['last_activity' => now()->timestamp]);
            Session::put('password_confirmed', true);
            // Session::put('last_activity' . auth()->user()->id, now());
            // return redirect()->intended('dashboard')
            // ->withSuccess('Signed in');
              return view('welcome')
            ->with('message','Signed in');
        }
   // return redirect("dashboard")->withSuccess('You have signed-in');
        return redirect("/")->with('error','Login data is in-correct');

    }
    public function dashboard()
    {

        if(Auth::check()){
            return view('dashboard');
        }

        return redirect("/")->withSuccess('You are not allowed to access');
    }
    public function logOut() {

        Session::flush();
        Auth::logout();

        return Redirect('/');
    }

}
