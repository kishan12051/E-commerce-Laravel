<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Employees;
use App\Models\User;
use DB;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Response;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $users = User::orderBy('id','DESC')->get();
        $page_title = "Users Management";
        return view('users.index',compact('users','page_title'))->with('i');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $roles = Role::pluck('name','name')->all();
        return view('users.create',compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messages = [
            'profile_picture.required'  => 'The Organization Logo is required',
            'profile_picture'  => 'The Organization Logo has invalid image dimensions use 120 X 120',
            'username' => 'The username field is required',
            'username.unique' => 'This username is already taken.',
            /* 'email.required' => 'The email field is required.',
            'email.email' => 'Please enter a valid email address.',
            'email.unique' => 'This email is already taken.', */
            'name.required' => 'The name field is required.',
            'name.alpha' => 'Please enter Valid name.',
            'phone_number.required' => 'The Phone Number field is required.',
            'phone_number.integer' => 'Please enter Valid Number',
            'date_of_birth' => 'The Date of birth field is required',
            'joining_date' => 'The Date of joining field is required',
            'password.required' => 'The password field is required.',
            'password.same' => 'The password and confirm password must be same.',
            'roles.required' => 'Please select at least one role.',
            'organization_name.required' => 'The organization name field field is required.',
            'organization_address.required' => 'The organization address field is required.',
            'organization_phone.required' => 'The organization phone field is required',
            'organization_phone.integer' => 'Please Enter Valid Phone Number'
        ];

        $this->validate($request, [
            'profile_picture' => 'required|dimensions:height=120',
            'username' => 'required|unique:users,username',
            'name' => 'required|alpha',
            'phone_number' => 'required|integer',
            'date_of_birth' => 'required',
            'joining_date' => 'required',
            /* 'email' => 'required|email|unique:users,email', */
            'password' => 'required|same:confirm-password',
            'roles' => 'required',
            'organization_name'=>'required',
            'organization_phone' => 'required|integer',
            'organization_address'=>'required'
        ], $messages);

        $input = $request->all();
        $input['password'] = Hash::make($input['password']);
        $employee = new Employees();
        $employee->fill($request->all());
        $user = User::create($input);
        $user->type = Auth()->user()->type;
        $user->sub_emp_id = Auth()->user()->id;
        $user->assignRole($request->input('roles'));
        if ($request->hasFile('profile_picture') && $request->file('profile_picture')->isValid()) {
            $extension = $request->file('profile_picture')->getClientOriginalExtension();
            $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
            $profile_picture = 'profile_picture_' . time() . "." . $extension;
            if (in_array($extension, $file_extension)) {
                $flag1 = true;
                $employee->profile_picture = $profile_picture;
            } else {
                $flag1 = false;
            }
        }
        if ($user->save()) {
            $lastUserId = User::latest('id')->first()->id;
            $employee->emp_id = "EMP-".rand("999999", '111111');
            $employee->user_id = $lastUserId;
            if ($employee->save()) {
                if ($request->hasFile('profile_picture') && $flag1 == true) {
                    $request->file('profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                }
                return redirect()->route('users.index')->with('message','User created successfully');
            } else {
                return redirect()->back()->with('message', 'User not created.');
            }
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);
        return view('users.show',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find($id);
        $employee = Employees::where('user_id', $user->id)->first();
        $roles = Role::pluck('name','name')->all();
        $userRole = $user->roles->pluck('name','name')->all();

        return view('users.edit',compact('user','roles','userRole','employee'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messages = [
            'username' => 'The username field is required',
            'username.unique' => 'This username is already taken.',
            'profile_picture.required' => 'The organization logo is required',
            'profile_picture'  => 'The Organization Logo has invalid image dimensions use 120 X 120',
            /* 'email.required' => 'The email field is required.',
            'email.email' => 'Please enter a valid email address.',
            'email.unique' => 'This email is already taken.', */
            'name.required' => 'The name field is required.',
            'name.alpha' => 'Please enter Valid name.',
            'phone_number.integer' => 'Please enter Valid Number',
            'date_of_birth' => 'The Date of birth field is required',
            'joining_date' => 'The Date of joining field is required',
            'password.required' => 'The password field is required.',
            'password.same' => 'The password and confirm password must be same.',
            'roles.required' => 'Please select at least one role.',
            'organization_name.required' => 'The organization name field field is required.',
            'organization_address.required' => 'The organization address field is required.',
            'organization_phone.required' => 'The organization phone field is required',
            'organization_phone.integer' => 'Please Enter Valid Phone Number'
        ];

        $this->validate($request, [
            'profile_picture' => 'required|dimensions:height=120',
            'username' => 'required|unique:users,username,'.$id,
            'name' => 'required|alpha',
            'phone_number' => 'required|integer',
            'date_of_birth' => 'required',
            'joining_date' => 'required',
            /* 'email' => 'required|email|unique:users,email,'.$id, */
            'password' => 'same:confirm-password',
            'roles' => 'required',
            'organization_name'=>'required',
            'organization_phone' => 'required|integer',
            'organization_address'=>'required'
        ], $messages);

        $input = $request->all();
        if(!empty($input['password'])){
            $input['password'] = Hash::make($input['password']);
        }else{
            $input = Arr::except($input,array('password'));
        }

        $user = User::find($id);
        $employee = Employees::where('user_id', $user->id)->first();
        $employee->fill($request->all());
        if($user->update($input)){
            DB::table('model_has_roles')->where('model_id',$id)->delete();
            $user->assignRole($request->input('roles'));
            if ($employee->save()) {
                if ($request->hasFile('profile_picture') && $request->file('profile_picture')->isValid()) {
                        $extension = $request->file('profile_picture')->getClientOriginalExtension();
                        $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
                        $profile_picture = 'profile_picture_' . time() . "." . $extension;
                        $move_location_profile_picture = storage_path('app/public/') . config('app.upload_folder') . '/' . config('app.organization_logo_folder') . '/' . $profile_picture;
                        if (in_array($extension, $file_extension)) {
                            $flag1 = true;
                            $employee->profile_picture = $profile_picture;
                        } else {
                            $flag1 = false;
                            // Flash message for invalid image format
                        }
                        // dd($request->all());
                        $request->file('profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                }
                return redirect()->route('users.index')->with('message','User updated successfully');
            }

        }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if (isset($request->status)) {
            $record = User::find($request->status);
            if ($record) {
                $record->delete();
                $allData = User::select('id', 'username')->orderBy('id', 'DESC')->get();
                foreach ($allData as $allDataRow) {
                    if (!empty($allDataRow->getRoleNames())) {
                        $rolenames = '';
                        foreach ($allDataRow->getRoleNames() as $v) {
                            $rolenames .= '<label class="badge badge-success">' . $v . '</label>';
                        }
                        $allDataRow->rolename = $rolenames;
                    }
                    $html = '<a class="btn btn-primary btn-circle btn-sm" title="Show" href="' . route('users.show', $allDataRow->id) . '"><i class="fas fa-eye"></i></a>
                             <a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('users.edit', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                             <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="users" data-id="' . $allDataRow->id . '" data-url="' . route('users.destroy', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                }
                $page_title = "Users Management";
                return response()->json(['data' => $allData, 'message' => 'User deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'User not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
