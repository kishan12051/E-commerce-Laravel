<?php
    
namespace App\Http\Controllers;
    
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\ShiftReport;
use App\Models\ShiftTankReadings;
use App\Models\ShiftPetrolSales;
use App\Models\PetrolTypes;
use DB;
class DashboardController extends Controller
{ 
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (request()->ajax()) {
            if(Auth::check()){
                if (auth()->user()->type == 3) {
                    $present_shiftReport = '';
                    $present_shiftpetrolsales_cash = '';
                    $present_shiftpetrolsales_vouchar = '';
                    $previous_shiftReport = '';
                    $previous_shiftpetrolsales_cash = '';
                    $previous_shiftpetrolsales_vouchar = '';

                    $actual_reading_total = $end_actual_reading_total = $after_receive_total = $newly_added_total = $filling_volumn_count = $remaining_petrol = $total_sold = 0;
                    $sl=0;
                    $present_shift_arr=[];
                    $previous_shift_arr=[];
                    $default_language = get_default_language();

                    if ($default_language == 'ru') {
                        $default_language_key = 1;
                    } elseif ($default_language == 'tu') {
                        $default_language_key = 2;
                    } else {
                        $default_language_key = 0;
                    }

                    if (auth()->user()->sub_emp_id == 0) {
                        $admin_id = auth()->user()->id;
                    } else {
                        $admin_id = auth()->user()->sub_emp_id;
                    }
                    $admin_id_arr = [$admin_id];

                    $present_shiftReport = ShiftReport::with('ShiftTankReadings')
                                            ->where('shift_report.status', 'C')
                                            ->limit(1)
                                            ->orderBy('shift_report.status', 'DESC')
                                            ->select(['id', 'user_id', 'employee_id', 'shift_timeid', 'shift_start_at_midnight', 'shift_end_at_midnight', 'shift_name', 'shift_name_en', 'shift_name_ru', 'shift_name_tu', 'shift_date', 'shift_start_date_time', 'shift_end_date_time', 'status'])
                                            ->first();
                     
                    if(!empty($present_shiftReport))
                    {
                        $present_shiftpetrolsales_cash = ShiftPetrolSales::where('shift_petrol_sales.shift_report_id', $present_shiftReport->id)
                                                        ->where('shift_petrol_sales.payment_method', '!=','')
                                                        ->groupBy('shift_petrol_sales.payment_method')
                                                        ->select(DB::raw('SUM(shift_petrol_sales.total_sold) as total,shift_petrol_sales.payment_method'))
                                                        ->get()->toArray();

                        $present_shiftpetrolsales_vouchar = ShiftPetrolSales::where('shift_petrol_sales.shift_report_id', $present_shiftReport->id)
                                                        ->where('shift_petrol_sales.voucher_type', '!=','')
                                                        ->groupBy('shift_petrol_sales.voucher_type')
                                                        ->select(DB::raw('SUM(shift_petrol_sales.total_sold) as total,shift_petrol_sales.voucher_type'))
                                                        ->get()->toArray();

                       
                        if(isset($present_shiftReport->ShiftTankReadings) && $present_shiftReport->ShiftTankReadings)
                        {
                            foreach($present_shiftReport->ShiftTankReadings as $shift_tank_readings)
                            {
                                $sl++;
                                $reservoir_name_arr = explode("#@@#", $shift_tank_readings->reservoir_name);
                                $petrol_type_name = explode("#@@#", $shift_tank_readings->petrol_type_name);
                                $filling_volumn_val = $filling_volumn_count = $remaining_petrol_each = 0;
                                $present_fuel = $shift_tank_readings->start_shift_fuel;
                                if($shift_tank_readings->filling_volumn != "" && $shift_tank_readings->filling_volumn != "[]")
                                {
                                    $fuel_data_array = json_decode($shift_tank_readings->filling_volumn);

                                    $added_str = "";
                                    foreach($fuel_data_array as $f_key => $f_val)
                                    {
                                        if($f_key > 0)
                                            $added_str = $added_str." + ";
                                        $added_str = $added_str.$f_val;
                                        $filling_volumn_count = $filling_volumn_count + $f_val;
                                    }
                                    $filling_volumn_val = $added_str;
                                    $present_fuel = $shift_tank_readings->present_fuel;
                                }
                                $actual_reading_total = $actual_reading_total + $shift_tank_readings->start_shift_fuel;
                                $end_actual_reading_total = $end_actual_reading_total + $shift_tank_readings->end_shift_fuel;
                                $after_receive_total = $after_receive_total + $present_fuel;
                                $newly_added_total += $filling_volumn_count;
                                $find_sales_data = find_pump_total_sold_data($shift_tank_readings->shift_report_id, $shift_tank_readings->petrol_typeid);
                                $total_sold += $find_sales_data->total_sum;
                                $remaining_petrol_each = $present_fuel - $find_sales_data->total_sum;
                                $remaining_petrol = $remaining_petrol + $remaining_petrol_each;
                                $find_reservoir_data = find_reservoir_data($shift_tank_readings->reservoir_id);
                                //dd($find_reservoir_data);
                                $newdata=['Tank Name'=>$petrol_type_name[$default_language_key], 'Remaining Petrol'=>$remaining_petrol_each, 'Capacity Petrol'=>$find_reservoir_data->capacity_liter];
                                array_push($present_shift_arr,$newdata);
                            }
                        }


                        $previous_shiftReport = ShiftReport::with('ShiftTankReadings')
                                            ->where('shift_report.status', 'C')
                                            ->where('shift_report.id', $present_shiftReport->last_report_id)  //35 //$present_shiftReport->last_report_id
                                            ->select(['id', 'user_id', 'employee_id', 'shift_timeid', 'shift_start_at_midnight', 'shift_end_at_midnight', 'shift_name', 'shift_name_en', 'shift_name_ru', 'shift_name_tu', 'shift_date', 'shift_start_date_time', 'shift_end_date_time', 'status'])
                                            ->first();

                        if(!empty($previous_shiftReport))
                        {
                            
                            $previous_shiftpetrolsales_cash = ShiftPetrolSales::where('shift_petrol_sales.shift_report_id', $previous_shiftReport->id)
                                                        ->where('shift_petrol_sales.payment_method', '!=','')
                                                        ->groupBy('shift_petrol_sales.payment_method')
                                                        ->select(DB::raw('SUM(shift_petrol_sales.total_sold) as total,shift_petrol_sales.payment_method'))
                                                        ->get()->toArray();

                            $previous_shiftpetrolsales_vouchar = ShiftPetrolSales::where('shift_petrol_sales.shift_report_id', $previous_shiftReport->id)
                                                        ->where('shift_petrol_sales.voucher_type', '!=','')
                                                        ->groupBy('shift_petrol_sales.voucher_type')
                                                        ->select(DB::raw('SUM(shift_petrol_sales.total_sold) as total,shift_petrol_sales.voucher_type'))
                                                        ->get()->toArray();
                            
                            if(isset($previous_shiftReport->ShiftTankReadings) && $previous_shiftReport->ShiftTankReadings)
                            {
                                foreach($previous_shiftReport->ShiftTankReadings as $shift_tank_readings)
                                {
                                    $sl++;
                                    $reservoir_name_arr = explode("#@@#", $shift_tank_readings->reservoir_name);
                                    $petrol_type_name = explode("#@@#", $shift_tank_readings->petrol_type_name);
                                    $filling_volumn_val = $filling_volumn_count = $remaining_petrol_each = 0;
                                    $present_fuel = $shift_tank_readings->start_shift_fuel;
                                    if($shift_tank_readings->filling_volumn != "" && $shift_tank_readings->filling_volumn != "[]")
                                    {
                                        $fuel_data_array = json_decode($shift_tank_readings->filling_volumn);

                                        $added_str = "";
                                        foreach($fuel_data_array as $f_key => $f_val)
                                        {
                                            if($f_key > 0)
                                                $added_str = $added_str." + ";
                                            $added_str = $added_str.$f_val;
                                            $filling_volumn_count = $filling_volumn_count + $f_val;
                                        }
                                        $filling_volumn_val = $added_str;
                                        $present_fuel = $shift_tank_readings->present_fuel;
                                    }
                                    $actual_reading_total = $actual_reading_total + $shift_tank_readings->start_shift_fuel;
                                    $end_actual_reading_total = $end_actual_reading_total + $shift_tank_readings->end_shift_fuel;
                                    $after_receive_total = $after_receive_total + $present_fuel;
                                    $newly_added_total += $filling_volumn_count;
                                    $find_sales_data = find_pump_total_sold_data($shift_tank_readings->shift_report_id, $shift_tank_readings->petrol_typeid);
                                    
                                    $total_sold += $find_sales_data->total_sum;
                                    $remaining_petrol_each = $present_fuel - $find_sales_data->total_sum;
                                    $remaining_petrol = $remaining_petrol + $remaining_petrol_each;
                                    $find_reservoir_data = find_reservoir_data($shift_tank_readings->reservoir_id);
                                    $newdata1=['Tank Name'=>$petrol_type_name[$default_language_key], 'Remaining Petrol'=>$remaining_petrol_each, 'Capacity Petrol'=>$find_reservoir_data->capacity_liter];
                                    array_push($previous_shift_arr,$newdata1);
                                }
                            }
                        }
                    }

                    //All Total Sales
                    $find_petrol_types = PetrolTypes::where('status', '!=','N')->select(['id', 'petrol_type_en', 'petrol_type_ru', 'petrol_type_tu','status'])->get()->toArray();

                    $returnHTML = view('ajax.dashboard',['present_shiftReport'=> $present_shiftReport, 'present_shiftpetrolsales_cash'=> $present_shiftpetrolsales_cash, 'present_shiftpetrolsales_vouchar'=> $present_shiftpetrolsales_vouchar, 'previous_shiftReport'=> $previous_shiftReport, 'previous_shiftpetrolsales_cash'=> $previous_shiftpetrolsales_cash, 'previous_shiftpetrolsales_vouchar'=> $previous_shiftpetrolsales_vouchar, 'find_petrol_types'=> $find_petrol_types, 'present_shift_arr'=> $present_shift_arr, 'previous_shift_arr'=> $previous_shift_arr])->render();

                     return response()->json( array('success' => true, 'html'=>$returnHTML) );

                }
            }
        }
        else{
            return view('dashboard');
        }
    }
    
}