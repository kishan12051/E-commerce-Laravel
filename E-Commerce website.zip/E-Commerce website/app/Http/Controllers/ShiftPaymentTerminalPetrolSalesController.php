<?php

namespace App\Http\Controllers;

use App\Models\Employees;
use App\Models\User;
use App\Models\Reservoirs;
use App\Models\PetrolTypes;
use App\Models\PaymentTerminals;
use App\Models\ShiftPaymentTerminalPetrolSale;
use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;

class ShiftPaymentTerminalPetrolSalesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
        $this->middleware('permission:payment-terminal-report-list', ['only' => ['index', 'show']]);

    }

    public function index()
    {

        $admin_id_arr = [0];

        if (auth()->user()->type == 3) {
            if (auth()->user()->sub_emp_id == 0) {
                $admin_id = auth()->user()->id;
            } else {
                $admin_id = auth()->user()->sub_emp_id;
            }
            $admin_id_arr = [$admin_id];

            $reservoirs = Reservoirs::where('status', 1)
                ->whereIn('user_id', $admin_id_arr)
                ->selectRaw('GROUP_CONCAT(DISTINCT(petrol_type_id)) as petrol_type_ids')
                ->first();

            $petrol_type_con['status'] = "Y";


            if (!empty($reservoirs->petrol_type_ids)) {
                $petrol_type_con['id'] = explode(",", $reservoirs->petrol_type_ids);

            } else {
                $petrol_type_con['id'] = [0];
            }

            $find_petrol_type = PetrolTypes::whereIn('id', $petrol_type_con['id'])
                ->where('status', $petrol_type_con['status'])
                ->pluck('petrol_type_en', 'id')
                ->toArray();

            // Retrieve payment terminal details
            $payment_terminal_details = PaymentTerminals::whereIn('user_id', $admin_id_arr)
                ->where('status', 'Y')
                ->orderBy('terminal_name', 'ASC')
                ->select('id', 'terminal_name', 'terminal_number')
                ->get();

            $payment_terminal_details = $payment_terminal_details->map(function ($item) {
                return [
                    'id' => $item->id,
                    'value' => $item->terminal_name . ' ( ' . $item->terminal_number . ')',
                ];
            })->pluck('value', 'id')->toArray();

            return view('payment-terminal-report.index', compact('payment_terminal_details', 'find_petrol_type'));

        } elseif (auth()->user()->type == 1) {
            if (auth()->user()->sub_emp_id == 0) {
                $admin_id = auth()->user()->id;
            } else {
                $admin_id = auth()->user()->sub_emp_id;
            }

            $petrolPumpCon = [
                'users.type' => 3,
                'users.sub_emp_id' => 0,
                'users.id_parent_organisation' => $admin_id,
                'users.status' => 'Y',
            ];

            // Retrieve employees with related User
            $petrol_pump = Employees::whereHas('user', function ($query) use ($petrolPumpCon) {
                foreach ($petrolPumpCon as $field => $value) {
                    if (is_array($value)) {
                        // Handle special cases where the value is an array, e.g., for 'IN' conditions
                        $query->whereIn($field, $value);
                    } else {
                        $query->where($field, $value);
                    }
                }
            })
                ->orderBy('organization_name', 'ASC')
                ->pluck('organization_name', 'user_id');

            // Retrieve and process the user data
            $admins = User::select(DB::raw('GROUP_CONCAT(DISTINCT(id)) as petrol_station_ids'))
                ->where($petrolPumpCon)
                ->first();

            if (!empty($admins->petrol_station_ids)) {
                $admin_id_arr = explode(",", $admins->petrol_station_ids);
            }


            $reservoirs = Reservoirs::where('status', 1)
                ->whereIn('user_id', $admin_id_arr)
                ->selectRaw('GROUP_CONCAT(DISTINCT(petrol_type_id)) as petrol_type_ids')
                ->first();

            $petrol_type_con['status'] = "Y";


            if (!empty($reservoirs->petrol_type_ids)) {
                $petrol_type_con['id'] = explode(",", $reservoirs->petrol_type_ids);

            } else {
                $petrol_type_con['id'] = [0];
            }

            $find_petrol_type = PetrolTypes::whereIn('id', $petrol_type_con['id'])
                ->where('status', $petrol_type_con['status'])
                ->pluck('petrol_type_en', 'id')
                ->toArray();

            // Retrieve payment terminal details
            $payment_terminal_details = PaymentTerminals::whereIn('user_id', $admin_id_arr)
                ->where('status', 'Y')
                ->orderBy('terminal_name', 'ASC')
                ->select('id', 'terminal_name', 'terminal_number')
                ->get();

            $payment_terminal_details = $payment_terminal_details->map(function ($item) {
                return [
                    'id' => $item->id,
                    'value' => $item->terminal_name . ' ( ' . $item->terminal_number . ')',
                ];
            })->pluck('value', 'id')->toArray();

            return view('payment-terminal-report.index', compact('payment_terminal_details', 'find_petrol_type', 'petrol_pump'));
        } else {
            return redirect()->route('dashboard')
                ->with('error', 'You are not authorized to view this record.');
        }

    }

    public function ajaxIndex(Request $request)
    {

        $response['draw'] = $request->draw;
        $offset = $request->start;
        $length = $request->length;
        $order = $request->order;


        if (request()->ajax()) {
            $admin_id_arr = [0];

            if (auth()->user()->type == 3) {
                if (auth()->user()->sub_emp_id == 0) {
                    $admin_id = auth()->user()->id;
                } else {
                    $admin_id = auth()->user()->sub_emp_id;
                }
                $admin_id_arr = [$admin_id];
            } elseif (auth()->user()->type == 1) {
                if (auth()->user()->sub_emp_id == 0) {
                    $admin_id = auth()->user()->id;
                } else {
                    $admin_id = auth()->user()->sub_emp_id;
                }

                $petrolPumpCon = [
                    'users.type' => 3,
                    'users.sub_emp_id' => 0,
                    'users.id_parent_organisation' => $admin_id,
                    'users.status' => 'Y',
                ];

                // Retrieve and process the user data
                $admins = User::select(DB::raw('GROUP_CONCAT(DISTINCT(id)) as petrol_station_ids'))
                    ->where($petrolPumpCon)
                    ->first();


                if (!empty($admins->petrol_station_ids)) {
                    $admin_id_arr = explode(",", $admins->petrol_station_ids);
                }
            }

            $condition = ShiftPaymentTerminalPetrolSale::whereIn('user_id', $admin_id_arr);

            if (!empty($request->payment_terminal)) {
                $condition->where('shift_payment_terminal_petrol_sales.payment_terminal_id', $request->payment_terminal);
            }

            if (!empty($request->petrol_type_id)) {
                $condition->where('shift_payment_terminal_petrol_sales.petrol_typeid', $request->petrol_type_id);
            }

            if ($request->petrol_station_id && $request->petrol_station_id !== '') {
                $petrol_station_ids = $request->petrol_station_id;

                if (is_array($petrol_station_ids)) {
                    $condition->whereIn('shift_payment_terminal_petrol_sales.user_id', $petrol_station_ids);
                }
            }

            if (!empty($request->start_date_time)) {
                $condition->whereDate('shift_payment_terminal_petrol_sales.sales_date', '>=', $request->start_date_time);
            }

            if (!empty($request->end_date_time)) {
                $condition->whereDate('shift_payment_terminal_petrol_sales.sales_date', '<=', $request->end_date_time);
            }

            if ($request->has('search')) {
                $search = $request['search']['value'];

                $date_arr = explode('/', $search);
                $formattedDate = '%';
                if (isset($date_arr[2]) && $date_arr[2] != "") {
                    $formattedDate .= $date_arr[2] . "-";
                }
                if (isset($date_arr[1]) && $date_arr[1] != "") {
                    $formattedDate .= $date_arr[1] . "-";
                }
                if (isset($date_arr[0]) && $date_arr[0] != "") {
                    $formattedDate .= $date_arr[0];
                }
                $formattedDate .= '%';


                $condition->where(function ($query) use ($search, $formattedDate) {
                    $query->orWhere('shift_payment_terminal_petrol_sales.petrol_type_name', 'like', "%$search%")
                        ->orWhere('shift_payment_terminal_petrol_sales.amount_received', 'like', "%$search%")
                        ->orWhere('shift_payment_terminal_petrol_sales.sales_date', 'like', "%$formattedDate%")
                        ->orWhere('shift_payment_terminal_petrol_sales.creation_date', 'like', "%$formattedDate%");

                    $query->orWhereHas('shiftReport', function ($subquery) use ($search, $formattedDate) {
                        $subquery->where('shiftid', 'like', "%$search%")
                            ->orWhere('shift_name', 'like', "%$search%")
                            ->orWhere('shift_date', 'like', "%$formattedDate%");
                    });
                    $query->orWhereHas('users', function ($subquery) use ($search) {
                        $subquery->where('username', 'like', "%$search%");
                    });
                    $query->orWhereHas('Employees', function ($subquery) use ($search) {
                        $subquery->where('name', 'like', "%$search%")
                            ->orWhere('organization_name', 'like', "%$search%");
                    });
                    $query->orWhereHas('Banks', function ($subquery) use ($search) {
                        $subquery->where('bank_name', 'like', "%$search%");
                    });
                    $query->orWhere(function ($query) use ($search) {
                        $query->orWhereHas('PaymentTerminals', function ($subquery) use ($search) {
                            $subquery->where('terminal_name', 'like', "%$search%")
                                ->orWhere('terminal_number', 'like', "%$search%");
                        })
                            ->orWhereRaw('CONCAT(payment_terminal_name, " (", payment_terminal_number, ")") LIKE ?', ["%$search%"]);
                    });

                });


            }

            $shiftPaymentTerminalPetrolSales = $condition->with(['ShiftReport', 'Users', 'Employees', 'Banks', 'PaymentTerminals']);

            $count = $shiftPaymentTerminalPetrolSales->count();

            $filteredCount = $count;

            // Get the data for the current page
            $shiftPaymentTerminalPetrolSales = $shiftPaymentTerminalPetrolSales->skip($offset)->take($length)->get();


            $records_data = [];
            foreach ($shiftPaymentTerminalPetrolSales as $shiftPaymentTerminalPetrolSale) {
                $shiftid = $shiftPaymentTerminalPetrolSale->ShiftReport->shiftid ?? '';
                if (!empty($shiftPaymentTerminalPetrolSale->ShiftReport->shift_start_at_midnight) == "Y" || !empty($shiftPaymentTerminalPetrolSale->ShiftReport->shift_end_at_midnight) == "Y") {
                    $default_language = get_default_language();
                    $shift_name_type = 'shift_name_' . $default_language;
                    $shift_name = $shiftPaymentTerminalPetrolSale->ShiftReport->$shift_name_type;
                } else {
                    // $default_language = get_default_language();
                    // $shift_name_type = 'shift_name_'.$default_language;
                    $shift_name = $shiftPaymentTerminalPetrolSale->ShiftReport->shift_name_en ?? '';
                }
                $shift_date = $shiftPaymentTerminalPetrolSale->ShiftReport->shift_date ?? '';

                $find_petrol_pump = $shiftPaymentTerminalPetrolSale->Employees->organization_name ?? $shiftPaymentTerminalPetrolSale->Employees->name ?? '';
                $terminal_name = $shiftPaymentTerminalPetrolSale->PaymentTerminals->terminal_name ?? '';
                $terminal_number = $shiftPaymentTerminalPetrolSale->PaymentTerminals->terminal_number ?? '';
                $petrol_type_name = $shiftPaymentTerminalPetrolSale->petrol_type_name;
                $bank_name = $shiftPaymentTerminalPetrolSale->Banks->bank_name;
                $amount_received = $shiftPaymentTerminalPetrolSale->amount_received;
                $sales_date = $shiftPaymentTerminalPetrolSale->sales_date;
                $creation_date = $shiftPaymentTerminalPetrolSale->creation_date;

                $records_data[] = [
                    'shiftid' => $shiftid,
                    'shift_name' => $shift_name,
                    'shift_date' => $shift_date,
                    'petrol_station' => $find_petrol_pump,
                    'petrol_type' => $petrol_type_name,
                    'terminal_name' => $terminal_name,
                    'terminal_number' => $terminal_number,
                    'bank_name' => $bank_name,
                    'amount_received' => $amount_received,
                    'sales_date' => $sales_date,
                    'creation_date' => $creation_date,
                ];

            }


            // Format the response in the structure expected by DataTables
            $formattedData = [
                'draw' => $request->draw,
                'recordsTotal' => $count,
                'recordsFiltered' => $filteredCount,
                'data' => $records_data,
            ];
            return response()->json($formattedData);

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}