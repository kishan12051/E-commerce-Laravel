<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\ConfirmsPasswords;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Cookie;

class ConfirmPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Confirm Password Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password confirmations and
    | uses a simple trait to include the behavior. You're free to explore
    | this trait and override any functions that require customization.
    |
    */

    use ConfirmsPasswords;

    /**
     * Where to redirect users when the intended url fails.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function showConfirmForm()
    {       
        return view('auth.passwords.confirm');
    }
    public function confirm(Request $request)
    {
        $request->validate([
            'password' => 'required', // Add a "password" validation rule to check the user's password
        ]);
        $user = auth()->user();
        if (Hash::check($request->password, $user->password)) {
            $user = User::find($user->id);
            $user->last_activity_at = now();
            $user->save();

            $idleUrl = Session::get('idle_url','/');

            return redirect($idleUrl)->withCookie(cookie()->forget('confirmpassword'));

        }else{
            return redirect()->route('password.confirm')->with('error','Login data is in-correct');
        }
        return redirect()->intended(); // Redirect the user to their intended URL
    }
}