<?php

namespace App\Http\Controllers;

use App\Models\Bank;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;

class BankController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:bank-list', ['only' => ['index','show']]);
        $this->middleware('permission:bank-create', ['only' => ['create','store']]);
        $this->middleware('permission:bank-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:bank-delete', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page_title = 'Lists Of Banks';
        $banks = Bank::orderBy('id', 'DESC')->get();
        return view('banks.index', compact('banks', 'page_title'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $pageTitle = 'Add New Bank';
        return view('banks.create',compact('pageTitle'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messages = [
            'bank_name.required' => 'The field is required.',
            'bank_name.unique' => 'This Bank is already taken.',
        ];
        $this->validate($request, [
            'bank_name' => 'required|unique:banks,bank_name',
        ], $messages);

         $bank                  = new Bank();
         $bank->bank_name       = $request->bank_name;
         $bank->status          = $request->status;
         $bank->created_at      = now();
         $bank->created_by      = Auth::user()->id;
         $bank->save();
        return redirect()->route('banks.index')->with('message','The record has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Bank $bank)
    {
        $pageTitle = 'List(s) Of Banks';
        return view('banks.show',compact('bank','pageTitle'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $bank = Bank::find($id);
        $pageTitle = 'Update Bank';
        return view('banks.edit',compact('bank','pageTitle'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messages = [
            'bank_name.required' => 'The field is required.',
            'bank_name.unique' => 'This Bank is already taken.',
        ];
        $this->validate($request, [
            'bank_name' => 'required|unique:banks,bank_name,'.$id,
        ], $messages);

        $bank = Bank::find($id);
        $bank->bank_name   = $request->bank_name;
        $bank->status = $request->status == 'Y' ? 'Y' : 'N';
        $bank->updated_at        = now();
        $bank->modified_by       = Auth::user()->id;
        $bank->save();
        return redirect()->route('banks.index')->with('message','The record has been updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function changeBanksStatus(Request $request)
    {
        $bankId = $request->id;
        $bank = Bank::find($bankId);
        if (!$bank) {
            return response()->json(['message' => 'Bank not found'], 404);
        }
        /* Toggle the Bank's status */
        $bank->status = ($bank->status === 'Y') ? 'N' : 'Y';
        $newStatus = $bank->status === 'Y' ? 'Active' : 'Inactive';
        if ($bank->save()) {
            return response()->json(['success' => true, 'newStatus' => $newStatus, 'message' => 'Bank status updated successfully']);
        } else {
            return response()->json(['success' => false, 'newStatus' => $newStatus, 'message' => 'Something Wents wrong']);
        }
    }

    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = Bank::find($request->status);
            if ($record) {
                $record->delete();
                $allData = Bank::select('id', 'bank_name', 'status')->orderBy('id', 'DESC')->get();
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('banks.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="banks" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $status = '<button class="btn btn-' . ($allDataRow->status == 'Y' ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="banks" data-id="' . $allDataRow->id . '">'
                        . ($allDataRow->status == 'Y' ? 'Activate' : 'Inactive') . ''
                        . '</button>';
                    $allDataRow->status = $status;
                    $allDataRow->action = $html;
                }

                return response()->json(['data' => $allData, 'message' => 'The record has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Bank not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
