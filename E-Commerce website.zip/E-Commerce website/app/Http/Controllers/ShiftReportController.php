<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Employees;
use App\Models\Shifts;
use App\Models\PetrolPumps;
use App\Models\ShiftReport;
use App\Models\ShiftEmployees;
use App\Models\Reservoirs;
use App\Models\ShiftTankReadings;
use App\Models\BottledOilType;
use App\Models\MainMatrixCalculations;
use App\Models\PetrolTypes;
use App\Models\SubMatrixCalculations;
use App\Models\ShiftBottledOilReadings;
use App\Models\ShiftPumpReadings;
use App\Models\User;
use App\Models\ShiftFillingReadings;
use App\Models\ShiftBottledOilFillingReadings;
use App\Models\GeneralSettings;
use App\Models\PaymentTerminals;
use App\Models\ShiftBottledOilSales;
use App\Models\ShiftPetrolSales;
use App\Models\ShiftPaymentTerminalPetrolSales;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Response;

class ShiftReportController extends Controller
{

	/**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    // function __construct(){
    //     $this->middleware('permission:shiftreport-create', ['only' => ['create','store']]);
    // }
    
    //Create the shift report
    public function create()
    {

        $userId = Auth::user()->id;

        $employees = Employees::where('user_id', $userId)->first();

        $shiftsRecords = Shifts::select('id', 'shift1_title_en', 'shift1_title_ru', 'shift1_title_tu', 'shift1_time', 'shift_start_time', 'shift_end_time')
            ->where('user_id', $userId)
            ->where('status', '1')
            ->where('start_date', '<=', date("Y-m-d"))
            ->where('end_date', '>=', date("Y-m-d"))
            ->get();

        // $employeesRecords = DB::table('users')
        $employeesRecords = User::select('users.*', 'employees.user_id', 'employees.id', 'employees.name')
            ->join('employees', 'employees.user_id', '=', 'users.id')
            ->where('users.sub_emp_id', $userId)
            ->where('users.type', '3')
            ->where('users.status', 'Y')
            ->orderBy('employees.name', 'ASC')
            ->get();

        $findPetrolPump =  PetrolPumps::where('user_id', $userId)->where('status', '1')->get();

        return view('shiftreport.create', compact('employees', 'shiftsRecords', 'findPetrolPump', 'employeesRecords'));
    }

    //Store the shift report records
    public function store(Request $request)
    {
        if (Auth::user()->type == 3) {

            $userId = Auth::user()->id;
            $shift_date = date("Y-m-d", strtotime($request->shift_start_date_time));
            /* Audit Code */
            $unscheduled_audit = $request->unscheduled_audit;
            $previously_shift_was_audit = $request->previously_shift_was_audit;
            $audit_time = $request->audit_time;
            $audit_date_time = NULL;
            $different_days = 0;

            if($audit_time != null && $audit_time != "" && $unscheduled_audit == 'Y'){
                $startDate = $request->shift_start_date_time;
                $endDate = $request->shift_end_date_time;
                // $audit_date = $this->request->getData('audit_date');
                // $audit_time = $this->request->getData('audit_time');
                if(date('Y-m-d', strtotime($startDate)) != date('Y-m-d', strtotime($endDate))){
                    $day1_start = $startDate;
                    $day1_end = date('Y-m-d', strtotime($startDate)).' 23:59:59';
                    $day2_start = date('Y-m-d', strtotime($endDate)).' 00:00:00';
                    $day2_end = $endDate;
                    $startAuditTime = date('Y-m-d', strtotime($startDate)).' '.$audit_time.':00';
                    $endAuditTime = date('Y-m-d', strtotime($endDate)).' '.$audit_time.':00';
                    if($startAuditTime >= $day1_start.':00' && $startAuditTime <= $day1_end){
                        $audit_date_time = date('Y-m-d', strtotime($startDate)).' '.$audit_time.':00';
                    }elseif($endAuditTime >= $day2_start && $endAuditTime <= $day2_end.':00'){
                        $audit_date_time = date('Y-m-d', strtotime($endDate)).' '.$audit_time.':00';
                        $different_days = 1;
                    }
                }else{
                    $audit_date_time = date('Y-m-d', strtotime($startDate)).' '.$audit_time.':00';
                }
            }

            $findShiftDetails = getShiftDetails($request->shift_name);
            $shift_name = $findShiftDetails->shift1_title_en;
            $shift_time = $findShiftDetails->shift1_time;

            /* Validation */
            $shiftReportExist = ShiftReport::where('user_id',$userId)
                                ->where('shift_timeid',$request->shift_name)
                                ->where('shift_name', $findShiftDetails->shift1_title_en."(".$findShiftDetails->shift1_time.")")
                                ->where('shift_date', $shift_date)
                                ->where('shift_start_at_midnight', $request->shift_start_at_midnight)
                                ->where('shift_end_at_midnight', $request->shift_end_at_midnight)
                                ->where('audit_date_time', $audit_date_time)
                                ->where('unscheduled_audit', $unscheduled_audit)
                                ->where('previously_shift_was_audit', $previously_shift_was_audit)
                ->where('deleted_at', NULL)
                                ->count();

            if($shiftReportExist > 0){
                return redirect()->back()->with('message', __('messages.Shift report for this shift already exists.'));
            }else{
                if ($request->assign_employee && !empty($request->assign_employee)) {

        $employees = Employees::where('user_id', $userId)->first();

        $shiftsRecords = Shifts::select('id', 'shift1_title_en', 'shift1_title_ru', 'shift1_title_tu', 'shift1_time', 'shift_start_time', 'shift_end_time')
            ->where('user_id', $userId)
            ->where('id', $request->shift_name)
            ->where('status', '1')
            ->where('start_date', '<=', date("Y-m-d"))
            ->where('end_date', '>=', date("Y-m-d"))
            ->first();

        $assignedPumpData = [];
        foreach ($request->assign_pump as $key => $value) {
            $petrolPumpsRecord = PetrolPumps::where('id', $key)->where('user_id', $userId)->get();
            $assignedPumpData[$key]['petrol_type_id'] = $petrolPumpsRecord[0]['petrol_type_id'];
            $assignedPumpData[$key]['pumpid'] = $petrolPumpsRecord[0]['pumpid'];
            $assignedPumpData[$key]['pump_name_en'] = $petrolPumpsRecord[0]['pump_name_en'];
            $assignedPumpData[$key]['pump_name_ru'] = $petrolPumpsRecord[0]['pump_name_ru'];
            $assignedPumpData[$key]['pump_name_tu'] = $petrolPumpsRecord[0]['pump_name_tu'];
        }
        $shiftReport = DB::table('shift_report')->latest('id')->first();

                    $shiftStartDateTime = $request->shift_start_date_time;
                    $shiftEndDateTime = $request->shift_end_date_time;
                    $shiftName = $shiftsRecords->shift1_title_en . '(' . $shiftsRecords->shift1_time . ')';
                    $shiftNameEn = $shiftsRecords->shift1_title_en . '(' . $shiftsRecords->shift1_time . ')';
                    $shiftNameRu = $shiftsRecords->shift1_title_ru . '(' . $shiftsRecords->shift1_time . ')';
                    $shiftNameTu = $shiftsRecords->shift1_title_tu . '(' . $shiftsRecords->shift1_time . ')';


                    /* Audit Code */
                    $auditFlag = 0;
                    if($unscheduled_audit == 'Y'){
                        $audit_date = date('Y-m-d', strtotime($audit_date_time));
                        if($different_days == 1){
                            $audit_date = date('Y-m-d', strtotime($startDate));
                        }

                        $shiftReportGetData = ShiftReport::select('id','shift_start_date_time','shift_end_date_time')
                                                ->where('employee_id', $employees->id)
                                                ->where('shift_date', $audit_date)
                                                ->where('shift_timeid', $findShiftDetails->id)
                                                ->get();

                        if(count($shiftReportGetData) > 0){
                            foreach ($shiftReportGetData as $key => $shiftData) {
                                $shift_start = date('Y-m-d H:i:s', strtotime($shiftData->shift_start_date_time));
                                $shift_end = date('Y-m-d H:i:s', strtotime($shiftData->shift_end_date_time));
                                if($audit_date_time >= $shift_start && $audit_date_time <= $shift_end){
                                    // if(!isset($shiftReport->id)){
                                    //     $shiftReport->shift_start_date_time = date('Y-m-d H:i:s', strtotime($audit_date_time.' + 1 minute'));
                                    // }
                                    /* New Shift Start & End Date Time */
                                    $new_shift_start_date_time = $shiftStartDateTime;
                                    $new_shift_end_date_time = $shift_end;
                                    /* Previous Shift & End Start Date Time */
                                    $previous_shift_start_date_time = $shift_start;
                                    $previous_shift_end_date_time = $audit_date_time;
                                    /* New Shift Start & End Date */
                                    $new_shift_start_date = date('Y-m-d', strtotime($new_shift_start_date_time));
                                    $new_shift_end_date = date('Y-m-d', strtotime($new_shift_end_date_time));
                                    /* Previous Shift Start & End Date */
                                    $previous_shift_start_date = date('Y-m-d', strtotime($previous_shift_start_date_time));
                                    $previous_shift_end_date = date('Y-m-d', strtotime($previous_shift_end_date_time));
                                    /* New Shift Title In En, Ru and Tu */
                                    $new_shift1_title_en = date('H:i', strtotime($new_shift_start_date_time))."-".date('H:i', strtotime($new_shift_end_date_time));
                                    $new_shift1_title_ru = $new_shift1_title_en;
                                    $new_shift1_title_tu = $new_shift1_title_en;
                                    /* New Shift Start & End Time */
                                    $new_shift1_time = $new_shift1_title_en;
                                    $new_shift_start_time = date('H:i', strtotime($new_shift_start_date_time));
                                    $new_shift_end_time = date('H:i', strtotime($new_shift_end_date_time));
                                    /* Previous Shift Title In En, Ru and Tu */
                                    $previous_shift1_title_en = date('H:i', strtotime($previous_shift_start_date_time))."-".date('H:i', strtotime($previous_shift_end_date_time));
                                    $previous_shift1_title_ru = $previous_shift1_title_en;
                                    $previous_shift1_title_tu = $previous_shift1_title_en;
                                    /* Previous Shift Start & End Time */
                                    $previous_shift1_time = $previous_shift1_title_en;
                                    $previous_shift_start_time = date('H:i', strtotime($previous_shift_start_date_time));
                                    $previous_shift_end_time = date('H:i', strtotime($previous_shift_end_date_time));
                                    $auditFlag = 0;
                                }else{
                                    $shiftEndDateTime = date('Y-m-d H:i:s', strtotime($audit_date_time));
                                    /* New Shift Start & End Date Time */
                                    $new_shift_start_date_time = $shiftStartDateTime;
                                    $new_shift_end_date_time = $shiftEndDateTime;
                                    $new_shift1_title_en = date('H:i', strtotime($new_shift_start_date_time))."-".date('H:i', strtotime($new_shift_end_date_time));
                                    $new_shift1_time = $new_shift1_title_en;
                                    if(!isset($shiftReport->id)){
                                        $auditFlag = 1;
                                    }else{
                                        $auditFlag = 0;
                                    }
                                }
                            }
                        }else{
                            $shiftEndDateTime = date('Y-m-d H:i:s', strtotime($audit_date_time));
                            /* New Shift Start & End Date Time */
                            $new_shift_start_date_time = $shiftStartDateTime;
                            $new_shift_end_date_time = $shiftEndDateTime;
                            $new_shift1_title_en = date('H:i', strtotime($new_shift_start_date_time))."-".date('H:i', strtotime($new_shift_end_date_time));
                            $new_shift1_time = $new_shift1_title_en;
                            $auditFlag = 1;
                        }
                        /* $shiftReport->shift_timeid = $newShiftId; */
                        $shiftName = $shift_name.' ('.$new_shift1_time.')';
                        $shiftNameEn = $shift_name.' ('.$new_shift1_time.')';
                        $shiftNameRu = $shift_name.' ('.$new_shift1_time.')';
                        $shiftNameTu = $shift_name.' ('.$new_shift1_time.')';
                    }

                    if($previously_shift_was_audit == 'Y'){
                            /* Find Previous Shift */
                            $shiftDate = date('Y-m-d', strtotime($shiftStartDateTime));
                            $shiftReportGetData = ShiftReport::select('id','shift_start_date_time','shift_end_date_time')
                                                    ->where('employee_id', $employees->id)
                                                    ->where('shift_date', $shiftDate)
                                                    ->get();

                            if(count($shiftReportGetData) > 0){
                                foreach ($shiftReportGetData as $key => $shiftData) {
                                    $shift_start = date('Y-m-d H:i:s', strtotime($shiftData->shift_start_date_time));
                                    $shift_end = date('Y-m-d H:i:s', strtotime($shiftData->shift_end_date_time));
                                    $shiftAuditDate = date('Y-m-d H:i:s', strtotime($shiftReport->shift_start_date_time));
                                    if($shiftAuditDate >= $shift_start && $shiftAuditDate <= $shift_end){
                                        $shiftStartDateTime = date('Y-m-d H:i:s', strtotime($shift_end.' + 1 minute'));
                                        $new_shift1_time = date('H:i', strtotime($shift_end.' + 1 minute'))."-".date('H:i', strtotime($shiftEndDateTime));
                                    }else{
                                        $shiftStartDateTime = date('Y-m-d H:i:s', strtotime($shiftEndDateTime));
                                        $new_shift1_time = date('H:i', strtotime($shiftEndDateTime))."-".date('H:i', strtotime($shiftEndDateTime));
                                    }
                                }
                            }else{
                                // $this->Flash->error(__('Previously shift was no Audit'));
                                // return $this->redirect($this->referer());
                                // $shiftReport->shift_start_date_time = date('Y-m-d H:i:s', strtotime($shiftReport->shift_start_date_time));
                                // $new_shift1_time = date('H:i', strtotime($shiftReport->shift_start_date_time))."-".date('H:i', strtotime($shiftReport->shift_end_date_time));
                                return redirect()->back()->with('message', __('messages.Previously shift was no Audit.'));
                            }
                            $shiftName = $shift_name.' ('.$new_shift1_time.')';
                            $shiftNameEn = $shift_name.' ('.$new_shift1_time.')';
                            $shiftNameRu = $shift_name.' ('.$new_shift1_time.')';
                            $shiftNameTu = $shift_name.' ('.$new_shift1_time.')';
                    }

                    /* Add Shift Report */
                    ShiftReport::Create([
                        'user_id' => $userId,
                        'employee_id' => $employees['id'],
                        'shiftid' => "SR-" . time(),
                        'shift_timeid' => $request->shift_name,
                        'shift_date' => date("Y-m-d", strtotime($request->shift_start_date_time)),
                        'shift_start_date_time' => $shiftStartDateTime,
                        'shift_end_date_time' => $shiftEndDateTime,
                        'shift_start_at_midnight' => $request->shift_start_at_midnight,
                        'shift_end_at_midnight' => $request->shift_end_at_midnight,
                        'assigned_pump_ids' => json_encode($request->assign_pump),
                        'assigned_pump_data' => json_encode($assignedPumpData),
                        'last_report_id' => $shiftReport->id,
                        'shift_name' => $shiftName,
                        'shift_name_en' => $shiftNameEn,
                        'shift_name_ru' => $shiftNameRu,
                        'shift_name_tu' => $shiftNameTu,
                        'unscheduled_audit' => $request->unscheduled_audit,
                        'previously_shift_was_audit' => $request->previously_shift_was_audit,
                        'audit_date_time' => $audit_date_time,
                        'created' => date('Y-m-d H:i:s'),
                        'modified' => date('Y-m-d H:i:s'),
                        'created_admin_id' => $userId,
                        'modified_admin_id' => $userId,
                    ]);

                    /* Last Report Id*/
                    $shiftReport = DB::table('shift_report')->latest('id')->first();
                    // $shiftReportId = DB::table('shift_report')->latest('id')->first();

                    if($unscheduled_audit == 'Y'){
                        if($auditFlag == 0){
                            // $getShiftReportData = $this->ShiftReport->find();
                            // $getShiftReportData->where(['id' => $shiftReport->id]);
                            // $shiftReportData = $getShiftReportData->first();
                            // $shift_data['shift_name'] = $shift_name.' ('.$previous_shift1_time.')';
                            // $shift_data['shift_name_en'] = $shift_name.' ('.$previous_shift1_time.')';
                            // $shift_data['shift_name_ru'] = $shift_name.' ('.$previous_shift1_time.')';
                            // $shift_data['shift_name_tu'] = $shift_name.' ('.$previous_shift1_time.')';
                            // $shift_data['shift_end_date_time'] = $audit_date_time;
                            // $shiftReportData = $this->ShiftReport->patchEntity($shiftReportData, $shift_data);
                            // $this->ShiftReport->save($shiftReportData);
                        }else{
                            // sleep(3);
                            $shiftex = explode('-',$shift_time);
                            $new_shift1_time = date('H:i', strtotime($audit_date_time.' + 1 minute'))."-".trim($shiftex[1]);
                            ShiftReport::Create([
                                'user_id' => $userId,
                                'employee_id' => $employees['id'],
                                'shiftid' => "SR-" . time(),
                                'shift_timeid' => $findShiftDetails->id,
                                'shift_date' => $shift_date,
                                'shift_start_at_midnight' => $request->shift_start_at_midnight,
                                'shift_end_at_midnight' => $request->shift_end_at_midnight,
                                'shift_name' => $shift_name.' ('.$new_shift1_time.')',
                                'shift_name_en' => $shift_name.' ('.$new_shift1_time.')',
                                'shift_name_ru' => $shift_name.' ('.$new_shift1_time.')',
                                'shift_name_tu' => $shift_name.' ('.$new_shift1_time.')',
                                'shift_start_date_time' => date('Y-m-d H:i:s', strtotime($audit_date_time.' + 1 minute')),
                                'shift_end_date_time' => $shiftEndDateTime,
                                'assigned_pump_ids' => json_encode($request->assign_pump),
                                'assigned_pump_data' => json_encode($assignedPumpData),
                                'employee_group' => 'All',
                                'notes' => $request->end_pump_reading_notes,
                                'last_report_id' => $shiftReport->id,
                                'assign_rac_emplyee_details' => NULL,
                                'status' => "P",
                                'created_admin_id' => $userId,
                                'modified_admin_id' => $userId,
                                'is_active_tab' => $request->is_active_tab,
                                'unscheduled_audit' => 'Y',
                                'previously_shift_was_audit' => $request->previously_shift_was_audit,
                                'audit_date_time' => $audit_date_time,
                                'created' => date('Y-m-d H:i:s'),
                                'modified' => date('Y-m-d H:i:s'),
                            ]);
                        }
                    }

                    $findManager = DB::table('employees')
                    ->select('employees.id', 'employees.emp_id', 'employees.name', 'employees.phone_number', 'users.email')
                    ->where('employees.id', $request->manager_id)
                    ->join('users', 'users.id', '=', 'employees.user_id')
                    ->first();

                    ShiftEmployees::create([
                        'creation_date' => date("Y-m-d"),
                        'status' => "Y",
                        'shift_report_id' => $shiftReport->id,
                        'employee_id' => $findManager->id,
                        'employeeid' => $findManager->emp_id,
                        'employee_name' => $findManager->name,
                        'employee_phone' => $findManager->phone_number,
                        'employee_email' => $findManager->email,
                        'is_manager' => 1,
                    ]);

                    foreach ($request->assign_employee as $empKey => $empVal) {
                        if ($empVal != "" && $empVal > 0) {
                            $emp_data = [];
                            $findEachEmployee = DB::table('employees')
                            ->select('employees.id', 'employees.emp_id', 'employees.name', 'employees.phone_number', 'users.email')
                            ->where('employees.id', $empVal)
                            ->join('users', 'users.id', '=', 'employees.user_id')
                            ->first();

                            ShiftEmployees::create([
                                'employee_id' => $findEachEmployee->id,
                                'employeeid' => $findEachEmployee->emp_id,
                                'employee_name' => $findEachEmployee->name,
                                'employee_phone' => $findEachEmployee->phone_number,
                                'employee_email' => $findEachEmployee->email,
                                'shift_report_id' => $shiftReport->id,
                                'is_manager' => 0,
                            ]);
                        }
                    }

                }
                
                return redirect()->to('shift-report/' . $shiftReport->id . '/edit')->with('message', 'Shift created successfully.');
            }

        }else{
            return redirect()->to('/')->with('message', 'You are not authorized to view this record.');
        }
    }

    //Edit the shift report.
    public function edit(Request $request,$id)
    {
        if (Auth::user()->type == 3) {
            /*userId*/
            $userId = Auth::user()->id;
            
            /*employees*/
            $employees = Employees::where('user_id', $userId)->first();
     
            /*shifts*/
            $shiftsRecords = Shifts::select('id', 'shift1_title_en', 'shift1_title_ru', 'shift1_title_tu', 'shift1_time', 'shift_start_time', 'shift_end_time')
                ->where('user_id', $userId)
                ->where('status', '1')
                ->where('start_date', '<=', date("Y-m-d"))
                ->where('end_date', '>=', date("Y-m-d"))
                ->get();

            $shiftSelectedRecords = Shifts::select('shifts.*','shift_report.*')
                ->join('shift_report','shift_report.shift_timeid','=','shifts.id')
                ->where('shift_report.user_id', $userId)
                ->where('shift_report.id', $id)
                ->where('shifts.status', '1')
                ->where('shifts.start_date', '<=', date("Y-m-d"))
                ->where('shifts.end_date', '>=', date("Y-m-d"))
                ->first();

            /*employees  and user*/
            $employeesRecords = User::select('users.*', 'employees.user_id', 'employees.id', 'employees.name')
                ->join('employees', 'employees.user_id', '=', 'users.id')
                ->where('users.sub_emp_id', $userId)
                ->where('users.type', '3')
                ->where('users.status', 'Y')
                ->orderBy('employees.name', 'ASC')
                ->get();

            $employeesSelectedRecords = User::select('users.*', 'employees.user_id', 'employees.id', 'employees.name','shift_employees.*')
                ->join('employees', 'employees.user_id', '=', 'users.id')
                ->join('shift_employees','shift_employees.employee_id','employees.id')
                ->where('users.sub_emp_id', $userId)
                ->where('shift_employees.shift_report_id', $id)
                ->where('shift_employees.is_manager','1')
                ->where('users.type', '3')
                ->where('users.status', 'Y')
                ->first();


            /*petrol pumps*/
            $findPetrolPump =  PetrolPumps::where('user_id', $userId)->where('status', '1')->get();

            /*Petrol types and petrol pumps */
            $findPetrolPumpRecords =  PetrolTypes::select('petrol_types.*', 'petrol_pumps.*')
                ->join('petrol_pumps', 'petrol_pumps.petrol_type_id', '=', 'petrol_types.id')
                ->where('petrol_pumps.user_id', $userId)
                ->where('petrol_pumps.status', '1')
                ->get();

            /*reservoirs and petrol types */
            $reservoirsRecords = Reservoirs::select('reservoirs.*', 'petrol_types.petrol_type_en')
                ->join('petrol_types', 'petrol_types.id', '=', 'reservoirs.petrol_type_id')
                ->where('reservoirs.user_id', $userId)
                ->where('reservoirs.status', '1')->get();

            /*shiftReport*/ 
            $shiftReport = ShiftReport::with([
                'ShiftTankReadings',
                'ShiftBottledOilReadings',
                'ShiftPumpReadings',
                'ShiftFillingReadings',
                'ShiftBottledOilFillingReadings'
            ])
            ->where('id',$id)
            ->first();

            /*shiftReport Id*/
            $shiftReportId = $shiftReport->id;
            $shiftLastReportId = $shiftReport->last_report_id;

            /*Shift Tank Readings*/
            $shiftTankReadings = ShiftTankReadings::where('shift_report_id', $shiftReportId)->get();

            if($shiftReport) {
                $fuelInCm =  $fuelInLiter = [];
                if ($shiftTankReadings) {
                    foreach ($shiftTankReadings as $key => $value) {
                        $fuelInCm[$value->reservoir_id] = $value->start_shift_height;
                        $fuelInLiter[$value->reservoir_id] = $value->start_shift_fuel;
                    }
                }
            }
            
            if($shiftReportId){

                /*Shift Tank Readings and petrol types*/
                $shiftTankReadingsRecords = ShiftTankReadings::select('shift_tank_readings.*','petrol_types.type_code','petrol_types.petrol_type_en','petrol_types.petrol_type_ru','petrol_types.petrol_type_tu','petrol_types.status')
                ->join('petrol_types', 'petrol_types.id', '=', 'shift_tank_readings.petrol_typeid')
                ->where('shift_tank_readings.shift_report_id', $shiftReportId)
                ->get();
               
                $tankReadingsRecords = array();
                foreach($shiftTankReadingsRecords as $value){
                    $tankReadingsRecords[$value->reservoir_id] = array(
                        'reservoir_id' => $value->reservoir_id,
                        'start_shift_height' => $value->start_shift_height,
                        'start_shift_fuel' => $value->start_shift_fuel
                    );                
                }

                /*shift bottled oil readings*/
                $shiftBottledOilReadings = ShiftBottledOilReadings::select('shift_bottled_oil_readings.*', 'bottled_oil_types.bottled_oil_en','bottled_oil_types.bottled_oil_ru','bottled_oil_types.bottled_oil_tu','bottled_oil_types.volumn','bottled_oil_types.price')
                ->join('bottled_oil_types', 'bottled_oil_types.id', '=', 'shift_bottled_oil_readings.bottled_oil_type_id')
                ->where('shift_bottled_oil_readings.shift_report_id', $shiftReportId)
                ->get();
                $bottledOilReadingsRecords = array();
                foreach ($shiftBottledOilReadings as $value) {
                   $bottledOilReadingsRecords[$value->bottled_oil_type_id] = array(
                    'start_shift_quantity' => $value->start_shift_quantity,
                   );
                }
              
            }
            
            /*bottled oil types*/
            $bottledOilTypes = BottledOilType::get();

            /*User and employees when users (type = 4)*/
            $users = User::select('employees.id', 'employees.organization_name as name')
                ->join('employees', 'employees.user_id', '=', 'users.id')
                ->where('users.status', 'Y')
                ->where('users.type', 4)
                ->orderBy('employees.organization_name', 'ASC')
                ->limit(1000)
                ->get();

            /*reservoirs*/
            $findPetrolTypeIds = Reservoirs::where('status', 1)
                ->where('user_id', $userId)
                ->selectRaw('GROUP_CONCAT(DISTINCT petrol_type_id) AS petrol_type_ids')
                ->first();

            /*petrol type ids*/
            $petrolTypeIds = $findPetrolTypeIds->petrol_type_ids;

            /*petrol type*/
            if ($petrolTypeIds != '') {
                $petrolTypes = PetrolTypes::where('status', 'Y')
                    ->whereIn('id', explode(',', $petrolTypeIds))
                    ->get();
            }
            /*petrol type*/
            $petrolTypesData = PetrolTypes::select('id', 'petrol_type_en', 'petrol_type_ru', 'petrol_type_tu')->where('status', 'Y')->get();
            
            /*Shift Filling Readings*/
            $shiftFillingReadings  = ShiftFillingReadings::where('shift_report_id',$shiftReportId)->get();
          
            /*shift bottled oil filling readings*/
            $shiftBottledOilFillingReadings  = ShiftBottledOilFillingReadings::where('shift_report_id',$shiftReportId)->get();

            /*shift pump readings*/
            $shiftPumpReadings = ShiftPumpReadings::where('shift_report_id',$shiftReportId)->get();
            $shiftPumpReadingsRecords = array();
            foreach ($shiftPumpReadings as $value) {
                $shiftPumpReadingsRecords[$value->petrol_pump_id] = array(
                    'petrol_pump_id' => $value->petrol_pump_id,
                    'start_reading' => $value->start_reading
                );
            }

            /*general settings*/
            $siteGeneralSettings = GeneralSettings::where('voucher_volumes', '!=', null)->first();

            /*shift employees*/
            $findExistingPumpEmployeeDetails = ShiftEmployees::where('shift_report_id', $shiftReportId)->where('is_manager', 0)->pluck('employee_id')->toArray();

            /*shift bottled oil sales*/
            $shiftBottledOilSales = ShiftBottledOilSales::where('shift_report_id', $shiftReportId)->get();

            /* Get Last Shift Report */
            $find_previous_shift_details = ShiftReport::with([
                'ShiftTankReadings',
                'ShiftBottledOilReadings',
                'ShiftPumpReadings',
                'ShiftFillingReadings',
                'ShiftBottledOilFillingReadings'
            ])
            ->where('id', $shiftLastReportId)
            ->first();

            /* Default Languages */
            $defaultLanguage = get_default_language();

            return view('shiftreport.edit', compact('employees', 'shiftsRecords', 'shiftSelectedRecords', 'employeesSelectedRecords', 'findPetrolPump', 'employeesRecords', 'reservoirsRecords', 'bottledOilTypes', 'shiftReport', 'shiftReportId', 'findPetrolPumpRecords', 'shiftTankReadings', 'tankReadingsRecords','shiftBottledOilReadings', 'bottledOilReadingsRecords' ,'shiftTankReadingsRecords', 'users', 'petrolTypes', 'shiftFillingReadings', 'shiftBottledOilFillingReadings','shiftPumpReadings', 'shiftPumpReadingsRecords','fuelInLiter','fuelInCm','petrolTypesData','siteGeneralSettings','findExistingPumpEmployeeDetails','shiftBottledOilSales','find_previous_shift_details','defaultLanguage'));

            // return redirect()->back()->withErrors(['msg' => 'The Message']);
        }else{
            return redirect()->to('/')->with('message', 'You are not authorized to view this record.');
        }
    }

    //Update he shift Report data.
    public function update(Request $request, $shiftReportId)
    {
        if (Auth::user()->type == 3) {

            $userId = Auth::user()->id;

            /* Get Shift Report Details */
            $shiftReport = ShiftReport::where('id', $shiftReportId)->first();

            if ($shiftReport) {

                /* Get Emplloyees */
                $employees = Employees::where('user_id', $userId)->first();

                $unscheduled_audit = $request->unscheduled_audit;
                $audit_time = $request->audit_time;
                $audit_date_time = NULL;
                $different_days = 0;

                if ($audit_time != null && $audit_time != "" && $unscheduled_audit == 'Y') {
                    $startDate = $request->shift_start_date_time;
                    $endDate = $request->shift_end_date_time;
                    // $audit_date = $this->request->getData('audit_date');
                    // $audit_time = $this->request->getData('audit_time');
                    if (date('Y-m-d', strtotime($startDate)) != date('Y-m-d', strtotime($endDate))) {
                        $day1_start = $startDate;
                        $day1_end = date('Y-m-d', strtotime($startDate)) . ' 23:59:59';
                        $day2_start = date('Y-m-d', strtotime($endDate)) . ' 00:00:00';
                        $day2_end = $endDate;
                        $startAuditTime = date('Y-m-d', strtotime($startDate)) . ' ' . $audit_time . ':00';
                        $endAuditTime = date('Y-m-d', strtotime($endDate)) . ' ' . $audit_time . ':00';
                        if ($startAuditTime >= $day1_start . ':00' && $startAuditTime <= $day1_end) {
                            $audit_date_time = date('Y-m-d', strtotime($startDate)) . ' ' . $audit_time . ':00';
                        } elseif ($endAuditTime >= $day2_start && $endAuditTime <= $day2_end . ':00') {
                            $audit_date_time = date('Y-m-d', strtotime($endDate)) . ' ' . $audit_time . ':00';
                            $different_days = 1;
                        }
                    } else {
                        $audit_date_time = date('Y-m-d', strtotime($startDate)) . ' ' . $audit_time . ':00';
                    }
                }

                $assignedPumpData = [];
                foreach ($request->assign_pump as $key => $value) {
                    $petrolPumpsRecord = PetrolPumps::where('id', $key)->where('user_id', $userId)->get();
                    $assignedPumpData[$key]['petrol_type_id'] = $petrolPumpsRecord[0]['petrol_type_id'];
                    $assignedPumpData[$key]['pumpid'] = $petrolPumpsRecord[0]['pumpid'];
                    $assignedPumpData[$key]['pump_name_en'] = $petrolPumpsRecord[0]['pump_name_en'];
                    $assignedPumpData[$key]['pump_name_ru'] = $petrolPumpsRecord[0]['pump_name_ru'];
                    $assignedPumpData[$key]['pump_name_tu'] = $petrolPumpsRecord[0]['pump_name_tu'];
                }

                /* Get Shift Details */
                $shiftStartDateTime = $request->shift_start_date_time;
                $shiftEndDateTime = date('Y-m-d H:i:s', strtotime($audit_date_time));
                $new_shift_start_date_time = $shiftStartDateTime;
                $new_shift_end_date_time = $shiftEndDateTime;

                $shift_date = date("Y-m-d", strtotime($request->shift_start_date_time));
                $findShiftDetails = getShiftDetails($request->shift_name);
                $shift_name = $findShiftDetails->shift1_title_en;
                $shift_time = $findShiftDetails->shift1_time;
                $new_shift_start_date_time = $request->shift_start_date_time;
                $new_shift1_title_en = date('H:i', strtotime($new_shift_start_date_time)) . "-" . date('H:i', strtotime($new_shift_end_date_time));
                $new_shift1_time = $new_shift1_title_en;

                ShiftReport::where('id', $shiftReportId)->update([
                    'user_id' => $userId,
                    'employee_id' => $employees->id,
                    'shift_timeid' => $findShiftDetails->id,
                    'shift_date' => $shift_date,
                    'shift_start_at_midnight' => $request->shift_start_at_midnight,
                    'shift_end_at_midnight' => $request->shift_end_at_midnight,
                    'shift_name' => $shift_name . ' (' . $new_shift1_time . ')',
                    'shift_name_en' => $shift_name . ' (' . $new_shift1_time . ')',
                    'shift_name_ru' => $shift_name . ' (' . $new_shift1_time . ')',
                    'shift_name_tu' => $shift_name . ' (' . $new_shift1_time . ')',
                    'shift_start_date_time' => date('Y-m-d H:i:s', strtotime($audit_date_time . ' + 1 minute')),
                    'shift_end_date_time' => $shiftEndDateTime,
                    'assigned_pump_ids' => json_encode($request->assign_pump),
                    'assigned_pump_data' => json_encode($assignedPumpData),
                    'employee_group' => 'All',
                    'notes' => $request->end_pump_reading_notes,
                    'last_report_id' => $shiftReport->id,
                    'assign_rac_emplyee_details' => NULL,
                    'status' => "P",
                    'modified_admin_id' => $userId,
                    'is_active_tab' => $request->is_active_tab,
                    'unscheduled_audit' => 'Y',
                    'previously_shift_was_audit' => $request->previously_shift_was_audit,
                    'audit_date_time' => $audit_date_time,
                    'modified' => date('Y-m-d H:i:s'),
                ]);

                // ShiftEmployees::where('shift_report_id', $shiftReport->id)->delete();
                Db::table('shift_employees')->where('shift_report_id', $shiftReport->id)->delete();

                $findManager = Employees::select('employees.id', 'employees.emp_id', 'employees.name', 'employees.phone_number', 'users.email')
                    ->where('employees.id', $request->manager_id)
                    ->join('users', 'users.id', '=', 'employees.user_id')
                    ->first();

                ShiftEmployees::create([
                    'creation_date' => date("Y-m-d"),
                    'status' => "Y",
                    'shift_report_id' => $shiftReport->id,
                    'employee_id' => $findManager->id,
                    'employeeid' => $findManager->emp_id,
                    'employee_name' => $findManager->name,
                    'employee_phone' => $findManager->phone_number,
                    'employee_email' => $findManager->email,
                    'is_manager' => 1,
                ]);

                foreach ($request->assign_employee as $empVal) {
                    if ($empVal != "" && $empVal > 0) {
                        $findEachEmployee = Employees::select('employees.id', 'employees.emp_id', 'employees.name', 'employees.phone_number', 'users.email')
                            ->where('employees.id', $empVal)
                            ->join('users', 'users.id', '=', 'employees.user_id')
                            ->first();

                        ShiftEmployees::create([
                            'employee_id' => $findEachEmployee->id,
                            'employeeid' => $findEachEmployee->emp_id,
                            'employee_name' => $findEachEmployee->name,
                            'employee_phone' => $findEachEmployee->phone_number,
                            'employee_email' => $findEachEmployee->email,
                            'shift_report_id' => $shiftReport->id,
                            'is_manager' => 0,
                        ]);
                    }
                }

                return redirect()->to('shift-report/' . $shiftReport->id . '/edit')->with('message', 'Shift updated successfully.');
            } else {
                return redirect()->to('/')->with('message', 'Shift Not Exist');
            }
        } else {
            return redirect()->to('/')->with('message', 'You are not authorized to view this record.');
        }
    }

    //Calucation of the matrix data
    public function calculateMatrix(Request $request)
    {
        if (Auth::user()->type == 3) {
            if ($request->reservoir_id && $request->reservoir_id != "" && $request->height !== 0) {
                $findMatrix = MainMatrixCalculations::where('reservoir_id', $request->reservoir_id)
                    ->where('valid_through', '>=', now())
                    ->where('issued_date', '<=', now())
                    ->first();

                if ($findMatrix) {
                    $heightArr = explode(".", $request->height);

                    $findSubMatrix = SubMatrixCalculations::where('main_matrix_calculation_id', $findMatrix->id)
                        ->where('height', $heightArr[0])
                        ->first();

                    if ($findSubMatrix) {
                        $pointMatrix = 0;
                        if (isset($heightArr[1]) && $heightArr[1] !== "") {
                            $num = "." . $heightArr[1];
                            $reqVal = $num * 10;
                            $data['point_matrix'] = $pointMatrix = $reqVal * $findSubMatrix->volumn_ml;
                        }
                        $data['volumn_liter'] = $findSubMatrix->volumn_liter;
                        $data['sum_val'] = $sumVal = $findSubMatrix->volumn_liter + $pointMatrix;
                        $totalMatrix = $sumVal * 1000;
                        $data['total_matrix'] = number_format($totalMatrix, 2, ".", "");
                        $data['msg'] = 'success';
                        $data['success'] = 'Matrix data avaliable';
                    } else {
                        $data['msg'] = 'No matrix calculation data found.';
                    }
                } else {
                    $data['msg'] = 'No matrix data found.';
                }
            } else {
                $data['msg'] = 'Some data missing.';
            }
        } else {
            $data['msg'] = 'You are not authorized to view this record.';
        }
        echo json_encode($data);
    }

    //Store the tank reading records
    public function tankReading(Request $request)
    {
        if ($request->fuel_in_cm) {

            $shiftTankReadigsExist = ShiftTankReadings::where('shift_report_id', $request->shift_report_id)->exists();

            if ($shiftTankReadigsExist == 1) {
                foreach ($request->fuel_in_cm as $key => $value) {
                    if ($value != '') {
                        $reservoirs = Reservoirs::select()->where('id', $value)->get()->toArray();
                        $userId = Auth::user()->id;
                        $reservoirs = DB::table('reservoirs')
                            ->join('petrol_types', 'petrol_types.id', '=', 'reservoirs.petrol_type_id')
                            ->select('reservoirs.*', 'petrol_types.petrol_type_en', 'petrol_types.petrol_type_ru', 'petrol_types.petrol_type_tu')
                            ->where('reservoirs.user_id', $userId)
                            ->where('reservoirs.id', $key)
                            ->where('reservoirs.status', '1')
                            ->get();

                        ShiftTankReadings::where('shift_report_id', $request->shift_report_id)->where('reservoir_id', $key)->update([
                            'reservoir_name' => $reservoirs[0]->reservoir_type_en . "#@@#" . $reservoirs[0]->reservoir_type_ru . "#@@#" . $reservoirs[0]->reservoir_type_tu,
                            'petrol_typeid' => $reservoirs[0]->petrol_type_id,
                            'petrol_type_name' => $reservoirs[0]->petrol_type_en . "#@@#" . $reservoirs[0]->petrol_type_ru . "#@@#" . $reservoirs[0]->petrol_type_tu,
                            'start_shift_height' => $value,
                            'start_shift_fuel' => $request->fuel_in_liter[$key],
                        ]);
                    }
                }
            } else {

                ShiftReport::where('id', $request->shift_report_id)->update(array('is_step2_complete' => 1));
                foreach ($request->fuel_in_cm as $key => $value) {
                    if ($value != '') {
                        $reservoirs = Reservoirs::select()->where('id', $value)->get()->toArray();
                        $userId = Auth::user()->id;
                        $reservoirs = DB::table('reservoirs')
                            ->join('petrol_types', 'petrol_types.id', '=', 'reservoirs.petrol_type_id')
                            ->select('reservoirs.*', 'petrol_types.petrol_type_en', 'petrol_types.petrol_type_ru', 'petrol_types.petrol_type_tu')
                            ->where('reservoirs.user_id', $userId)
                            ->where('reservoirs.id', $key)
                            ->where('reservoirs.status', '1')
                            ->get();

                        ShiftTankReadings::create([
                            'creation_date' => date("Y-m-d"),
                            'reading_type' => 'S',
                            'remark' => '',
                            'shift_report_id' => $request->shift_report_id,
                            'reservoir_id' => $key,
                            'reservoir_name' => $reservoirs[0]->reservoir_type_en . "#@@#" . $reservoirs[0]->reservoir_type_ru . "#@@#" . $reservoirs[0]->reservoir_type_tu,
                            'petrol_typeid' => $reservoirs[0]->petrol_type_id,
                            'petrol_type_name' => $reservoirs[0]->petrol_type_en . "#@@#" . $reservoirs[0]->petrol_type_ru . "#@@#" . $reservoirs[0]->petrol_type_tu,
                            'start_shift_height' => $value,
                            'start_shift_fuel' => $request->fuel_in_liter[$key],
                        ]);
                    }
                }
            }
        }

        if ($request->bottled_oil_qty) {
            $shiftBottledOilReadings = ShiftBottledOilReadings::where('shift_report_id', $request->shift_report_id)->exists();
            if ($shiftBottledOilReadings == 1) {
                foreach ($request->bottled_oil_qty as $key => $value) {
                    if ($value != '') {
                        $bottledOilTypes = BottledOilType::where('id', $key)->get();

                        ShiftBottledOilReadings::where('shift_report_id', $request->shift_report_id)->where('bottled_oil_type_id', $bottledOilTypes[0]->id)->update([
                            'start_shift_quantity' => $value,
                        ]);
                    }
                }
            } else {
                foreach ($request->bottled_oil_qty as $key => $value) {
                    if ($value != '') {
                        $bottledOilTypes = BottledOilType::where('id', $key)->get();

                        ShiftBottledOilReadings::create([
                            'creation_date' => date("Y-m-d"),
                            'remark' => '',
                            'shift_report_id' => $request->shift_report_id,
                            'bottled_oil_type_id' => $bottledOilTypes[0]->id,
                            'bottled_oil_title' => $bottledOilTypes[0]->bottled_oil_en . "#@@#" . $bottledOilTypes[0]->bottled_oil_ru . "#@@#" . $bottledOilTypes[0]->bottled_oil_tu,
                            'bottled_oil_volumn' => $bottledOilTypes[0]->volumn,
                            'start_shift_quantity' => $value,
                        ]);
                    }
                }
            }
        }

        if ($request->end_fuel_in_cm && $request->end_fuel_in_liter) {
            
            ShiftReport::where('id', $request->shift_report_id)->update(array('is_step6_complete' => 1));
            
            $endFuelInLiter =  $request->end_fuel_in_liter;
            foreach ($request->end_fuel_in_cm as $fuelKey => $fuelVal) {
                ShiftTankReadings::where('id', $fuelKey)->update([
                    'end_shift_height' => $fuelVal,
                    'end_shift_fuel' => $endFuelInLiter[$fuelKey]
                ]);
            }
        }

        if($request->end_botled_oil_quantity){
            foreach ($request->end_botled_oil_quantity as $oil_key => $oil_val) {
                ShiftBottledOilReadings::where('id',$oil_key)->update([
                    'end_shift_quantity'  => $oil_val,
                ]);
            }
        }
        return response()->json([
            'status' => 'success',
            'message' => 'Shift Tank Readings created successfully'
        ], 200);
    }
    
    //Store the pump reading records
    public function pumpReading(Request $request)
    {
        foreach ($request->fuel_in_cm as $key => $value) {
            if ($value != '') {
                $userId = Auth::user()->id;

                $findPetrolPump =  PetrolPumps::select('petrol_pumps.*', 'petrol_types.type_code', 'petrol_types.petrol_type_en', 'petrol_types.petrol_type_ru', 'petrol_types.petrol_type_tu', 'petrol_types.status')
                    ->join('petrol_types', 'petrol_types.id', '=', 'petrol_pumps.petrol_type_id')
                    ->where('petrol_pumps.user_id', $userId)
                    ->where('petrol_pumps.id', $key)
                    ->where('petrol_pumps.status', '1')
                    ->get();

                $shiftPumpReadings = ShiftPumpReadings::where('shift_report_id', $request->shift_report_id)->where('petrol_pump_id', $findPetrolPump[0]->id)->exists();

                if ($shiftPumpReadings == 1) {
                    ShiftPumpReadings::where('shift_report_id', $request->shift_report_id)->where('petrol_pump_id', $findPetrolPump[0]->id)->update([
                        'start_reading' => $value,
                    ]);
                } else {
                    
                    ShiftReport::where('id', $request->shift_report_id)->update(array('is_step3_complete' => 1));

                    ShiftPumpReadings::create([
                        'creation_date' => date("Y-m-d"),
                        'remark' => '',
                        'shift_report_id' => $request->shift_report_id,
                        'reservoir_id' => $findPetrolPump[0]->reservoir_id,
                        'petrol_pump_id' => $findPetrolPump[0]->id,
                        'pumpid' => $findPetrolPump[0]->pumpid,
                        'pump_name' => $findPetrolPump[0]->pump_name_en . "#@@#" . $findPetrolPump[0]->pump_name_ru . "#@@#" . $findPetrolPump[0]->pump_name_tu,
                        'petrol_typeid' => $findPetrolPump[0]->petrol_type_id,
                        'petrol_type_name' => $findPetrolPump[0]->petrol_type_en . "#@@#" . $findPetrolPump[0]->petrol_type_ru . "#@@#" . $findPetrolPump[0]->petrol_type_tu,
                        'start_reading' => $value,
                    ]);
                }
            }
        }

        return response()->json([
            'status' => 'success',
            'message' => 'Shift Pump Readings created successfully'
        ], 200);
    }

    //Store the shift filling reading records
    public function shiftFillingReadings(Request $request)
    {
        if ($request->filled_reservoir) {
            $employees = Employees::where('id', $request->rdc_user_id)->first();
            $userId = Auth::user()->id;

            $petrolTypes = PetrolTypes::where('id', $request->add_filling_petrol_typeid)->first();

            $findReservoirs = Reservoirs::whereIn('id', $request->filled_reservoir)->get();

            $filledInReservoirName = [];
            if ($findReservoirs) {
                foreach ($findReservoirs as $key => $value) {
                    $filledInReservoirName[] = $value->reservoir_type_en . "#@@#" . $value->reservoir_type_ru . "#@@#" . $value->reservoir_type_tu;
                }
            }
            if ($employees != '' && $petrolTypes != '') {
               
                    ShiftFillingReadings::create([
                        'shift_report_id' => $request->shift_report_id,
                        'user_id' => $userId,
                        'petrol_typeid' => $petrolTypes->id,
                        'petrol_type_name' => $petrolTypes->petrol_type_en . "#@@#" . $petrolTypes->petrol_type_ru . "#@@#" . $petrolTypes->petrol_type_tu,
                        'rdc_user_id' => $request->rdc_user_id,
                        'rdc_employee_id' => $employees->id,
                        'rdc_organization_name' => $employees->organization_name,
                        'rdc_organization_phone' => $employees->organization_phone,
                        'rdc_organization_address' => $employees->organization_address,
                        'filling_doc_number' => $request->filling_doc_number,
                        'filling_delivery_doc_date' => date('Y-m-d', strtotime($request->filling_delivery_doc_date)),
                        'filling_delivery_date' => date('Y-m-d', strtotime($request->filling_delivery_date)),
                        'filling_vehicle_plate_number' => $request->filling_vehicle_plate_number,
                        'filling_volumn' => $request->filling_volumn,
                        'filling_ppd_value' => $request->filling_ppd_value,
                        'feeling_temperature' => $request->feeling_temperature,
                        'filling_mass' => $request->filling_mass,
                        'filled_in_reservoir' => "," . implode(",", $request->filled_reservoir) . ",",
                        'filled_in_reservoir_name' => json_encode($filledInReservoirName),
                    ]);

                return response()->json([
                    'status' => 'success',
                    'message' => 'Shift Filling Readings created successfully'
                ], 200);
            }
        }
    }

    //Store the shift bottled oil filling readings records
    public function shiftBottledOilFillingReadings(Request $request)
    {
         if (Auth::user()->sub_emp_id == 0) {
            $userId = Auth::user()->id;
        } else {
            $userId = Auth::user()->sub_emp_id;
        }

        if ($request->filling_quantity) {

            foreach ($request->filling_quantity as $key => $val) {

                if ($val != "" && $val > 0) {

                    $bottledOilTypes = BottledOilType::where('id', $key)->get();
                    $employees = Employees::where('id', $request->rdc_user_id)->get();

                    if ($bottledOilTypes != '' && $employees != '') {
                        ShiftBottledOilFillingReadings::create([
                            'shift_report_id' => $request->shift_report_id,
                            'user_id' => $userId,
                            'bottled_oil_type_id' => $bottledOilTypes[0]->id,
                            'bottled_oil_type_name' => $bottledOilTypes[0]->bottled_oil_en . "#@@#" . $bottledOilTypes[0]->bottled_oil_ru . "#@@#" . $bottledOilTypes[0]->bottled_oil_tu,
                            'bottled_oil_volumn' => $bottledOilTypes[0]->volumn,
                            'bottled_oil_price' => $bottledOilTypes[0]->price,
                            'rdc_user_id' => $employees[0]->user_id,
                            'rdc_employee_id' => $employees[0]->id,
                            'rdc_organization_name' => $employees[0]->organization_name,
                            'rdc_organization_phone' => $employees[0]->organization_phone,
                            'rdc_organization_address' => $employees[0]->organization_address,
                            'filling_doc_number' => $request->filling_doc_number,
                            'filling_delivery_doc_date' =>  date('Y-m-d', strtotime($request->filling_delivery_doc_date)),
                            'filling_delivery_date' => date('Y-m-d', strtotime($request->filling_delivery_date)),
                            'filling_vehicle_plate_number' => $request->filling_vehicle_plate_number,
                            'filling_quantity' => $val,
                            'feeling_temperature' =>  " ",
                            'filling_mass' => " ",
                        ]);

                        $findExistingBottledOilReadingDetails = ShiftBottledOilReadings::where('shift_report_id', $request->shift_report_id)
                            ->where('bottled_oil_type_id', $bottledOilTypes[0]->id)
                            ->first();

                        if ($findExistingBottledOilReadingDetails) {
                            $findTotalAddedQuantity = ShiftBottledOilFillingReadings::where('shift_report_id', '=', $request->shift_report_id)
                                ->where('bottled_oil_type_id', '=', $bottledOilTypes[0]->id)
                                ->selectRaw('SUM(filling_quantity) as total_sum')
                                ->first();

                            $fillingQuantity =  [];
                            $total = $findExistingBottledOilReadingDetails->start_shift_quantity;
                            if ($findTotalAddedQuantity->total_sum > 0) {
                                $filledQuantity = $findTotalAddedQuantity->total_sum;
                                $fillingQuantity[] = $filledQuantity;
                                $updateDataFillingQuantity = json_encode($fillingQuantity);
                                $total = $total + $filledQuantity;
                                $updateDataPresentQuantity = $total;
                            } else {
                                $updateDataFillingQuantity = NULL;
                                $updateDataPresentQuantity = "0";
                            }

                            ShiftBottledOilReadings::where('shift_report_id', $request->shift_report_id)
                                ->where('bottled_oil_type_id', $bottledOilTypes[0]->id)
                                ->update([
                                    'filling_quantity' => $updateDataFillingQuantity,
                                    'present_quantity' => $updateDataPresentQuantity,
                                ]);
                        }
                    }
                }
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Shift Bottled Oil Readings created successfully'
            ], 200);
        }
    }

    //Store the shift end pump readings records
    public function shiftEndPumpReadings(Request $request)
    {
        if ($request->end_pump_reading) {
            foreach ($request->end_pump_reading as $end_pump_key => $end_pump_val) {
                $getShiftPumpReadings = ShiftPumpReadings::where('shift_report_id', $request->shift_report_id)->where('id', $end_pump_key)->get();
                if ($getShiftPumpReadings) {
                    if (isset($getShiftPumpReadings[0]->reservoir_id) && $getShiftPumpReadings[0]->reservoir_id > 0) {
                        ShiftPumpReadings::where('shift_report_id', $request->shift_report_id)->where('id', $end_pump_key)->update([
                            'end_reading' => $end_pump_val,
                            'total_sales' => $end_pump_val - $getShiftPumpReadings[0]->start_reading,
                        ]);
                    }
                }
            }
            return response()->json([
                'status' => 'success',
                'message' => 'Shift End Pump Readings created successfully'
            ], 200);
        }
    }

    //Passing the petrol types records
    public function createSalesData(Request $request)
    {

        if ($request->ajax()) {
            $petrolTypes = PetrolTypes::select('id', 'petrol_type_en', 'petrol_type_ru', 'petrol_type_tu')->where('status', 'Y')->get();
    
            $findReservoirPetrolType = findReservoirPetrolType($request->user_id);
                $petrolTypeIdArr = [];
                if ($findReservoirPetrolType != "") {
                    $petrolTypeIdArr = explode(",", $findReservoirPetrolType);
                }
    
            /*petrol type data*/
            $defaultLanguage = get_default_language();
            if($petrolTypes){
                foreach ($petrolTypes as $petrolTypeKey => $petrolTypeVal) {

                    if (in_array($petrolTypeVal['id'], $petrolTypeIdArr)) {
                        $petrolTypeName = 'petrol_type_' . $defaultLanguage;
                        $findPetrolPrice = petrolPrice($petrolTypeVal['id']);
                        $salesSetrolType[$petrolTypeVal['id']] = [
                            'text' => $petrolTypeVal[$petrolTypeName],
                            'value' => $petrolTypeVal['id'],
                            'data_petrol_price' =>  isset($findPetrolPrice->price)  ? $findPetrolPrice->price : '0'
                        ];
                    }
                }
            }
            if($petrolTypes){
                foreach ($petrolTypes as $key => $val) {
                    $find_total_sold_liter_per_petrol_type = findTotalSoldLiterPerPetrolType($val['id'], $request->shift_report_id);
                    $find_already_added_total_sold_liter_per_petrol_type = findAlreadyAddedTotalSoldLiterPerPetrolType($val['id'], $request->shift_report_id);
        
                    $labelsData[] = array(
                        "id" => $val['id'],
                        "total_sold" => $find_total_sold_liter_per_petrol_type,
                        "total_added_sales" => $find_already_added_total_sold_liter_per_petrol_type,
                        "total_sold_as_per_amt" => 0
                    );
                }
            }
            /* Voucher Data */
            $voucher_volumn = ["5", "10", "15"];
            if ($request->voucher_volumes != "") {
                $voucher_volumn = explode(",", $request->voucher_volumes);
            }
            $voucher_volumn = array_combine($voucher_volumn, $voucher_volumn);
            $i = 0;
            
            foreach ($request->voucher_types as $pv_key => $pv_val) {
    
                $volumeArr = array();
                foreach ($voucher_volumn as  $vv_key => $vv_val) {
                    $i++;
                    $volumeArr[] = $vv_val;
                }
                $paymentVoucherData[] = array(
                    "payment_voucher_key" => $pv_key,
                    "payment_voucher_val" =>  __($pv_val),
                    'volume_data' => $volumeArr
                );
            }
            
            $data['msg'] = "success";
            $data['sales_petrol_type'] = $salesSetrolType;
            $data['labelsData'] = $labelsData;
            $data['paymentVoucherData'] = $paymentVoucherData;
        }else {
            $data['msg'] = "Request not allowed. Please, try again.";
        }

        return response()->json([
            'status' => 'success',
            'data' => $data,
        ], 200);

    }

    //Fetched the Payment terminals records
    public function shiftPumpBank(Request $request)
    {

        if (Auth::user()->type == 3) {
            if ($request->sales_petrol_type != "") {
                /*userId*/
                $userId = Auth::user()->id;
                if (Auth::user()->sub_emp_id > 0) {
                    $userId = Auth::user()->sub_emp_id;
                }

                $findTerminal = PaymentTerminals::where('payment_terminals.user_id', $userId)
                ->whereRaw('CONCAT(",", petrol_types, ",") LIKE ?', ["%,$request->sales_petrol_type,%"])
                ->where('payment_terminals.status', 'Y')
                ->orderBy('payment_terminals.bank_id', 'ASC')
                ->orderBy('payment_terminals.terminal_name', 'ASC')
                ->join('banks', 'payment_terminals.bank_id', '=', 'banks.id')
                ->select('payment_terminals.*','banks.bank_name')
                ->get();

                $bankVal = array();
                if($findTerminal){
                    foreach ($findTerminal as $key => $value) {
    
                        $bankVal[$value->bank_name][] = array(
                            'id' => $value->id,
                            'bank_id' => $value->bank_id,
                            'terminal_name' => $value->terminal_name,
                            'terminal_number' => $value->terminal_number
                        );
                    }
                }
                $shiftReportId = $request->shift_report_id;
                $salesPetrolType = $request->sales_petrol_type;

                return response()->json(compact('bankVal', 'shiftReportId', 'salesPetrolType'));
            } else {
                echo "msg@@@".__('Some data missing.');
            }
        } else {
            echo "msg@@@" . __('You are not authorized to view this record.');
        }
    }

    //Store the Shift bottled oil sales records
    public function shiftbottledOilSales(Request $request)
    {
        if (Auth::user()->type == 3) {
            if ($request->shift_report_id != "") {

                if (Auth::user()->sub_emp_id == 0) {
                    $userId = Auth::user()->id;
                } else {
                    $userId = Auth::user()->idsub_emp_id;
                }

                $shiftReport = ShiftReport::where('id', $request->shift_report_id)->where('user_id', $userId)->first();
                if ($shiftReport) {

                    $findBottledOilType = BottledOilType::where('id', $request->bottled_oil_type_id)->first();
                    if ($findBottledOilType) {

                        $findEmployee = ShiftEmployees::where('shift_report_id', $shiftReport->id)->where('employee_id', $request->employee_id)->first();
                        if ($findEmployee) {

                            $shiftBottledOilSales =  ShiftBottledOilSales::create([
                                'shift_report_id' => $shiftReport->id,
                                'employee_id' => $request->employee_id,
                                'employeeid' => $findEmployee->employeeid,
                                'employee_name' => $findEmployee->employee_name,
                                'bottled_oil_type_id' => $request->bottled_oil_type_id,
                                'bottle_type' => $findBottledOilType->bottled_oil_en . "#@@#" . $findBottledOilType->bottled_oil_ru . "#@@#" . $findBottledOilType->bottled_oil_tu,
                                'volumn' => $findBottledOilType->volumn,
                                'amount_received' => $request->amount_received,
                                'each_bottle_price' => $findBottledOilType->price,
                                'service_charge' => $request->service_charge,
                                'calculated_quantity' => floor(($request->amount_received / $findBottledOilType->price)),
                                'payment_method' => $request->payment_method,
                                'remark' => $request->sales_remarks,
                                'creation_date' => date("Y-m-d"),
                            ]);

                            if ($shiftBottledOilSales) {
                                $data['msg'] = "success";
                                $data['success'] = 'The shift bottle oil sale has been saved.';
                            } else {
                                $data['msg'] = 'The record could not be saved.';
                            }
                        } else {
                            $data['msg'] = __('No employee found.');
                        }
                    } else {
                        $data['msg'] = __('Invalid bottled oil id id.');
                    }
                } else {
                    $data['msg'] = __('You are not authorized to add/edit this record.');
                }
            } else {
                $data['msg'] = __('Some data missing. Please, try again.');
            }
        } else {
            $data['msg'] = __('Some data missing. Please, try again.');
        }

        return response()->json([
            'status' => 'success',
            'data' => $data,
        ], 200);
    }

    //Fetched the Shift filling readings records
    public function shiftFillingReadingsEdit(Request $request)
    {
        $shiftFillingReadings = ShiftFillingReadings::where('id', $request->shift_filling_id)->first();

        $shiftFillingReadingsdata = array(
            'shift_filling_readings_id' => $shiftFillingReadings->id,
            'filling_doc_number' => $shiftFillingReadings->filling_doc_number,
            'filling_delivery_doc_date' =>  date('d-m-Y', strtotime($shiftFillingReadings->filling_delivery_doc_date)),
            'filling_delivery_date' =>  date('d-m-Y', strtotime($shiftFillingReadings->filling_delivery_date)),
            'filling_vehicle_plate_number' => $shiftFillingReadings->filling_vehicle_plate_number,
            'filling_volumn' => $shiftFillingReadings->filling_volumn,
            'filling_ppd_value' => $shiftFillingReadings->filling_ppd_value,
            'feeling_temperature' => $shiftFillingReadings->feeling_temperature,
            'filling_mass' => $shiftFillingReadings->filling_mass,
            'rdc_user_id' => $shiftFillingReadings->rdc_user_id,
            'petrol_typeid' => $shiftFillingReadings->petrol_typeid,
            'filled_in_reservoir' => $shiftFillingReadings->filled_in_reservoir,
        );
        return response()->json([
            'status' => 'success',
            'data' => $shiftFillingReadingsdata
        ], 200);
    }

    //Update the Shift filling readings records
    public function shiftFillingReadingsUpdate(Request $request)
    {
        
        if ($request->filled_reservoir) {

            $employees = Employees::where('id', $request->rdc_user_id)->first();
            $userId = Auth::user()->id;
            $petrolTypes = PetrolTypes::where('id', $request->add_filling_petrol_typeid)->first();
            $findReservoirs = Reservoirs::whereIn('id', $request->filled_reservoir)->get();
            $filledInReservoirName = [];

            if ($findReservoirs) {
                foreach ($findReservoirs as $key => $value) {
                    $filledInReservoirName[] = $value->reservoir_type_en . "#@@#" . $value->reservoir_type_ru . "#@@#" . $value->reservoir_type_tu;
                }
            }

            if ($employees != '' && $petrolTypes != '') {
               
                ShiftFillingReadings::where('id', $request->shift_filling_readings_id)->where('shift_report_id', $request->shift_report_id)->update([
                    'user_id' => $userId,
                    'petrol_typeid' => $petrolTypes->id,
                    'petrol_type_name' => $petrolTypes->petrol_type_en . "#@@#" . $petrolTypes->petrol_type_ru . "#@@#" . $petrolTypes->petrol_type_tu,
                    'rdc_user_id' => $request->rdc_user_id,
                    'rdc_employee_id' => $employees->id,
                    'rdc_organization_name' => $employees->organization_name,
                    'rdc_organization_phone' => $employees->organization_phone,
                    'rdc_organization_address' => $employees->organization_address,
                    'filling_doc_number' => $request->filling_doc_number,
                    'filling_delivery_doc_date' => date('Y-m-d', strtotime($request->filling_delivery_doc_date)),
                    'filling_delivery_date' => date('Y-m-d', strtotime($request->filling_delivery_date)),
                    'filling_vehicle_plate_number' => $request->filling_vehicle_plate_number,
                    'filling_volumn' => $request->filling_volumn,
                    'filling_ppd_value' => $request->filling_ppd_value,
                    'feeling_temperature' => $request->feeling_temperature,
                    'filling_mass' => $request->filling_mass,
                    'filled_in_reservoir' => "," . implode(",", $request->filled_reservoir) . ",",
                    'filled_in_reservoir_name' => json_encode($filledInReservoirName),
                ]);

                return response()->json([
                    'status' => 'success',
                    'message' => 'Shift Filling Readings updated successfully'
                ], 200);
            }
        }
    }
    
    //Fetched the Shift bottled oil filling reading records
    public function shiftBottledOilFillingReadingsEdit(Request $request)
    {
        $shiftBottledOilFillingReadings = ShiftBottledOilFillingReadings::where('id', $request->shift_bottled_oil_filling_readings_id)->first();
        
        $shiftBottledOilFillingReadingsData = array(
            'shift_bottled_oil_filling_id' => $shiftBottledOilFillingReadings->id,
            'filling_delivery_doc_date' =>  date('d-m-Y', strtotime($shiftBottledOilFillingReadings->filling_delivery_doc_date)),
            'filling_delivery_date' => date('d-m-Y', strtotime($shiftBottledOilFillingReadings->filling_delivery_date)),
            'filling_doc_number' => $shiftBottledOilFillingReadings->filling_doc_number,
            'filling_vehicle_plate_number' => $shiftBottledOilFillingReadings->filling_vehicle_plate_number,
            'rdc_user_id' => $shiftBottledOilFillingReadings->rdc_employee_id,
            'filling_quantity' => $shiftBottledOilFillingReadings->filling_quantity,
            'bottled_oil_type_id' => $shiftBottledOilFillingReadings->bottled_oil_type_id,
        );

        return response()->json(
            [
                'status' => 'success',
                'data' => $shiftBottledOilFillingReadingsData
            ],
            200
        );
    }

    //Update the Shift bottled oil filling reading records
    public function shiftBottledOilFillingReadingsUpdate(Request $request)
    {
        if (Auth::user()->sub_emp_id == 0) {
            $userId = Auth::user()->id;
        } else {
            $userId = Auth::user()->sub_emp_id;
        }

        if ($request->filling_quantity) {

            foreach ($request->filling_quantity as $key => $val) {

                if ($val != "" && $val > 0) {

                    $bottledOilTypes = BottledOilType::where('id', $key)->get();
                    $employees = Employees::where('id', $request->rdc_user_id)->get();

                    if ($bottledOilTypes != '' && $employees != '') {

                        ShiftBottledOilFillingReadings::where('id', $request->shift_bottled_oil_filling_id)->where('shift_report_id', $request->shift_report_id)->update([
                            'user_id' => $userId,
                            'bottled_oil_type_id' => $bottledOilTypes[0]->id,
                            'bottled_oil_type_name' => $bottledOilTypes[0]->bottled_oil_en . "#@@#" . $bottledOilTypes[0]->bottled_oil_ru . "#@@#" . $bottledOilTypes[0]->bottled_oil_tu,
                            'bottled_oil_volumn' => $bottledOilTypes[0]->volumn,
                            'bottled_oil_price' => $bottledOilTypes[0]->price,
                            'rdc_user_id' => $employees[0]->user_id,
                            'rdc_employee_id' => $employees[0]->id,
                            'rdc_organization_name' => $employees[0]->organization_name,
                            'rdc_organization_phone' => $employees[0]->organization_phone,
                            'rdc_organization_address' => $employees[0]->organization_address,
                            'filling_doc_number' => $request->filling_doc_number,
                            'filling_delivery_doc_date' =>  date('Y-m-d', strtotime($request->filling_delivery_doc_date)),
                            'filling_delivery_date' => date('Y-m-d', strtotime($request->filling_delivery_date)),
                            'filling_vehicle_plate_number' => $request->filling_vehicle_plate_number,
                            'filling_quantity' => $val,
                            'feeling_temperature' =>  " ",
                            'filling_mass' => " ",
                        ]);

                        $findExistingBottledOilReadingDetails = ShiftBottledOilReadings::where('shift_report_id', $request->shift_report_id)
                            ->where('bottled_oil_type_id', $bottledOilTypes[0]->id)
                            ->first();

                        if ($findExistingBottledOilReadingDetails) {
                            $findTotalAddedQuantity = ShiftBottledOilFillingReadings::where('shift_report_id', '=', $request->shift_report_id)
                                ->where(
                                    'bottled_oil_type_id',
                                    '=',
                                    $bottledOilTypes[0]->id
                                )
                                ->selectRaw('SUM(filling_quantity) as total_sum')
                                ->first();

                            $fillingQuantity =  [];
                            $total = $findExistingBottledOilReadingDetails->start_shift_quantity;
                            if (
                                $findTotalAddedQuantity->total_sum > 0
                            ) {
                                $filledQuantity = $findTotalAddedQuantity->total_sum;
                                $fillingQuantity[] = $filledQuantity;
                                $updateDataFillingQuantity = json_encode($fillingQuantity);
                                $total = $total + $filledQuantity;
                                $updateDataPresentQuantity = $total;
                            } else {
                                $updateDataFillingQuantity = NULL;
                                $updateDataPresentQuantity = "0";
                            }

                            ShiftBottledOilReadings::where('shift_report_id', $request->shift_report_id)
                                ->where('bottled_oil_type_id', $bottledOilTypes[0]->id)
                                ->update([
                                    'filling_quantity' => $updateDataFillingQuantity,
                                    'present_quantity' => $updateDataPresentQuantity,
                                ]);
                        }
                        return response()->json([
                            'status' => 'success',
                            'message' => 'Shift Bottled Oil Readings updated successfully'
                        ], 200);
                    }
                }
            }
            // exit();
        }
    }

    //Update the is_step4_complete in shift report table
    public function fillingUpPetrol(Request $request)
    {
        ShiftReport::where('id', $request->shift_report_id)->update(array('is_step4_complete' => 1));

        return response()->json([
            'status' => 'success',
            'message' => 'The shift report has been saved.'
        ], 200);
    }

    //Fetched the Shift bottled oil sales records
    public function shiftbottledOilSalesEdit(Request $request)
    {
        $shiftbottledOilSalesEdit = ShiftBottledOilSales::where('id',$request->shift_bottled_oil_sales_id)->where('shift_report_id',$request->shift_report_id)->first();

        $shiftbottledOilSalesData = array(

            'employee_id' => $shiftbottledOilSalesEdit->employee_id,
            'bottled_oil_type_id' => $shiftbottledOilSalesEdit->bottled_oil_type_id,
            'amount_received' => $shiftbottledOilSalesEdit->amount_received,
            'service_charge' => $shiftbottledOilSalesEdit->service_charge,
            'payment_method' => $shiftbottledOilSalesEdit->payment_method,
            'remark' => $shiftbottledOilSalesEdit->remark,
        );

        return response()->json([
                'status' => 'success',
                'data' => $shiftbottledOilSalesData
            ],200
        );
    }

    //Update the Shift bottled oil sales records
    public function shiftbottledOilSalesUpdate(Request $request)
    {
        if (Auth::user()->type == 3) {
            if ($request->shift_report_id != "") {

                if (Auth::user()->sub_emp_id == 0) {
                    $userId = Auth::user()->id;
                } else {
                    $userId = Auth::user()->idsub_emp_id;
                }

                $shiftReport = ShiftReport::where('id', $request->shift_report_id)->where('user_id', $userId)->first();
                if ($shiftReport) {
                    $shiftBottledOilSaleData =  ShiftBottledOilSales::where('shift_report_id', $shiftReport->id,)->where('id', $request->shift_bottled_oil_sales_id)->first();
                    if ($shiftBottledOilSaleData) {
                        $findBottledOilType = BottledOilType::where('id', $request->bottled_oil_type_id)->first();
                        if ($findBottledOilType) {

                            $findEmployee = ShiftEmployees::where('shift_report_id', $shiftReport->id)->where('employee_id', $request->employee_id)->first();
                            if ($findEmployee) {

                                $shiftBottledOilSales =  ShiftBottledOilSales::where('shift_report_id', $shiftReport->id,)->where('id', $request->shift_bottled_oil_sales_id)->update([
                                    'employee_id' => $request->employee_id,
                                    'employeeid' => $findEmployee->employeeid,
                                    'employee_name' => $findEmployee->employee_name,
                                    'bottled_oil_type_id' => $request->bottled_oil_type_id,
                                    'bottle_type' => $findBottledOilType->bottled_oil_en . "#@@#" . $findBottledOilType->bottled_oil_ru . "#@@#" . $findBottledOilType->bottled_oil_tu,
                                    'volumn' => $findBottledOilType->volumn,
                                    'amount_received' => $request->amount_received,
                                    'each_bottle_price' => $findBottledOilType->price,
                                    'service_charge' => $request->service_charge,
                                    'calculated_quantity' => floor(($request->amount_received / $findBottledOilType->price)),
                                    'payment_method' => $request->payment_method,
                                    'remark' => $request->remark,
                                ]);

                                if ($shiftBottledOilSales) {
                                    $data['msg'] = "success";
                                    $data['success'] = 'The shift bottle oil sale has been updated.';
                                } else {
                                    $data['msg'] = 'The record could not be saved.';
                                }
                            } else {
                                $data['msg'] = __('No employee found.');
                            }
                        } else {
                            $data['msg'] = __('Invalid bottled oil id id.');
                        }
                    } else {
                        $data['msg'] = __('No record found with this report id and bottoled oil sales id.');
                    }
                } else {
                    $data['msg'] = __('You are not authorized to add/edit this record.');
                }
            } else {
                $data['msg'] = __('Some data missing. Please, try again.');
            }
        } else {
            $data['msg'] = __('Some data missing. Please, try again.');
        }

        return response()->json([
            'status' => 'success',
            'data' => $data,
        ], 200);
    }

    //Shift report listing
    public function listing()
    {
        return view('shiftreport.listing');
    }
    
    //Fetched the all shift report records
    public function listingData(Request $request)
    {
        if (request()->ajax()) {

            $startDate = $request->start_date;
            $endDate = $request->end_date;

            if (Auth::user()->sub_emp_id == 0) {
                $userId = Auth::user()->id;
            } else {
                $userId = Auth::user()->sub_emp_id;
            }

            $shiftReport = ShiftReport::where('user_id', $userId)
                ->where('shift_date', '>=', $startDate)
                ->where('shift_date', '<=', $endDate)
                ->orderBy('created', 'DESC')
                ->orderBy('modified', 'DESC')
                ->get();
                
            $data = array();
            foreach ($shiftReport as $skey => $shiftReportData) {

                $default_language = get_default_language();
                $shift_name = 'shift_name_' . $default_language;

                $shiftDate = date('d/m/Y', strtotime($shiftReportData->shift_date));

                if ($shiftReportData->shift_start_at_midnight == "Y" ||  $shiftReportData->shift_end_at_midnight == "Y") {
                    $cur_report_name = $shiftReportData->$shift_name != "" ? $shiftReportData->$shift_name : $shiftReportData->shift_name;
                    $report_name_arr = explode(" (", $cur_report_name);
                    $shiftDateTime = $report_name_arr[0] . " (" . date('H:i', strtotime($shiftReportData->shift_start_date_time)) . " - " . date('H:i', strtotime($shiftReportData->shift_end_date_time)) . ")";
                } else {
                    $shiftDateTime = $shiftReportData->$shift_name != "" ? $shiftReportData->$shift_name : $shiftReportData->shift_name;
                }

                $shiftCreateDate = $shiftReportData->created ? date('d/m/Y H:i:s', strtotime($shiftReportData->created)) : "-";
                $shiftEditDate = $shiftReportData->modified ? date('d/m/Y H:i:s', strtotime($shiftReportData->modified)) : "-";

                $status = '';
                if ($shiftReportData->status == 'A') {
                    $status = __('messages.Approved');
                } elseif ($shiftReportData->status == 'C') {
                    $status = __('messages.Complete');
                } elseif ($shiftReportData->status == 'R') {
                    $status = __('messages.Rejected');
                } else {
                    $status = __('messages.Pending');
                }

                /* Get Admin Name */
                $created_admin = find_admin_name($shiftReportData->created_admin_id);
                $modified_admin = find_admin_name($shiftReportData->modified_admin_id);

                $action = '<a href="' . URL('shift-report/view/' . $shiftReportData->id) . '" class="btn btn-primary btn-circle btn-sm" title = "' . __('messages.View') . '" target="_blank"><i class="fas fa-eye"></i></a>';
                $action .= '<a onclick="openPrintWindow('.$shiftReportData->id.');" class="btn btn-secondary btn-circle btn-sm" title = "' . __('messages.Print V2 Report') . '" target="_blank"><i class="fas fa-print"></i></a>';

                if ($shiftReportData->status == 'A' || $shiftReportData->status == 'C') {
                    // do nothing
                } else {
                    $action .= '<a href="' . URL('shift-report/' . $shiftReportData->id) . '/edit" class="btn btn-warning btn-circle btn-sm" title = "' . __('messages.Edit') . '"><i class="fas fa-edit"></i></a>';
                }

                if (Auth::user()->type == 3) {
                    if (Auth::user()->sub_emp_id == 0) {
                        $action .= '<button class="btn btn-danger btn-circle btn-sm delete-record" title="Delete" data-module="shiftreport" data-id="'.$shiftReportData->id.'"><i class="fas fa-trash"></i></button>';
                    } elseif ($shiftReportData->status == 'P') {
                        $action .= '<button class="btn btn-danger btn-circle btn-sm delete-record" title="Delete" data-module="shiftreport" data-id="'.$shiftReportData->id.'"><i class="fas fa-trash"></i></button>';
                    }
                }

                $data[] = array(
                    'shift_id' => $shiftReportData->shiftid,
                    'shift_date_and_name' => $shiftDate . "<br>" . $shiftDateTime,
                    'created_date_time' => $shiftCreateDate,
                    'created_user' => $created_admin,
                    'updated_date_time' => $shiftEditDate,
                    'updated_user' => $modified_admin,
                    'approve_reject_comment' => $shiftReportData->comment,
                    'status' => $status,
                    'action' => $action
                );
            }

            return DataTables()->of($data)->make(true);
        }
    }

    //Shift report view as per Id
    public function shiftView($id)
    {
        $page_title = "EASY REPORT MANAGEMENT SYSTEM (E-RMS) - REPORT";
        if (Auth::user()->sub_emp_id == 0) {
            $userId = Auth::user()->id;
        } else {
            $userId = Auth::user()->sub_emp_id;
        }

        $shiftReport = ShiftReport::select('shift_report.*', 'employees.organization_name')
        ->join('employees', 'employees.id', '=', 'shift_report.employee_id')
        ->where('shift_report.user_id', $userId)
            ->where('shift_report.id', $id)
            ->first();

        if ($shiftReport) {

            $shiftTankReadings = ShiftTankReadings::select('petrol_typeid', 'petrol_type_name','shift_report_id')
            ->where('shift_report_id', $shiftReport->id)
            ->groupBy('petrol_typeid', 'petrol_type_name','shift_report_id')
            ->orderByRaw('MIN(petrol_type_name) ASC')
            ->get();
            
            $shiftBottledOilReadings = ShiftBottledOilReadings::select()
                ->where('shift_report_id', $shiftReport->id)
                ->get();

            $findVoucherData = ShiftPetrolSales::select('voucher_volumn')
            ->where('shift_report_id', $id)
            ->where('voucher_volumn', '>', 0)
            ->groupBy('voucher_volumn')
            ->orderBy('voucher_volumn', 'asc')
            ->limit(1000)
            ->pluck('voucher_volumn');

            $shiftmanager = ShiftEmployees::where('shift_report_id', $id)
            ->where('is_manager', 1)
            ->first();

            $findPetrolTypeData = DB::table('shift_pump_readings AS spr')
            ->select(
                DB::raw('MIN(spr.id) AS min_id, MAX(spr.id) AS max_id, MAX(spr.petrol_type_name) AS max_petrol_type_name, spr.petrol_typeid'),
            )
                ->where('spr.shift_report_id', $id)
                ->groupBy('spr.petrol_typeid')
                ->orderBy('max_petrol_type_name', 'ASC')
                ->limit(1000)
                ->get();

            $previousShiftmanager = null; 
            if ($shiftReport->last_report_id > 0) {
                $previousShiftReport = ShiftReport::where('id', $shiftReport->last_report_id)
                    ->where('user_id', $userId)
                    ->with('shiftEmployees')
                    ->first();

                if ($previousShiftReport) {
                    $previousShiftmanager = ShiftEmployees::where('shift_report_id', $previousShiftReport->id)
                        ->where('is_manager', 1)
                        ->first();

                    view()->share('previousShiftmanager', $previousShiftmanager);
                }
                view()->share('previousShiftReport', $previousShiftReport);
            }

            $shiftPaymentTerminalPetrolSales = ShiftPaymentTerminalPetrolSales::where('user_id', $userId)
                ->where('shift_report_id', $id)
                ->orderBy('shift_petrol_sale_id', 'ASC')
                ->get();

                // echo "<pre>";
                // print_r($shiftPaymentTerminalPetrolSales);
                // echo "</pre>";
                // exit();

            return view('shiftreport.view', compact('page_title','shiftReport', 'shiftTankReadings', 'shiftBottledOilReadings', 'findVoucherData', 'shiftmanager', 'findPetrolTypeData', 'previousShiftReport', 'previousShiftmanager','shiftPaymentTerminalPetrolSales'));
        }
    }

    //Shift report print as per Id
    public function shiftViewv2Report($id,$print = null)
    {
        
        $page_title = "EASY REPORT MANAGEMENT SYSTEM (E-RMS) - REPORT V2";
        if (Auth::user()->sub_emp_id == 0) {
            $userId = Auth::user()->id;
        } else {
            $userId = Auth::user()->sub_emp_id;
        }

        $shiftReport = ShiftReport::select('shift_report.*', 'employees.organization_name')
        ->join('employees', 'employees.id', '=', 'shift_report.employee_id')
        ->where('shift_report.user_id', $userId)
            ->where('shift_report.id', $id)
            ->first();

        if ($shiftReport) {

            $shiftTankReadings = ShiftTankReadings::select('petrol_typeid', 'petrol_type_name','shift_report_id')
            ->where('shift_report_id', $shiftReport->id)
            ->groupBy('petrol_typeid', 'petrol_type_name','shift_report_id')
            ->orderByRaw('MIN(petrol_type_name) ASC')
            ->get();
            
            $shiftBottledOilReadings = ShiftBottledOilReadings::select()
                ->where('shift_report_id', $shiftReport->id)
                ->get();

            $findVoucherData = ShiftPetrolSales::select('voucher_volumn')
            ->where('shift_report_id', $id)
            ->where('voucher_volumn', '>', 0)
            ->groupBy('voucher_volumn')
            ->orderBy('voucher_volumn', 'asc')
            ->limit(1000)
            ->pluck('voucher_volumn');

            $shiftmanager = ShiftEmployees::where('shift_report_id', $id)
            ->where('is_manager', 1)
            ->first();

            $findPetrolTypeData = DB::table('shift_pump_readings AS spr')
            ->select(
                DB::raw('MIN(spr.id) AS min_id, MAX(spr.id) AS max_id, MAX(spr.petrol_type_name) AS max_petrol_type_name, spr.petrol_typeid'),
            )
                ->where('spr.shift_report_id', $id)
                ->groupBy('spr.petrol_typeid')
                ->orderBy('max_petrol_type_name', 'ASC')
                ->limit(1000)
                ->get();

            $previousShiftmanager = null; 
            if ($shiftReport->last_report_id > 0) {
                $previousShiftReport = ShiftReport::where('id', $shiftReport->last_report_id)
                    ->where('user_id', $userId)
                    ->with('shiftEmployees')
                    ->first();
            
                if ($previousShiftReport) {
                    $previousShiftmanager = ShiftEmployees::where('shift_report_id', $previousShiftReport->id)
                        ->where('is_manager', 1)
                        ->first();

                        view()->share('previousShiftmanager', $previousShiftmanager);
                }
                view()->share('previousShiftReport', $previousShiftReport);
            }

            $shiftPaymentTerminalPetrolSales = ShiftPaymentTerminalPetrolSales::where('user_id', $userId)
                ->where('shift_report_id', $id)
                ->orderBy('shift_petrol_sale_id', 'ASC')
                ->get();

            return view('shiftreport.print', compact('page_title','shiftReport', 'shiftTankReadings', 'shiftBottledOilReadings', 'findVoucherData', 'shiftmanager', 'findPetrolTypeData', 'previousShiftReport', 'previousShiftmanager','shiftPaymentTerminalPetrolSales','print'));
        }
    }

    //Delete the Shift report record
    public function delete(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $record = ShiftReport::find($id);
            $shiftEmployees = ShiftEmployees::where('shift_report_id', $id)->get();
            $shiftTankReadings = ShiftTankReadings::where('shift_report_id', $id)->get();
            $shiftBottledOilReadings = ShiftBottledOilReadings::where('shift_report_id', $id)->get();
            $shiftPumpReadings = ShiftPumpReadings::where('shift_report_id', $id)->get();
            $shiftFillingReadings = ShiftFillingReadings::where('shift_report_id', $id)->get();
            $shiftBottledOilFillingReadings = ShiftBottledOilFillingReadings::where('shift_report_id', $id)->get();
            $shiftBottledOilSales = ShiftBottledOilSales::where('shift_report_id', $id)->get();

            if ($record && $shiftEmployees && $shiftTankReadings && $shiftBottledOilReadings && $shiftPumpReadings && $shiftFillingReadings && $shiftBottledOilFillingReadings && $shiftBottledOilSales) {
                
                $record->delete();

                foreach ($shiftEmployees as $shiftEmployeesRecords) {
                    $shiftEmployeesRecords->delete();
                }

                foreach ($shiftTankReadings as $shiftTankReadingsRecords) {
                    $shiftTankReadingsRecords->delete();
                }

                foreach ($shiftBottledOilReadings as $shiftBottledOilReadingsRecords) {
                    $shiftBottledOilReadingsRecords->delete();
                }

                foreach ($shiftPumpReadings as $shiftPumpReadingsRecords) {
                    $shiftPumpReadingsRecords->delete();
                }

                foreach ($shiftFillingReadings as $shiftFillingReadingsRecords) {
                    $shiftFillingReadingsRecords->delete();
                }

                foreach ($shiftBottledOilFillingReadings as $shiftBottledOilFillingReadingsRecords) {
                    $shiftBottledOilFillingReadingsRecords->delete();
                }

                foreach ($shiftBottledOilSales as $shiftBottledOilSalesRecords) {
                    $shiftBottledOilSalesRecords->delete();
                }
                
                DB::commit();

                return Response::json(['message' => 'Shift Report deleted successfully.']);
            } else {
                return Response::json(['message' => 'Shift Report not found.'], 404);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error($e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    //Delete the Shift Filling reading record 
    public function shiftFillingReadingDelete(Request $request, $id)
    {

        DB::beginTransaction();
        try {
            $record = ShiftFillingReadings::find($id);

            if ($record) {
                
                $record->delete();
                
                DB::commit();

                return Response::json(['message' => 'The shift filling record has been deleted.']);
            } else {
                return Response::json(['message' => 'Shift filling not found.'], 404);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error($e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    //Delete the Shift bottled oil filling reading delete record 
    public function shiftBottledOilFillingReadingDelete(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $record = ShiftBottledOilFillingReadings::find($id);

            if ($record) {
                
                $record->delete();
                
                DB::commit();

                return Response::json(['message' => 'The shift bottle oil filling reading record has been deleted.']);
            } else {
                return Response::json(['message' => 'Shift bottle oil filling reading record not found.'], 404);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error($e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    //Delete the Shift bottled oil sales delete record 
    public function shiftBottledOilSalesDelete(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $record = ShiftBottledOilSales::find($id);

            if ($record) {
                
                $record->delete();
                
                DB::commit();

                return Response::json(['message' => 'The shift bottle oil sales record has been deleted.']);
            } else {
                return Response::json(['message' => 'Shift bottle oil sales record not found.'], 404);
            }
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error($e->getMessage());
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}
