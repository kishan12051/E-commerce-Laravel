<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Employees;
use App\Models\EmployeeGroups;

class EmployeeGroupsController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:employee-groups-list', ['only' => ['index','show','changeEmployeeGroupStatus']]);
        $this->middleware('permission:employee-groups-create', ['only' => ['create','store']]);
        $this->middleware('permission:employee-groups-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:employee-groups-delete', ['only' => ['destroy']]);
        $this->middleware('permission:employee-groups-show', ['only' => ['show']]);

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $condition['employee_groups.user_id'] = auth()->user()->id;
        $employeeGroups = EmployeeGroups::where($condition)->get();
        return view('employee-groups.index', compact('employeeGroups'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (auth()->user()->sub_emp_id == 0) {
            $sub_emp_id = auth()->user()->id;
        } else {
            $sub_emp_id = auth()->user()->sub_emp_id;
        }
        $users = User::join("employees","employees.user_id","=","users.id")->where('users.status', 'Y')
        ->where('type', 3)->orderBy('name', 'ASC')
        ->limit(1000)
        ->where("sub_emp_id",$sub_emp_id)
        ->select('users.id as id', 'employees.name as name', 'employees.id as e_id')
        ->pluck('name', 'e_id');
        return view('employee-groups.create', compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messages = [
            'group_name.required' => 'The Group name field is required.',
            'assign_employee' => 'Please select atleast one assign employee.',
            'group_name.unique' => 'This Group name is already taken.',
        ];
        $this->validate($request, [
            'group_name' => 'required||unique:employee_groups',
            'assign_employee' => 'required',


        ], $messages);
        $employeeGroup = new EmployeeGroups();

        if ($request->isMethod('post')) {
            $employeeGroup->fill($request->all());
            $employeeGroup->group_employee_ids = is_array($request->assign_employee) ? json_encode($request->assign_employee) : "";
            $employeeGroup->user_id = auth()->user()->id;
            $employee = Employees::where('user_id', '=', auth()->user()->id)->first();

            if($employee && isset($employee->id) && $employee->id != "")
				$employeeGroup->employee_id = $employee->id;
            if ($employeeGroup->save()) {
                return redirect()->route('employee-groups.index')->with('message', 'Employee Group Created successfully');
            }else{
                $employeeErrors = $employeeGroup->getErrors();
                if (!empty($employeeErrors)) {
                    $errorMessages = [];
                    foreach ($employeeErrors as $key => $errors) {
                        $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                    }
                    redirect()->route('employee-groups')->with('error', 'The record could not be saved. ' . implode(' and ', $errorMessages));
                }
            }
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employeeGroup = EmployeeGroups::find($id);
        if ($employeeGroup && $employeeGroup->user_id == auth()->user()->id) {
            $conditions = [];
            if (auth()->user()->sub_emp_id == 0) {
                $sub_emp_id = auth()->user()->id;
            } else {
                $sub_emp_id = auth()->user()->sub_emp_id;
            }
            $users = User::join("employees","employees.user_id","=","users.id")->where('users.status', 'Y')->where('type', 3)->orderBy('name', 'ASC')
            ->limit(1000)->where("sub_emp_id",$sub_emp_id)
            ->select('users.id as id', 'employees.name as name', 'employees.id as e_id')
            ->pluck('name', 'e_id');
            $assign_employee = request()->input('assign_employee', $employeeGroup->group_employee_ids != "" ? json_decode($employeeGroup->group_employee_ids, true) : []);
            return view('employee-groups.edit', compact('employeeGroup', 'users' , 'assign_employee'));
        }else{
            return redirect()->route('employee-groups.index')->with('message', 'You are not authorized to edit this record');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messages = [
            'group_name.required' => 'The Group name is required.',
            'group_name.unique' => 'This Group name is already taken.',
            'assign_employee' => 'Please select atleast one assign employee.',
        ];
        $this->validate($request, [
            'group_name' => 'required|unique:employee_groups,group_name,'.$id,
            'assign_employee' => 'required',
        ], $messages);

        $employeeGroup = EmployeeGroups::findOrFail($id);
        if ($request->isMethod('PATCH')) {
            $employeeGroup->fill($request->all());
            $employeeGroup->group_employee_ids = is_array($request->assign_employee) ? json_encode($request->assign_employee) : "";
            $employeeGroup->user_id = auth()->user()->id;
            $employee = Employees::where('user_id', '=', auth()->user()->id)->first();
            if($employee && isset($employee->id) && $employee->id != "")
				$employeeGroup->employee_id = $employee->id;
            if ($employeeGroup->save()) {
                return redirect()->route('employee-groups.index')->with('message', 'Employee Group Updated successfully');
            }else{
                $employeeErrors = $employeeGroup->getErrors();
                if (!empty($employeeErrors)) {
                    $errorMessages = [];
                    foreach ($employeeErrors as $key => $errors) {
                        $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                    }
                    redirect()->route('employee-groups')->with('message', 'The record could not be saved. ' . implode(' and ', $errorMessages));
                }
            }
        }else{
            return redirect()->route('employee-groups.index')->with('message', 'Request method not proper');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if (isset($request->status)) {
            $record = EmployeeGroups::find($request->status);
            if ($record) {
                $record->delete();
                // Assuming $allData and $allDataRow are defined in the same function
                $allData = EmployeeGroups::select('id', 'group_name','group_employee_ids', 'status')->get();
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('employee-groups.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm"><i class="fas fa-edit"></i></a>
                        <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="employee-groups" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $status = '<button class="btn btn-' . ($allDataRow->status == 'Y' ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="employee-groups" data-id="' . $allDataRow->id . '">'
                        . ($allDataRow->status == 'Y' ? 'Activate' : 'Deactivate') . ''
                        . '</button>';
                    $employeeIds = json_decode($allDataRow->group_employee_ids, true);
                    $group_employee_ids = [];
                    foreach ($employeeIds as $employeeId) {
                        $employee = \App\Models\Employees::find($employeeId);
                        if ($employee) {
                            $group_employee_ids[] = $employee->name;
                        }
                    }
                    $allDataRow->group_employee_ids = implode('<br>', $group_employee_ids);
                    $allDataRow->status = $status;
                    $allDataRow->action = $html;
                }

                return response()->json(['data' => $allData, 'message' => 'Employee Groups deleted successfully.']);
            } else {
                return response()->json(['message' => 'Employee Groups not found.'], 404);
            }
        } else {
            return response()->json(['message' => 'Invalid request.'], 400);
        }
    }

    public function changeEmployeeGroupStatus(Request $request)
    {
        $employeeGroupId = $request->id;
        $employeeGroup = EmployeeGroups::find($employeeGroupId);
        if (!$employeeGroup) {
            return response()->json(['message' => 'Employee Group not found'], 404);
        }
        /* Toggle the employee group's status */
        $newStatus = $employeeGroup->status === 'Y' ? 'Active' : 'Deactivate';
        $employeeGroup->status = ($employeeGroup->status === 'Y') ? 'N' : 'Y';
        if($employeeGroup->save()){
            return response()->json(['success' => true ,'newStatus' => $newStatus ,'message' => 'Employee Group status updated successfully']);
        }else{
            return response()->json(['success' => false ,'newStatus' => $newStatus, 'message' => 'Something Wents wrong']);
        }
    }

}
