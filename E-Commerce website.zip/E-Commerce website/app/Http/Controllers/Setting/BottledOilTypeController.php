<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BottledOilType;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;

class BottledOilTypeController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:bottled-oil-types-list', ['only' => ['index','show']]);
        $this->middleware('permission:bottled-oil-types-create', ['only' => ['create','store']]);
        $this->middleware('permission:bottled-oil-types-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:bottled-oil-types-delete', ['only' => ['destroy']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page_title = "List Of Bottled Oil Type";
        $bottledOilTypes = BottledOilType::orderBy('id', 'DESC')->get();
        return view('bottled-oil-type.index',compact('bottledOilTypes','page_title'))
            ->with('i');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('bottled-oil-type.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $errormsg = 'This field is required.';
        $request->validate([


            'bottled_oil_en' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingBottledoilType = BottledOilType::where('bottled_oil_en', $value)->first();
                    if ($existingBottledoilType) {
                        $fail('Bottled oil Type name for English already exists.');
                    }
                },
            ],
            'bottled_oil_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingBottledoilType = BottledOilType::where('bottled_oil_ru', $value)->first();
                    if ($existingBottledoilType) {
                        $fail('Bottled oil Type name for Russian already exists.');
                    }
                },
            ],
            'bottled_oil_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingBottledoilType = BottledOilType::where('bottled_oil_tu', $value)->first();
                    if ($existingBottledoilType) {
                        $fail('Bottled oil Type name for Türkmen already exists.');
                    }
                },
            ],

            'volumn' => 'required|max:9',
            'price' => [
                'required',
                'regex:/^\d{1,8}(\.\d{0,2})?$/'
            ],
        ], [
            'bottled_oil_en.required' =>  $errormsg,
            'bottled_oil_ru.required' =>  $errormsg,
            'bottled_oil_tu.required' =>  $errormsg,
            'volumn.required' =>  $errormsg,
            'price.required' =>  $errormsg,
            'volumn.max' => 'The volumn must be 9 digits or less.',
            'price.regex' => 'Please enter a valid value. The price/bottle must be 8 digits or less.',

        ]);

        try {
            $BottledOilType = new BottledOilType();
            $BottledOilType->bottled_oil_en = $request->bottled_oil_en;
            $BottledOilType->bottled_oil_ru = $request->bottled_oil_ru;
            $BottledOilType->bottled_oil_tu = $request->bottled_oil_tu;
            $BottledOilType->volumn = $request->volumn;
            $BottledOilType->price = $request->price;
            $BottledOilType->save();

            return redirect()->route('bottled-oil-type.index')->with('message', 'The record has been saved successfully');

        } catch (\Exception $e) {
            return $e;

        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(isset($id)){
            $record = BottledOilType::findOrFail($id);
            // dd($record);
            $data = $record->toArray();
            return view('bottled-oil-type.edit',compact('record') );
        }else{
            return redirect()->route('bottled-oil-type.index')->with('message', 'no data found');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $errormsg = 'This field is required.';
        $errormsgen = 'Bottled oil Type name for English already exists.';
        $errormsgru = 'Bottled oil Type name for Russian already exists.';
        $errormsgtk = 'Bottled oil Type name for Türkmen already exists.';
        $request->validate([
            'bottled_oil_en' => 'required|unique:bottled_oil_types,bottled_oil_en,'.$id,
            'bottled_oil_ru' => 'required|unique:bottled_oil_types,bottled_oil_ru,'.$id,
            'bottled_oil_tu' => 'required|unique:bottled_oil_types,bottled_oil_tu,'.$id,
            'volumn' => 'required|max:9',
            'price' => [
                'required',
                'regex:/^\d{1,8}(\.\d{0,2})?$/'
            ],
        ], [
            'bottled_oil_en.required' =>  $errormsg,
            'bottled_oil_ru.required' =>  $errormsg,
            'bottled_oil_tu.required' =>  $errormsg,
            'bottled_oil_en.unique' => $errormsgen,
            'bottled_oil_ru.unique' => $errormsgru,
            'bottled_oil_tu.unique' => $errormsgtk,
            'volumn.required' =>  $errormsg,
            'price.required' =>  $errormsg,
            'volumn.max' => 'The volumn must be 9 digits or less.',
            'price.regex' => 'Please enter a valid value. The price/bottle must be 8 digits or less.',

        ]);

        $BottledOilType = BottledOilType::findOrFail($id);

        try{
            $BottledOilType->bottled_oil_en = $request->bottled_oil_en;
            $BottledOilType->bottled_oil_ru = $request->bottled_oil_ru;
            $BottledOilType->bottled_oil_tu = $request->bottled_oil_tu;
            $BottledOilType->volumn = $request->volumn;
            $BottledOilType->price = $request->price;
            $BottledOilType->save();

            return redirect()->route('bottled-oil-type.index')->with('message', 'The record has been updated successfully');
        }
        catch (\Exception $e) {
            Log::error($e->getMessage());
            return Redirect::back()->withErrors(['error' => 'An error occurred.']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = BottledOilType::find($request->status);
            if ($record) {
                $record->delete();
                $default_language = get_default_language();
                $allData = BottledOilType::select('id', 'bottled_oil_'.$default_language,'volumn','price')->orderBy('id', 'DESC')->get();
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('bottled-oil-type.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="bottled-oil-type" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData, 'message' => 'The record has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Bottled Oil Type not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
