<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\Log;
use App\Models\DefaultMatrixData;
use App\Models\Employees;
use App\Models\MatrixTemplates;
use App\Models\Reservoirs;
use Carbon\Carbon;
use Collective\Html\FormFacade as Form;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class MatrixController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
     */
   
     function __construct()
    {

        $this->middleware('permission:matrix-templates-list|matrix-templates-create|matrix-templates-edit|matrix-templates-delete|default-matrix-records-add', ['only' => ['index','show']]);
        $this->middleware('permission:matrix-templates-create', ['only' => ['create','store']]);
        $this->middleware('permission:matrix-templates-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:matrix-templates-delete', ['only' => ['destroy']]);
        $this->middleware('permission:default-matrix-records-add', ['only' => ['add']]);

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function index()
    {
        if (auth()->user()->type == 3) {
            $userId = auth()->user()->sub_emp_id == 0 ? auth()->user()->id : auth()->user()->sub_emp_id;
            $page_title = 'LISTS OF MATRIX TEMPLATES';
            $matrixtemplates = MatrixTemplates::where('user_id', $userId)->orderBy('id', 'DESC')->get();
            return view('matrix-templates.index', compact('matrixtemplates', 'page_title'))->with('i');

        } else {
            return redirect()->route('dashboard.index')
                ->with('error', 'You are not authorized to view this record.');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $createMatrixtemplates = MatrixTemplates::select('id', 'template_name_en')
                                ->limit(200)
                                ->get()
                                ->pluck('template_name_en', 'id');
        return view('matrix-templates.create',compact('createMatrixtemplates'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $userId   = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();
        $errormsg = 'This field is required.';
        $request->validate([/* 'is_parent' => ['required'], */
            'template_name_en' => ['required',
                function ($attribute, $value, $fail) {
                    $existingMatrixTemplates = MatrixTemplates::where('template_name_en', $value)->first();
                    if ($existingMatrixTemplates) {
                        $fail('Name for english already exists.');
                    }
                },
            ],
            'template_name_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingMatrixTemplates = MatrixTemplates::where('template_name_ru', $value)->first();
                    if ($existingMatrixTemplates) {
                        $fail('Name for russian already exists.');
                    }
                },
            ],
            'template_name_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingMatrixTemplates = MatrixTemplates::where('template_name_tu', $value)->first();
                    if ($existingMatrixTemplates) {
                        $fail('Name for turkmenistan already exists.');
                    }
                },
            ],
        ], [
            'template_name_en.required' => $errormsg,
            'template_name_ru.required' => $errormsg,
            'template_name_tu.required' => $errormsg,
        ]);

        $MatrixTemplates = new MatrixTemplates();
        $MatrixTemplates->user_id = $userId;
        $MatrixTemplates->employee_id = $employee->id;
        $MatrixTemplates->template_name_en = $request->template_name_en;
        $MatrixTemplates->template_name_ru = $request->template_name_ru;
        $MatrixTemplates->template_name_tu = $request->template_name_tu;
        $MatrixTemplates->created_at = now();
        $MatrixTemplates->save();
        return redirect()->route('matrix-templates.index')->with('message', 'Matrix Template Added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $matrixtemplates = MatrixTemplates::findOrFail($id);
        $defaultmetrixdatas = DefaultMatrixData::where('matrix_template_id', $id)->get();
        return view('matrix-templates.edit', compact('matrixtemplates', 'defaultmetrixdatas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messages = [
            'template_name_en.required' => 'The field is required.',
            'template_name_ru.required' => 'The field is required.',
            'template_name_tu.required' => 'The field is required.',
            'template_name_en.unique' => 'Name for english already exists.',
            'template_name_ru.unique' => 'Name for russian already exists.',
            'template_name_tu.unique' => 'Name for Turkmenistan already exists.',
        ];

        $this->validate($request, [
            'template_name_en' => 'required|unique:matrix_templates,template_name_en,' . $id,
            'template_name_ru' => 'required|unique:matrix_templates,template_name_ru,' . $id,
            'template_name_tu' => 'required|unique:matrix_templates,template_name_tu,' . $id,
        ], $messages);

        $matrixtemplate = MatrixTemplates::findOrFail($id);
        if ($matrixtemplate) {
            $matrixtemplate->template_name_en = $request->template_name_en;
            $matrixtemplate->template_name_ru = $request->template_name_ru;
            $matrixtemplate->template_name_tu = $request->template_name_tu;
            $matrixtemplate->updated_at = now();
            $matrixtemplate->save();
            return redirect()->route('matrix-templates.index')->with('message', 'Matrix Template updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if (auth()->user()->type == 3) {
            $userId = auth()->user()->sub_emp_id == 0 ? auth()->user()->id : auth()->user()->sub_emp_id;
            $matrixTemplate = MatrixTemplates::where('user_id', $userId)->where('id', $request->status)->first();

            if ($matrixTemplate) {
                // Check if there are related records in DefaultMatrixData and Reservoirs
                $defaultMatrixDataCount = DefaultMatrixData::where('matrix_template_id', $request->status)->count();
                $reservoirsCount = Reservoirs::where('matrix_template_id', $request->status)->count();

                if ($defaultMatrixDataCount > 0 || $reservoirsCount > 0) {
                    return response()->json(['error' => 'Please delete related matrix data first.']);
                }

                if ($matrixTemplate->delete()) {
                    // Retrieve the updated list of matrix templates
                    $default_language = get_default_language();
                    $allData = MatrixTemplates::select('id', 'template_name_' . $default_language)->orderBy('id', 'DESC')->get();
                    foreach ($allData as $allDataRow) {
                        $html = '<a class="btn btn-info btn-circle btn-sm" href="' . route('matrix-templates.duplicate', $allDataRow->id) . '"><i class="fas fa-copy"></i></a>
                                <a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('matrix-templates.edit', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                                <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="matrix-templates" data-id="' . $allDataRow->id . '"
                                    data-url="' . route('matrix-templates.destroy', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';
                        $allDataRow->action = $html;
                    }
                    return response()->json(['data' => $allData, 'message' => 'Matrix Template deleted successfully.'], 200);
                } else {
                    $error = 'The matrix template could not be deleted. Please try again.';
                    return response()->json(['error' => $error]);
                }
            } else {
                $error = 'You are not authorized to view this record.';
                return response()->json(['error' => $error]);
            }
        } else {
            $error = 'You are not authorized to view this record.';
            return response()->json(['error' => $error]);
        }
    }

    public function duplicate($id)
    {
        $matrixtemplates = MatrixTemplates::find($id);
        $defaultmetrixdatas = DefaultMatrixData::where('matrix_template_id', $id)->get();
        $duplicatematrixtemplates = $matrixtemplates->replicate();
        $duplicatematrixtemplates->template_name_en = $matrixtemplates->template_name_en.("(Duplicate)"). " ".time();
        $duplicatematrixtemplates->template_name_ru = $matrixtemplates->template_name_ru.("(Duplicate)"). " ".time();
        $duplicatematrixtemplates->template_name_tu = $matrixtemplates->template_name_tu.("(Duplicate)"). " ".time();
        $duplicatematrixtemplates->created_at = Carbon::now();
        if ($duplicatematrixtemplates->save()) {
            foreach($defaultmetrixdatas as $key=>$defaultmetrixdata){
                $duplicatedefaultmatrixdata = $defaultmetrixdata->replicate();
                $duplicatedefaultmatrixdata->created_at = Carbon::now();
                $duplicatedefaultmatrixdata->matrix_template_id = $duplicatematrixtemplates->id;
                $duplicatedefaultmatrixdata->save();
            }
        }
        return redirect()->route('matrix-templates.index')->with('message', 'The matrix template has been saved.');
    }
}
