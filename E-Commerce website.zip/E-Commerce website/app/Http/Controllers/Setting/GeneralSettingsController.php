<?php

namespace App\Http\Controllers\setting;
use App\Http\Controllers\Controller;
use App\Models\GeneralSettings;
use App\Models\Language;
use App\Models\TimeZone;
use Illuminate\Http\Request;

class GeneralSettingsController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:generalsettings-list', ['only' => ['index','show']]);
        $this->middleware('permission:generalsettings-edit', ['only' => ['edit','update']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $page_title = "General Settings";
        $generalsettings= GeneralSettings::first();
        $languages = Language::orderBy('id', 'ASC')->pluck('name', 'id');
        $timezone = TimeZone::orderBy('id', 'ASC')->pluck('time_zone', 'id');

        return view('generalsettings.index', compact('generalsettings','languages','timezone','page_title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $errormsg = 'This field is required';
        $emailErrorMsg = 'Invalid email format';
        $dimensionsErrorMsg = 'The file has invalid image dimensions';
        $phonenumErrMsg = 'Please provide valid Phone number';

        $request->validate([
            'website_title' => 'required',
            'login_page_title' => 'required',
            /* 'email' => 'required|email', */
            'currency' => 'required',
            'address' => 'required',
            'phone_no' => 'required|integer',
            'footer_text' => 'required',
            'language_name' => 'required',
            'favicon_icon' => 'dimensions:width=16,height=16',
            'left_navigation_icon' => 'dimensions:height=120',
            'website_logo' => 'dimensions:height=512',

        ], [
            'website_title.required' =>  $errormsg,
            'login_page_title.required' => $errormsg,
            /* 'email.required' =>  $errormsg, */
            'email.email' => $emailErrorMsg,
            'currency.required' =>  $errormsg,
            'address.required' =>  $errormsg,
            'phone_no.required' =>  $errormsg,
            'phone_no.integer' =>  $phonenumErrMsg,
            'footer_text.required' =>  $errormsg,
            'language_name.required' =>  $errormsg,
            'favicon_icon.dimensions' =>  $dimensionsErrorMsg,
            'left_navigation_icon.dimensions' =>  $dimensionsErrorMsg,
            'website_logo.dimensions' =>  $dimensionsErrorMsg,
        ]);
        $generalsetting = GeneralSettings::findOrFail($id);
        $generalsetting->website_title = $request->website_title;
        $generalsetting->login_page_title = $request->login_page_title;
        $generalsetting->address = $request->address;
        /*generalsetting->email = $request->email;*/
        $generalsetting->phone_no = $request->phone_no;
        $generalsetting->language = $request->language_name;
        $generalsetting->time_zone = $request->timezone_name;
        $generalsetting->currency = $request->currency;
        $generalsetting->footer_text = $request->footer_text;

        if ($request->hasFile('left_navigation_icon')) {
            $image = $request->file('left_navigation_icon');
            $destinationPath = public_path('left-navigation-icon');
            $filename = $image->getClientOriginalName();

            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }

            $image->move($destinationPath, $filename);

            $generalsetting->left_navigation_icon = $filename;
        }
        if ($request->hasFile('favicon_icon')) {
            $image = $request->file('favicon_icon');
            $destinationPath = public_path('favicon-icon');
            $filename = $image->getClientOriginalName();

            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }

            $image->move($destinationPath, $filename);

            $generalsetting->favicon_icon = $filename;
        }
        if ($request->hasFile('website_logo')) {
            $image = $request->file('website_logo');
            $destinationPath = public_path('website-logo');
            $filename = $image->getClientOriginalName();

            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }

            $image->move($destinationPath, $filename);

            $generalsetting->website_logo = $filename;

        }

        $generalsetting->save();

        return redirect()->route('generalsettings.index')
        ->with('message', 'general settings updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

