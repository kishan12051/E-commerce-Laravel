<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Designations;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;

class DesignationsController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:designations-list', ['only' => ['index','show']]);
        $this->middleware('permission:designations-create', ['only' => ['create','store']]);
        $this->middleware('permission:designations-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:designations-delete', ['only' => ['destroy']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function index(Request $request)
    {
        $designations = Designations::orderBy('id','DESC')->get();
        $page_title = "Lists Of Designations";
        return view('designations.index',compact('designations','page_title'))->with('i');
    }
    public function create()
    {
        $createDesignations = Designations::select('id', 'title_en')
        ->where('status','Y')
        ->limit(200)
        ->get()
        ->pluck('title_en', 'id');
        return view('designations.create',compact('createDesignations'));
    }
    public function store(Request $request)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'title_en' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Designations::where('title_en', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for english already exists');
                    }
                },
            ],
            'title_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Designations::where('title_ru', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for russian already exists');
                    }
                },
            ],
            'title_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Designations::where('title_tu', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for Türkmen already exists');
                    }
                },
            ],
        ], [
            'title_en.required' =>  $errormsg,
            'title_ru.required' =>  $errormsg,
            'title_tu.required' =>  $errormsg
        ]);

        $Designations = new Designations();
        $Designations->designation_code = "DES-".rand("999999", '111111');
        $Designations->title_en = $request->title_en;
        $Designations->title_ru = $request->title_ru;
        $Designations->title_tu = $request->title_tu;
        $Designations->created_at = now();
        $Designations->save();
        return redirect()->route('designations.index')->with('message', 'The record has been saved successfully');
    }

    public function edit($id)
    {
        $designation = Designations::findOrFail($id);
        return view('designations.edit', compact('designation'));
    }

    public function update(Request $request, $id)
    {

        $messages = [
            'title_en.required' => 'The field is required.',
            'title_ru.required' => 'The field is required.',
            'title_tu.required' => 'The field is required.',
            'title_en.unique' => 'Title for english already exists.',
            'title_ru.unique' => 'Title for russian already exists.',
            'title_tu.unique' => 'Title for Türkmen already exists.'
        ];

        $this->validate($request, [
            'title_en' => 'required|unique:designations,title_en,'.$id,
            'title_ru' => 'required|unique:designations,title_ru,'.$id,
            'title_tu' => 'required|unique:designations,title_tu,'.$id
        ], $messages);


        try {
            $designation = Designations::findOrFail($id);
            $designation->update([
                'title_en' => $request->input('title_en'),
                'title_ru' => $request->input('title_ru'),
                'title_tu' => $request->input('title_tu'),
            ]);
            return redirect()->route('designations.index')->with('message', 'The record has been updated successfully');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return Redirect::back()->withErrors(['error' => 'An error occurred.']);
        }
    }

    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = Designations::find($request->status);
            if ($record) {
                $record->delete();
                $default_language = get_default_language();
                $allData = Designations::select('id','designation_code','title_'.$default_language)->orderBy('id','DESC')->get();
                foreach ($allData as $allDataRow) {
                    $html = '<a class="btn btn-primary btn-circle btn-sm" title="Show" href="' . route('designations.show', $allDataRow->id) . '"><i class="fas fa-eye"></i></a>
                             <a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('designations.edit', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                             <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="designations" data-id="' . $allDataRow->id . '" data-url="' . route('designations.destroy', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData,'message'=>'The record has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Designation not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
