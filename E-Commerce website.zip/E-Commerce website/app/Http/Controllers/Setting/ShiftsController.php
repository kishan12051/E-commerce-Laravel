<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Shifts;
use App\Models\Employees;
use Carbon\Carbon;
use Illuminate\Support\Facades\Response;

class ShiftsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct(){
        $this->middleware('permission:shift-list', ['only' => ['index','show']]);
        $this->middleware('permission:shift-create', ['only' => ['create','store']]);
        $this->middleware('permission:shift-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:shift-delete', ['only' => ['destroy']]);
    }
    public function index()
    {
        $page_title = "List Of Shifts";
        $shifts = Shifts::orderBy('id')->get();
        // Format start_date and end_date using Carbon
        foreach ($shifts as $shift) {
            $shift->start_date = Carbon::createFromFormat('Y-m-d', $shift->start_date)->format('d/m/Y');
            $shift->end_date = Carbon::createFromFormat('Y-m-d', $shift->end_date)->format('d/m/Y');
        }

        return view('shifts.index', compact('shifts','page_title'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $statusArray = [
            '1' => 'Active',
            '0' => 'Inactive',
        ];

        return view('shifts.create',compact('statusArray'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
{
    // Validate the request data
    $request->validate([
        'start_date' => 'required|date_format:Y/m/d',
        'end_date' => 'required|date_format:Y/m/d|after:start_date',
        'shift1_title_en' => 'required',
        'shift1_title_ru' => 'required',
        'shift1_title_tu' => 'required',
        'shift_start_time' => 'required',
        'shift_end_time' => 'required',
        'status' => 'required',
    ], [
        'start_date.required' => 'This field is required',
        'start_date.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD.',
        'end_date.required' => 'This field is required',
        'end_date.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD.',
        'end_date.after' => 'End date must be after the start date',
        'shift1_title_en.required' => 'This field is required',
        'shift1_title_ru.required' => 'This field is required',
        'shift1_title_tu.required' => 'This field is required',
        'shift_start_time.required' => 'This field is required',
        'shift_end_time.required' => 'This field is required',
        'status.required' => 'This field is required',
    ]);

    // Build the time slot in the format "start_time - end_time"
    $startTime = $request->shift_start_time;
    $endTime = $request->shift_end_time;
    $timeSlot = $startTime . ' - ' . $endTime;

    // Check if the time slot already exists in the database
    $existingShift = Shifts::where('shift1_time', $timeSlot)
        ->where('start_date', '<=', $request->end_date)
        ->where('end_date', '>=', $request->start_date)
        ->first();

    if ($existingShift) {
        return redirect()->back()->with('error' , __('Time slot is already exits'));
    }

    // If the time slot is not already booked, proceed with saving the new shift
    $adminId = auth()->user()->id;
    $employee = Employees::where('user_id', $adminId)->first();

    $shifts = new Shifts();
    $shifts->user_id = $adminId;
    $shifts->employee_id = $employee->id;
    $shifts->start_date = Carbon::createFromFormat('Y/m/d', $request->input('start_date'));
    $shifts->end_date = Carbon::createFromFormat('Y/m/d', $request->input('end_date'));
    $shifts->shift1_title_en = $request->input('shift1_title_en');
    $shifts->shift1_title_ru = $request->input('shift1_title_ru');
    $shifts->shift1_title_tu = $request->input('shift1_title_tu');
    $shifts->shift_start_time = $request->input('shift_start_time');
    $shifts->shift_end_time = $request->input('shift_end_time');
    $shifts->shift1_time = $timeSlot;
    $shifts->status = $request->input('status');
    $shifts->created_at = now();

    if ($shifts->save()) {
        return redirect()->route('shifts.index')->with('message', __('The record has been saved successfully'));
    } else {
        return redirect()->back()->with('error', __('Failed to add Shift. Please try again.'));
    }
}


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $statusArray = [
            '1' => 'Active',
            '0' => 'Inactive',
        ];

        $shifts = Shifts::findOrFail($id);
        $shifts->start_date = Carbon::createFromFormat('Y-m-d', $shifts->start_date)->format('Y/m/d');
        $shifts->end_date = Carbon::createFromFormat('Y-m-d', $shifts->end_date)->format('Y/m/d');
        return view('shifts.edit', compact('shifts','statusArray'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'start_date' => 'required|date_format:Y/m/d',
            'end_date' => 'required|date_format:Y/m/d|after:start_date',
            'shift1_title_en' => 'required',
            'shift1_title_ru' => 'required',
            'shift1_title_tu' => 'required',
            'shift_start_time' => 'required',
            'shift_end_time' => 'required',
            'status' => 'required',
        ], [
            'start_date.required' => $errormsg,
            'start_date.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD.',
            'end_date.required' => $errormsg,
            'end_date.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD.',
            'end_date.after' => 'End date must be after the start date.',
            'shift1_title_en.required' => $errormsg,
            'shift1_title_ru.required' => $errormsg,
            'shift1_title_tu.required' => $errormsg,
            'shift_start_time.required' => $errormsg,
            'shift_end_time.required' => $errormsg,
            'status.required' => $errormsg,
        ]);

        $shifts = Shifts::findOrFail($id);

        if ($shifts) {
        // Build the time slot in the format "start_time - end_time"
        $startTime = $request->shift_start_time;
        $endTime = $request->shift_end_time;
        $timeSlot = $startTime . ' - ' . $endTime;

        if ($timeSlot != $shifts->shift1_time) {
            // Check if the new time slot already exists in the database
            $existingShift = Shifts::where('shift1_time', $timeSlot)
                ->where('start_date', '<=', $request->end_date)
                ->where('end_date', '>=', $request->start_date)
                ->first();

            if ($existingShift) {
                return redirect()->back()->with('error', 'Time slot is already booked.');
            }
        }

            $shifts->start_date = $request->start_date;
            $shifts->end_date = $request->end_date;
            $shifts->shift1_title_en = $request->shift1_title_en;
            $shifts->shift1_title_ru = $request->shift1_title_ru;
            $shifts->shift1_title_tu = $request->shift1_title_tu;
            $shifts->shift_start_time = $request->shift_start_time;
            $shifts->shift_end_time = $request->shift_end_time;
            $shifts->shift1_time = $timeSlot;
            $shifts->status = $request->status;
            $shifts->updated_at = now();
            $shifts->save();
            return redirect()->route('shifts.index')
            ->with('message', 'Shift updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function changeShiftsStatus(Request $request)
    {
        $data = $request->all();
        $shifts = Shifts::find($data['id']);
        if(!$shifts){
            return response()->json(['message'=>'Shift Not found'], 404);
        }
        $shifts->status = ($shifts->status === 1) ? 0 : 1;
        $newStatus = $shifts->status === 1 ? 'Active' : 'Inactive' ;
        if ($shifts->save()) {
            return response()->json(['success' => true, 'newStatus' => $newStatus, 'message' => 'The record has been updated successfully']);
        } else {
            return response()->json(['success' => false, 'newStatus' => $newStatus, 'message' => 'Something Went wrong']);
        }
    }

    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = Shifts::find($request->status);
            if ($record) {
                $record->delete();
                $default_language = get_default_language();
                $allData = Shifts::select('id','start_date', 'end_date', 'shift1_title_' . $default_language)
                ->selectRaw('CONCAT(shift_start_time, "-", shift_end_time) AS shift_time')
                ->addSelect('status')
                ->get();

                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                    <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="shifts" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $status = '<button class="btn btn-' . ($allDataRow->status == 1 ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="shifts" data-id="' . $allDataRow->id . '">'
                        . ($allDataRow->status == 1 ? 'Active' : 'Inactive') . ''
                        . '</button>';
                    $allDataRow->status = $status;
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData, 'message' => 'The record has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Shift not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}




