<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Employees;
use App\Models\DefaultMatrixData;
use App\Models\MatrixTemplates;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;

class DefaultMatrixRecordsController extends Controller
{
    public function add(Request $request,$id)
    {
        $user       = Auth::user();
        $username   = $user->username;
        $matrix_template_id = $request->route('id');
        $defaultmetrixdatas = DefaultMatrixData::get();
        return view('default-matrix-records.add',compact('user','matrix_template_id','defaultmetrixdatas'));
    }

    public function store(Request $request)
    {
        $userId   = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();
        $matrix_template_id = $request->matrix_template_id;
        $errormsg = 'This field is required.';
        $request->validate([
            'height' => 'required|not_in:0|string|regex:/^[^a-zA-Z]+$/',
            'volumn_liter' => 'required|not_in:0|string|regex:/^[^a-zA-Z]+$/',
            'volumn_ml' => 'required|not_in:0|string|regex:/^[^a-zA-Z]+$/'
        ], [
            'height.required' => 'This field is required',
            'volumn_liter.required' => 'This field is required',
            'volumn_ml.required' => 'This field is required',

            'height.not_in' => 'Height in cm must be greater than 0',
            'volumn_liter.not_in' => 'Volumn in liter must be greater than 0',
            'volumn_ml.not_in' => 'Volumn in ml must be greater than 0',

            'height.regex' => 'Height should not contain alphabets',
            'volumn_liter.regex' => 'Volumn should not contain alphabets',
            'volumn_ml.regex' => 'Volumn should not contain alphabets',

        ]);

        $DefaultMatrixData                              = new DefaultMatrixData();
        $DefaultMatrixData->user_id                     = $userId;
        $DefaultMatrixData->employee_id                 = $employee->id;
        $DefaultMatrixData->matrix_template_id          = $matrix_template_id;
        $DefaultMatrixData->height                      = $request->height;
        $DefaultMatrixData->volumn_liter                = $request->volumn_liter;
        $DefaultMatrixData->volumn_ml                   = $request->volumn_ml;
        $DefaultMatrixData->save();

        return redirect()->to('matrix-templates/' .$matrix_template_id . '/edit')->with('message', 'Default Matrix Data created successfully.');
    }
    public function edit(Request $request,$id,$matrix_template_id)
    {
        $user               = Auth::user();
        $matrix_template_id = $matrix_template_id;
        $defaultmetrixdatas = DefaultMatrixData::findOrFail($id);
        return view('default-matrix-records.edit', compact('defaultmetrixdatas','user','matrix_template_id'));
    }

    public function update(Request $request, $id)
    {
        $userId   = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();
        $matrix_template_id = $request->matrix_template_id;
        $request->validate([
            'height' => 'required|not_in:0|string|regex:/^[^a-zA-Z]+$/',
            'volumn_liter' => 'required|not_in:0|string|regex:/^[^a-zA-Z]+$/',
            'volumn_ml' => 'required|not_in:0|string|regex:/^[^a-zA-Z]+$/'
        ], [
            'height.required' => 'This field is required',
            'volumn_liter.required' => 'This field is required',
            'volumn_ml.required' => 'This field is required',

            'height.not_in' => 'Height in cm must be greater than 0',
            'volumn_liter.not_in' => 'Volumn in liter must be greater than 0',
            'volumn_ml.not_in' => 'Volumn in ml must be greater than 0',

            'height.regex' => 'Height should not contain alphabets',
            'volumn_liter.regex' => 'Volumn should not contain alphabets',
            'volumn_ml.regex' => 'Volumn should not contain alphabets',

        ]);

        $DefaultMatrixData = DefaultMatrixData::findOrFail($id);
        if($DefaultMatrixData){
            $DefaultMatrixData->user_id             = $userId;
            $DefaultMatrixData->employee_id         = $employee->id;
            $DefaultMatrixData->matrix_template_id  = $matrix_template_id;
            $DefaultMatrixData->height              = $request->height;
            $DefaultMatrixData->volumn_liter        = $request->volumn_liter;
            $DefaultMatrixData->volumn_ml           = $request->volumn_ml;
            $DefaultMatrixData->updated_at          = now();
            $DefaultMatrixData->save();
            return redirect()->to('matrix-templates/' .$matrix_template_id . '/edit')->with('message', 'Default Matrix Data updated successfully.');
        }
    }
    public function destroy(Request $request, $id)
    {
        try {
            $defaultMatrixdata = DefaultMatrixData::findOrFail($id);
            $defaultMatrixdata->delete();
            return redirect()->to('matrix-templates/' .$matrix_template_id . '/edit')->with('message', 'Default Matrix Data deleted successfully');
        }
        catch (\Exception $e) {
            Log::error($e->getMessage());
            return Redirect::back()->withErrors(['error' => 'An error occurred.']);
        }
    }

    public function delete(Request $request)
    {
        if (auth()->user()->type == 3) {
            if (auth()->user()->sub_emp_id == 0) {
                $admin_id = auth()->user()->id;
            } else {
                $admin_id = auth()->user()->sub_emp_id;
            }
            $defaultMatrix = DefaultMatrixData::where('id', $request->status)->where('user_id', $admin_id)->get()->toArray();
            $matrix_template_id=$defaultMatrix[0]['matrix_template_id'];
            $defaultMatrixRecord = DefaultMatrixData::where('id', $request->status)->where('user_id', $admin_id)->first();
            
            if ($defaultMatrixRecord) {
                if ($defaultMatrixRecord->delete()) {
                    $allData = DefaultMatrixData::select('id', 'height','volumn_liter','volumn_ml')
                    ->where('user_id', $admin_id)
                    ->where('matrix_template_id', $matrix_template_id)->get();

                    $allData = $allData->map(function ($data) {
                        $data->height = (int) $data->height;
                        $data->volumn_liter = (int) $data->volumn_liter;
                        $data->volumn_ml = (int) $data->volumn_ml;
                        return $data;
                    });

                    foreach ($allData as $allDataRow) {
                        $html = '<a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('default-matrix-records.edit', ['id' => $allDataRow->id, 'matrix_template_id' => $matrix_template_id]) . '"><i class="fas fa-edit"></i></a>
                                <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="default-matrix-records" data-id="' . $allData[0]['id'] . '"
                                    data-url="' . route('default-matrix-records.destroy', $allData[0]['id']) . '"><i class="fas fa-trash"></i></button>';
                        $allDataRow->action = $html;
                    }
                    return response()->json(['data' => $allData, 'message' => 'Default Matrix deleted successfully.'], 200);
                } else {
                    session()->flash('error', 'The default matrix record could not be deleted. Please try again.');
                }
                return redirect()->route('matrix-templates/' .$matrix_template_id . '/edit');
            } else {
                session()->flash('error', 'You are not authorized to view this record.');
                return redirect()->route('default-matrix-records.index');
            }
        } else {
            session()->flash('error', 'You are not authorized to view this record.');
            return redirect()->route('dashboards.index');
        }
    }
}
