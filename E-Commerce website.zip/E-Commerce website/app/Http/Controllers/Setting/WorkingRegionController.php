<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\WorkingRegion;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Carbon\Carbon;
use Illuminate\Support\Facades\Response;

class WorkingRegionController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:working-regions-list', ['only' => ['index','show']]);
        $this->middleware('permission:working-regions-create', ['only' => ['create','store']]);
        $this->middleware('permission:working-regions-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:working-regions-delete', ['only' => ['destroy']]);
    }
    public function index()
    {
        $page_title = "Lists Of Working Region";
        $workingregion = WorkingRegion::get();
        return view('workingregion.index', compact('workingregion','page_title'))->with('i');
    }

    public function create()
    {
        $createWorkingregion = WorkingRegion::get();
        return view('workingregion.create',compact('createWorkingregion'));
    }

    public function store(Request $request)
    {
        $errormsg = 'This field is required.';
        $request->validate([
            'region_name_en' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingRegion = WorkingRegion::where('region_name_en', $value)->first();
                    if ($existingRegion) {
                        $fail('Region name for English already exists.');
                    }
                },
            ],
            'region_name_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingRegion = WorkingRegion::where('region_name_ru', $value)->first();
                    if ($existingRegion) {
                        $fail('Region name for Russian already exists.');
                    }
                },
            ],
            'region_name_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingRegion = WorkingRegion::where('region_name_tu', $value)->first();
                    if ($existingRegion) {
                        $fail('Region name for Türkmen already exists.');
                    }
                },
            ],
        ], [
            'region_name_en.required' => $errormsg,
            'region_name_ru.required' => $errormsg,
            'region_name_tu.required' => $errormsg
        ]);

        try {
            $workingRegion = new WorkingRegion();
            $workingRegion->region_code = "REG-" . rand("999999", '111111');
            $workingRegion->region_name_en = $request->region_name_en;
            $workingRegion->region_name_ru = $request->region_name_ru;
            $workingRegion->region_name_tu = $request->region_name_tu;
            if ($workingRegion->save()) {
                return redirect()->route('workingregion.index')->with('message', 'The record has been saved successfully');
            }
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return redirect()->back()->withErrors(['error' => 'An error occurred.']);
        }
    }

    public function edit($id)
    {
        $workingRegion = WorkingRegion::findOrFail($id);
        return view('workingregion.edit', compact('workingRegion'));
    }

    public function update(Request $request, $id)
    {
        $errormsg = 'This field is required.';
        $errormsgen = 'Region name for English already exists.';
        $errormsgru = 'Region name for Russian already exists.';
        $errormsgtk = 'Region name for Türkmen already exists.';

        $request->validate([
            'region_name_en' => 'required|unique:working_regions,region_name_en,'.$id,
            'region_name_ru' => 'required|unique:working_regions,region_name_ru,'.$id,
            'region_name_tu' => 'required|unique:working_regions,region_name_tu,'.$id,
        ],[

            'region_name_en.required' =>  $errormsg,
            'region_name_ru.required' =>  $errormsg,
            'region_name_tu.required' =>  $errormsg,
            'region_name_en.unique' => $errormsgen,
            'region_name_ru.unique' => $errormsgru,
            'region_name_tu.unique' => $errormsgtk
        ]);

        try {
            $workingRegion = WorkingRegion::findOrFail($id);
            $workingRegion->update([
                'region_name_en' => $request->input('region_name_en'),
                'region_name_ru' => $request->input('region_name_ru'),
                'region_name_tu' => $request->input('region_name_tu'),
            ]);

            return redirect()->route('workingregion.index')->with('message', 'The record has been updated successfully');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return Redirect::back()->withErrors(['error' => 'An error occurred.']);
        }
    }

    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = WorkingRegion::find($request->status);
            if ($record) {
                $record->delete();
                $allData = WorkingRegion::select('id','region_code','region_name_en')->get();
                foreach ($allData as $allDataRow) {
                    $html = '<a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('workingregion.edit', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                             <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="workingregion" data-id="' . $allDataRow->id . '" data-url="' . route('workingregion.destroy', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData,'message'=>'The record has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'working region not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
