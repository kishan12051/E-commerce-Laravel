<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\VoucherType;
use App\Models\Employees;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;

class VouchertypeController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:voucher-type-list', ['only' => ['index','show']]);
        $this->middleware('permission:voucher-type-create', ['only' => ['create','store']]);
        $this->middleware('permission:voucher-type-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:voucher-type-delete', ['only' => ['destroy']]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function index(Request $request)
    {
        $vouchertypes = VoucherType::get();
        $page_title = "Lists Of Voucher Type";
        return view('voucher-type.index',compact('vouchertypes','page_title'))->with('i');
    }
    public function create()
    {   
        return view('voucher-type.create');
    }
    public function store(Request $request)
    {
        $userId = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();
        $errormsg = 'This field is required';
        $request->validate([
            'voucher_type_en' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingVoucherType = VoucherType::where('voucher_type_en', $value)->first();
                    if ($existingVoucherType) {
                        $fail('Voucher Type for english already exists');
                    }
                },
            ],
            'voucher_type_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingVoucherType = VoucherType::where('voucher_type_ru', $value)->first();
                    if ($existingVoucherType) {
                        $fail('Voucher Type for russian already exists');
                    }
                },
            ],
            'voucher_type_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingVoucherType = VoucherType::where('voucher_type_tu', $value)->first();
                    if ($existingVoucherType) {
                        $fail('Voucher Type for Türkmen already exists');
                    }
                },
            ],
        ], [
            'voucher_type_en.required' =>  $errormsg,
            'voucher_type_ru.required' =>  $errormsg,
            'voucher_type_tu.required' =>  $errormsg
        ]);

        $VoucherType = new VoucherType();
        $VoucherType->user_id         = $userId;
        $VoucherType->employee_id     = $employee->id;
        $VoucherType->voucher_type_en = $request->voucher_type_en;
        $VoucherType->voucher_type_ru = $request->voucher_type_ru;
        $VoucherType->voucher_type_tu = $request->voucher_type_tu;
        $VoucherType->save();
        return redirect()->route('voucher-type.index')->with('message', 'Voucher Type created successfully');
    }

    public function edit($id)
    {
        $voucherType = VoucherType::findOrFail($id);
        return view('voucher-type.edit', compact('voucherType'));
    }

    public function update(Request $request, $id)
    {
        $userId = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();
        
        $errormsg = 'This field is required.';
        $errormsgen = 'Voucher Type for English already exists.';
        $errormsgru = 'Voucher Type for Russian already exists.';
        $errormsgtk = 'Voucher Type for Türkmen already exists.';

        $request->validate([
            'voucher_type_en' => 'required|unique:voucher_type,voucher_type_en,'.$id,
            'voucher_type_ru' => 'required|unique:voucher_type,voucher_type_ru,'.$id,
            'voucher_type_tu' => 'required|unique:voucher_type,voucher_type_tu,'.$id,
        ],[
 
            'voucher_type_en.required' =>  $errormsg,
            'voucher_type_ru.required' =>  $errormsg,
            'voucher_type_tu.required' =>  $errormsg,
            'voucher_type_en.unique' => $errormsgen,
            'voucher_type_ru.unique' => $errormsgru,
            'voucher_type_tu.unique' => $errormsgtk
        ]);

        try {
            $voucherType = VoucherType::findOrFail($id);
            $voucherType->update([
                'user_id'           => $userId,
                'employee_id'       => $employee->id,
                'voucher_type_en'   => $request->input('voucher_type_en'),
                'voucher_type_ru'   => $request->input('voucher_type_ru'),
                'voucher_type_tu'   => $request->input('voucher_type_tu'),
            ]);
            return redirect()->route('voucher-type.index')->with('message', 'Voucher Type updated successfully');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return Redirect::back()->withErrors(['error' => 'An error occurred.']);
        }
    }

    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = VoucherType::find($request->status);
            if ($record) {
                $record->delete();
                $default_language = get_default_language();
                $allData = VoucherType::select('id', 'voucher_type_'.$default_language)->get();                
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('voucher-type.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="voucher-type" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData, 'message' => 'Voucher Type deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Voucher Type not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
