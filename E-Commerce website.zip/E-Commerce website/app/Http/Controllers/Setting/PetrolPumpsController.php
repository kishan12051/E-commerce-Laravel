<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\PetrolPumps;
use App\Models\Reservoirs;
use App\Models\PetrolType;
use App\Models\Employees;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;

class PetrolPumpsController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:petrol-pumps-list', ['only' => ['index','show']]);
        $this->middleware('permission:petrol-pumps-create', ['only' => ['create','store']]);
        $this->middleware('permission:petrol-pumps-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:petrol-pumps-delete', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $page_title = "List Of Petrol Pumps";
        $userId = Auth::user()->id;
        $petrolpumps = PetrolPumps::where('user_id', $userId)->get();
        return view('petrol-pumps.index',compact('petrolpumps','page_title'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $default_language = get_default_language();
        $reservoirs = Reservoirs::where('status', '1')->pluck('reservoir_type_' . $default_language, 'id');
        $petroltype = PetrolType::where('status', 'Y')->pluck('petrol_type_' . $default_language, 'id');
        return view('petrol-pumps.create',compact('reservoirs','petroltype'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
     
        $errormsg = 'This field is required';
        $userId = Auth::user()->id;
        $employees = Employees::where('user_id', $userId)->first();
        $request->validate([
            'pump_name_en' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = PetrolPumps::where('pump_name_en', $value)->first();
                    if ($existingDesignation) {
                        $fail('Pump name for english already exists');
                    }
                },
            ],
            'pump_name_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = PetrolPumps::where('pump_name_ru', $value)->first();
                    if ($existingDesignation) {
                        $fail('Pump name for russian already exists');
                    }
                },
            ],
            'pump_name_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = PetrolPumps::where('pump_name_tu', $value)->first();
                    if ($existingDesignation) {
                        $fail('Pump name for turkmen already exists');
                    }
                },
            ],
            'reservoir_id'   => 'required',
            'petrol_type_id' => 'required',
            'pumpid'         => 'required',
            'status'         => 'required'
        ], [
            'pump_name_en.required'     =>  $errormsg,
            'pump_name_ru.required'     =>  $errormsg,
            'pump_name_tu.required'     =>  $errormsg,
            'reservoir_id.required'     =>  $errormsg,
            'petrol_type_id.required'   =>  $errormsg,
            'pumpid.required'           =>  $errormsg,
            'status.required'           =>  $errormsg
        ]);
        $PetrolPumps = new PetrolPumps();
            $PetrolPumps->user_id           = $userId;
            $PetrolPumps->employee_id       = $employees->id;
            $PetrolPumps->reservoir_id      = $request->reservoir_id;
            $PetrolPumps->petrol_type_id    = $request->petrol_type_id;
            $PetrolPumps->pumpid            = $request->pumpid ;
            $PetrolPumps->pump_name_en      = $request->pump_name_en;
            $PetrolPumps->pump_name_ru      = $request->pump_name_ru;
            $PetrolPumps->pump_name_tu      = $request->pump_name_tu;
            $PetrolPumps->status            = $request->status;
            $PetrolPumps->save();
            return redirect()->route('petrol-pumps.index')
        ->with('message', 'Petrol Pump Added successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $default_language   = get_default_language();
        $petrolpump         = PetrolPumps::findOrFail($id);
        $reservoirs         = Reservoirs::where('status', '1')->pluck('reservoir_type_' . $default_language, 'id');
        $petroltype         = PetrolType::where('status', 'Y')->pluck('petrol_type_' . $default_language, 'id');
        return view('petrol-pumps.edit',compact('petrolpump','reservoirs','petroltype'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        $userId = Auth::user()->id;
        $employees = Employees::where('user_id', $userId)->first();
        $errormsg = 'This field is required';
        $request->validate([
            'pump_name_en'      => 'required|unique:petrol_pumps,pump_name_en,'.$id,
            'pump_name_ru'      => 'required|unique:petrol_pumps,pump_name_ru,'.$id,
            'pump_name_tu'      => 'required|unique:petrol_pumps,pump_name_tu,'.$id,
            'reservoir_id'      => 'required',
            'petrol_type_id'    => 'required',
            'pumpid'            => 'required',
            'status'            => 'required'
        ], [
            'pump_name_en.required'     => $errormsg,
            'pump_name_ru.required'     => $errormsg,
            'pump_name_tu.required'     => $errormsg,
            'pump_name_en.unique'       => 'Pump name for English already exists.',
            'pump_name_ru.unique'       => 'Pump name for Russian already exists.',
            'pump_name_tu.unique'       => 'Pump name for Turkmen already exists.',
            'reservoir_id.required'     => $errormsg,
            'petrol_type_id.required'   => $errormsg,
            'pumpid.required'           => $errormsg,
            'status.required'           => $errormsg
        ]);

        $petrolPump = PetrolPumps::find($id);

        if ($petrolPump) {
            $petrolPump->user_id        = $userId;
            $petrolPump->employee_id    = $employees->id;
            $petrolPump->reservoir_id   = $request->reservoir_id;
            $petrolPump->petrol_type_id = $request->petrol_type_id;
            $petrolPump->pumpid         = $request->pumpid;
            $petrolPump->pump_name_en   = $request->pump_name_en;
            $petrolPump->pump_name_ru   = $request->pump_name_ru;
            $petrolPump->pump_name_tu   = $request->pump_name_tu;
            $petrolPump->status         = $request->status;
            $petrolPump->save();
            return redirect()->route('petrol-pumps.index')
            ->with('message', 'Petrol Pump updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function changepetrolStatus(Request $request)
    {
        $data = $request->all();
         $petrolpumps = PetrolPumps::find($data['id']);
         if (!$petrolpumps) {
            return response()->json(['message' => 'Petrol Pump not found'], 404);
        }
        /* Toggle the employee's status */
        $petrolpumps->status = ($petrolpumps->status === 0) ? 1 : 0;
        $newStatus = $petrolpumps->status === 0 ? 'Active' : 'Deactivate';
        if($petrolpumps->save()){             
            return response()->json(['success' => true ,'newStatus' => $newStatus ,'message' => 'Petrol Pump status updated successfully']);
        }else{
            return response()->json(['success' => false ,'newStatus' => $newStatus, 'message' => 'Something Wents wrong']);
        }
    }

    public function destroy(Request $request)
    {
        $userId = Auth::user()->id;
        if (isset($request->status)) {
            $record = PetrolPumps::find($request->status);
            if ($record) {
                $record->delete();
                $default_language = get_default_language();
                $allData = DB::table('petrol_pumps')
                ->join('reservoirs', 'petrol_pumps.reservoir_id', '=', 'reservoirs.id')
                ->join('petrol_types', 'petrol_pumps.petrol_type_id', '=', 'petrol_types.id')
                ->select(
                    'petrol_pumps.id',
                    'reservoirs.reservoir_type_'.$default_language,
                    'petrol_types.petrol_type_'.$default_language,
                    'petrol_pumps.pumpid',
                    'petrol_pumps.pump_name_'.$default_language,
                    'petrol_pumps.status'
                )
                ->where('petrol_pumps.user_id', $userId)
                ->whereNull('petrol_pumps.deleted_at')
                ->get();
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('petrol-pumps.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="petrol-pumps" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $status = '<button class="btn btn-' . ($allDataRow->status === 0 ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="petrol-pump" data-id="' . $allDataRow->id . '">'
                        . ($allDataRow->status === 0 ? 'Activate' : 'Deactivate') . ''
                        . '</button>';
                    $allDataRow->status = $status;
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData, 'message' => 'Petrol Pump deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Petrol Pump not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
