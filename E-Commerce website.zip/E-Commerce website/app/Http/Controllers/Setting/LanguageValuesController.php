<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use App\Models\Employees;
use App\Models\User;
use DB;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Response;
use Spatie\Permission\Models\Role;
use App\Models\Language;
use App\Models\LanguageValues;

class LanguageValuesController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:lang-values-list', ['only' => ['index','show']]);
        $this->middleware('permission:lang-values-create', ['only' => ['create','store']]);
        $this->middleware('permission:lang-values-edit', ['only' => ['edit','update','saveAllLangData']]);
        $this->middleware('permission:lang-values-delete', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page_title = 'Lists Of Language Values';
        $languageValues = LanguageValues::get();
        $languages = Language::get();
        session()->forget('edit_url');
        session(['index_url' => url()->current()]);
        return view('language-values.index',compact('languages','languageValues','page_title'))->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $languages = Language::get();
        return view('language-values.create',compact('languages'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $errormsg = 'This field is required';
        $validationRules = ['lang_key' => 'required',];
        $customMessages  = ['lang_key.required' => $errormsg,];

        $request->validate($validationRules, $customMessages);
        if (request()->isMethod('post')) {
            try {
                $languageValue = new LanguageValues();
                $languageValue->lang_key = $request->lang_key;
                $languageValue->lang_values = json_encode($request->lang_values);
                $languageValue->created_at = now();
                $languageValue->save();
                // dd($languageValue);

                if(session()->has('index_url')) {
                    return redirect()->route('language-values.index')->with('message', 'The record has been saved successfully');
                }
                elseif (session()->has('edit_url')) {
                    return redirect(session('edit_url'))->with('message', 'The record has been saved successfully');
                }
            } catch (\Exception $e) {
                return redirect()->route('language-values.index')->with('error', 'An error occurred while creating the language Values.');
            }
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $languages = Language::when($id, function ($query, $id) {
            return $query->where('id', $id);
        })->orderBy('serial_no', 'ASC')->get();
        $find_language_values = LanguageValues::orderBy('id', 'ASC')->get();
        session()->forget('index_url');
        session(['edit_url' => url()->current()]);
        return view('language-values.edit',compact('find_language_values', 'languages', 'id'))->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

     public function update(Request $request,$id = null)
{
    $languages = [];
    if (!empty($id)) {
        $languages = Language::where('id', $id)->orderBy('serial_no', 'ASC')->get();
    } else {
        $languages = Language::orderBy('serial_no', 'ASC')->get();
    }

    $find_language_values = LanguageValues::orderBy('id', 'ASC')->get();
        if (request()->isMethod('PATCH')) {


            // Validate and save the data
        $error_flag = false;


        if (request()->has('lang_key')) {
            foreach (request('lang_key') as $key => $val) {
                $languageValue = LanguageValues::find($key);

                $update_data = [
                    'lang_key' => $val,
                    'lang_values' => json_encode(request('lang_values')[$key]),
                    'modified_at' => now(), // Assuming 'modified_at' is a timestamp field
                    'modified_by' => auth()->user()->id, // Assuming you have authentication set up
                ];



                $languageValue->fill($update_data);

                if ($languageValue->save()) {
                    // Record saved successfully
                } else {
                    $error_flag = true;
                }
            }
        }

        if ($error_flag) {
            return back()->with('error', 'Some records could not be saved. Please, try again.');
        } else {
            return redirect()->route('language-values.edit', $id)->with('message', 'The record has been updated successfully');
        }
    }

    return view('language-values.edit')->with(['find_language_values' => $find_language_values, 'languages' => $languages, 'id' => $id]);
}


    public function saveAllLangData(Request $request)
    {
        if (request()->isMethod('post')) {
            if (request()->has('lang_key') && !empty(request()->input('lang_key'))) {
                foreach (request()->input('lang_key') as $key => $val) {
                    $languageValue = LanguageValues::findOrFail($key);
                    $languageValue->lang_key = $val;
                    $languageValue->lang_values = json_encode(request()->input('lang_values')[$key]);
                    $languageValue->save();
                }
            }
            return redirect()->route('language-values.index')->with('message','The record has been updated successfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = LanguageValues::find($request->status);
            if ($record) {
                $record->delete();
                $langData = LanguageValues::select('id', 'lang_key', 'lang_values')->get();
                $allData = [];
                foreach ($langData as $allDataRow) {
                    $rowData = [
                        'id' => $allDataRow->id,
                        'lang_key' => $allDataRow->lang_key,
                    ];
                    $langValues = json_decode($allDataRow->lang_values, true);
                    $langFilteredValues = array_slice($langValues, 0, 3);
                    foreach ($langFilteredValues as $key => $value) {
                        $rowData['lang_value_' . $key] = '<input type="text" name="lang_values[' . $allDataRow->id . '][' . $key . ']" value="' . $value . '" class="form-control" autocomplete="off">';
                    }
                    for ($i = count($langFilteredValues); $i < 3; $i++) {
                        $rowData['lang_value_' . $i] = '<input type="text" name="lang_values[' . $allDataRow->id . '][' . $i . ']" value="" class="form-control" autocomplete="off">';
                    }
                    $rowData['action'] = '<button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="language-values" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $allData[] = $rowData;
                }
                return response()->json(['data' => $allData, 'message' => 'Language value has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'The record has not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
