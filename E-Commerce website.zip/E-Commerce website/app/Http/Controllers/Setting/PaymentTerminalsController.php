<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PaymentTerminals;
use Illuminate\Support\Facades\Response;
use App\Models\Bank;
use App\Models\Employees;
use App\Models\PetrolType;
use App\Models\Reservoirs;
use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use DataTables;
use Illuminate\Console\View\Components\Alert;

class PaymentTerminalsController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
        $this->middleware('permission:payment-terminals-list', ['only' => ['index', 'show']]);
        $this->middleware('permission:payment-terminals-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:payment-terminals-show', ['only' => ['edit', 'update']]);
        $this->middleware('permission:payment-terminals-delete', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (request()->ajax()) {
            $data = PaymentTerminals::orderBy('id', 'DESC')->get()->toArray();
            foreach ($data as $key => $value) {
                $petrolType =  PetrolType::whereIn('id', explode(',', $value['petrol_types']))->get()->toArray();
                $data[$key]['petrol_types'] = $petrolType;
            }
            return DataTables()->of($data)->addIndexColumn()->make(true);
        }

        return view('payment-terminals.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $default_language = get_default_language();
        $findAvailablePetrolTypeIds = Reservoirs::where('user_id', Auth::user()->id)
            ->where('status', 1)
            ->selectRaw('GROUP_CONCAT(DISTINCT(petrol_type_id)) as petrol_type_ids')
            ->first();

        $petrolPumpTypeId = [];
        if ($findAvailablePetrolTypeIds && $findAvailablePetrolTypeIds->petrol_type_ids) {
            $petrolPumpTypeId = explode(",", $findAvailablePetrolTypeIds->petrol_type_ids);
        }

        $findPumpPetrolType = PetrolType::whereIn('id', $petrolPumpTypeId)
            ->where('status', 'Y')
            ->get()->toArray();

        $bank = Bank::where('status', 'Y')->pluck('bank_name', 'id');

        return view('payment-terminals.create', compact('findPumpPetrolType', 'bank'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
{
    $request->validate([
        'terminal_name' => 'required',
        'terminal_number' => 'required',
        'bank_id' => 'required',
        'petrol_types_data' => 'required',
    ], [
        'terminal_name.required' => 'Payment terminal name is required.',
        'terminal_number.required' => 'Payment terminal number is required.',
        'bank_id.required' => 'Payment terminal bank is required.',
        'petrol_types_data.required' => 'Petrol types data is required.',
    ]);

    // Check if the combination already exists
    $existingTerminal = PaymentTerminals::where([
        'terminal_name' => $request->terminal_name,
        'terminal_number' => $request->terminal_number,
        'bank_id' => $request->bank_id,
    ])->first();

    if ($existingTerminal) {
        return redirect()->route('payment-terminals.index')->with('message', 'This combination already exists');
    }

    $findPetrolTypesDetails = PetrolType::whereIn('id', $request['petrol_types_data'])->get();
    $data['petrol_type_details'] = $findPetrolTypesDetails->toJson();

    // Create a new PaymentTerminals record
    $adminId = Auth::user()->id;
    $bankDetails = Bank::find($request->bank_id);

    $PaymentTerminals = new PaymentTerminals();
    $PaymentTerminals->terminal_name = $request->terminal_name;
    $PaymentTerminals->terminal_number = $request->terminal_number;
    $PaymentTerminals->bank_id = $request->bank_id;
    $PaymentTerminals->bank_name = $bankDetails->bank_name;
    $PaymentTerminals->petrol_types = implode(",", $request['petrol_types_data']);
    $PaymentTerminals->petrol_type_details = $data['petrol_type_details'];
    $PaymentTerminals->status = $request->status == 'Y' ? 'Y' : 'N';
    $PaymentTerminals->created_at = now();
    $PaymentTerminals->created_by = $adminId;
    $PaymentTerminals->save();

    return redirect()->route('payment-terminals.index')->with('message', 'Payment Type Added successfully.');
}


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $default_language = get_default_language();
        $findAvailablePetrolTypeIds = Reservoirs::where('user_id', Auth::user()->id)
            ->where('status', 1)
            ->selectRaw('GROUP_CONCAT(DISTINCT(petrol_type_id)) as petrol_type_ids')
            ->first();

        $petrolPumpTypeId = [];
        if ($findAvailablePetrolTypeIds && $findAvailablePetrolTypeIds->petrol_type_ids) {
            $petrolPumpTypeId = explode(",", $findAvailablePetrolTypeIds->petrol_type_ids);
        }

        if (isset($id)) {
            $paymentTerminals = PaymentTerminals::findOrFail($id);
            $paymentTerminals = $paymentTerminals->toArray(); // Or use $user->attributesToArray()
            $bank = Bank::where('status', 'Y')->pluck('bank_name', 'id');
            $findPumpPetrolType = PetrolType::whereIn('id', $petrolPumpTypeId)
                ->where('status', 'Y')
                ->get()->toArray();
            if($paymentTerminals['status'] == "Y"){
                $bank_status = 0;
            }
            else if($paymentTerminals['status'] == "N"){
                $bank_status = 1;
            }

            return view('payment-terminals.edit', compact('paymentTerminals','bank','bank_status','findPumpPetrolType'));
        } else {
            $data = "No data Found";
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
{
    // Retrieve the existing record
    $existingTerminal = PaymentTerminals::findOrFail($id);

    $request->validate([
        'terminal_name' => 'required',
        'terminal_number' => 'required',
        'bank_id' => 'required',
        'petrol_types_data' => 'required',
    ], [
        'terminal_name.required' => 'Payment terminal name is required.',
        'terminal_number.required' => 'Payment terminal number is required.',
        'bank_id.required' => 'Payment terminal bank is required.',
        'petrol_types_data.required' => 'Petrol types data is required.',
    ]);

    // Check if the combination already exists and is not the same as the existing record
    $combinationExists = PaymentTerminals::where([
        'terminal_name' => $request->terminal_name,
        'terminal_number' => $request->terminal_number,
        'bank_id' => $request->bank_id,
    ])->where('id', '!=', $id)->exists();

    if ($combinationExists) {
        return redirect()->back()->with('message', 'This combination already exists');
    }

    // Update the record with the new data
    $findPetrolTypesDetails = PetrolType::whereIn('id', $request['petrol_types_data'])->get();
    $data['petrol_type_details'] = $findPetrolTypesDetails->toJson();

    $adminId = Auth::user()->id;
    $bankDetails = Bank::find($request->bank_id);

    $existingTerminal->terminal_name = $request->terminal_name;
    $existingTerminal->terminal_number = $request->terminal_number;
    $existingTerminal->bank_id = $request->bank_id;
    $existingTerminal->bank_name = $bankDetails->bank_name;
    $existingTerminal->petrol_types = implode(",", $request['petrol_types_data']);
    $existingTerminal->petrol_type_details = $data['petrol_type_details'];
    $existingTerminal->status = $request->status == 'Y' ? 'Y' : 'N';
    $existingTerminal->created_at = now();
    $existingTerminal->created_by = $adminId;
    $existingTerminal->save();

    return redirect()->route('payment-terminals.index')->with('message', 'Payment Type updated successfully.');
}


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function destroy(Request $request, $id)
    {
        if (!isset($request->status)) {
            return response()->json(['error' => 'Invalid request'], 400);
        }

        $record = Reservoirs::find($request->status);

        if (!$record) {
            return response()->json(['error' => 'Reservoir not found'], 404);
        }

        $record->delete();
        $default_language = get_default_language();
        $userId = Auth::user()->id;

        $allData = DB::table('reservoirs')
            ->join('matrix_templates', 'reservoirs.matrix_template_id', '=', 'matrix_templates.id')
            ->join('petrol_types', 'reservoirs.petrol_type_id', '=', 'petrol_types.id')
            ->select(
                'reservoirs.id',
                'reservoirs.reservoir_type_' . get_default_language(),
                'matrix_templates.template_name_'. get_default_language(),
                'petrol_types.petrol_type_' . get_default_language(),
                'reservoirs.capacity_kg',
                'reservoirs.capacity_liter',
                'reservoirs.status'
            )
            ->where('matrix_templates.user_id', $userId)
            ->get();
        $allData->transform(function ($allDataRow) {

            $html = '<a href="' . route('manage-reservoirs.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                    <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="manage-reservoirs" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
            $status = '<button class="btn btn-' . ($allDataRow->status == 1 ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="manage-reservoirs" data-id="' . $allDataRow->id . '">'
                    . ($allDataRow->status == 1 ? 'Activate' : 'Deactivate') . ''
                    . '</button>';
            $allDataRow->status = $status;
            $allDataRow->action = $html;
            unset($allDataRow->id);
            return $allDataRow;
        });

        return response()->json(['data' => $allData, 'message' => 'Reservoir deleted successfully.'], 200);
    }

    public function changepaymentStatus(Request $request)
    {
        $data = $request->all();
        $paymentterminals = PaymentTerminals::find($data['id']);
        if (!$paymentterminals) {
            return response()->json(['message' => 'Payment Terminal not found'], 404);
        }
        /* Toggle the employee's status */
        $paymentterminals->status = ($paymentterminals->status === 'Y') ? "N" : "Y";

        $newStatus = $paymentterminals->status === 'Y' ? 'Active' : 'Deactivate';
        if ($paymentterminals->save()) {
            return response()->json(['success' => true, 'newStatus' => $newStatus, 'message' => 'Payment Terminal status updated successfully']);
        } else {
            return response()->json(['success' => false, 'newStatus' => $newStatus, 'message' => 'Something Wents wrong']);
        }
    }
}
