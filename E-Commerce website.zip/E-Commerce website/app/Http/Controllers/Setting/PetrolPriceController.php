<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use App\Models\Employees;
use App\Models\PetrolPrice;
use App\Models\PetrolType;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;

class PetrolPriceController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:petrol-price-list', ['only' => ['index','show']]);
        $this->middleware('permission:petrol-price-create', ['only' => ['create','store']]);
        $this->middleware('permission:petrol-price-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:petrol-price-delete', ['only' => ['destroy']]);
    }
    public function index()
    {
        $page_title = "Lists Of Petrol Price";
        $petrolPrices = PetrolPrice::with('petrolType')->orderBy('id', 'DESC')->get();
        return view('petrolprice.index', compact('petrolPrices', 'page_title'))->with('i');
    }

    public function create()
    {
        $default_language = get_default_language();
        $petrolTypes = PetrolType::where('status', 'Y')->pluck('petrol_type_'.$default_language, 'id');
        return view('petrolprice.create', compact('petrolTypes'));
    }

    public function store(Request $request)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'petrol_type_id' => 'required',
            'price' => 'required',
            'start_date_time' => 'required|date_format:d/m/Y',
            'end_date_time' => 'required|date_format:d/m/Y|after:start_date_time',
        ], [
            'petrol_type_id.required' => 'This field is required',
            'price.required' => 'This field is required',
            'start_date_time.required' => 'This field is required',
            'start_date_time.date_format' => 'The start date must be in the format d/m/Y.',
            'end_date_time.required' => 'This field is required',
            'end_date_time.date_format' => 'The end date must be in the format d/m/Y.',
            'end_date_time.after' => 'The end date must be after the start date',

        ]);

        $adminId = auth()->user()->id;
        $employee = Employees::where('user_id', $adminId)->first();

        $petrolPrice = new PetrolPrice();
        $petrolPrice->petrol_type_id = $request->input('petrol_type_id');
        $petrolPrice->price = $request->input('price');
        $petrolPrice->start_date_time = Carbon::createFromFormat('d/m/Y', $request->input('start_date_time'));
        $petrolPrice->end_date_time = Carbon::createFromFormat('d/m/Y', $request->input('end_date_time'));
        $petrolPrice->created_admin_id = $adminId;
        $petrolPrice->created_employee_id = $employee->id;
        $petrolPrice->updated_admin_id = $adminId;
        $petrolPrice->updated_employee_id = $employee->id;

        if ($petrolPrice->save()) {
            return redirect()->route('petrolprice.index')->with('message', __('The record has been saved successfully'));
        } else {
            return redirect()->back()->with('error', __('Failed to add petrol price. Please try again.'));
        }
    }

    public function edit($id)
    {
        $default_language = get_default_language();
        $petrolPrice = PetrolPrice::findOrFail($id);
        $petrolPrice->start_date_time = Carbon::createFromFormat('Y-m-d H:i:s', $petrolPrice->start_date_time)->format('d/m/Y H:i');
        $petrolPrice->end_date_time = Carbon::createFromFormat('Y-m-d H:i:s', $petrolPrice->end_date_time)->format('d/m/Y H:i');
        $petrolTypes = PetrolType::where('status', 'Y')->pluck('petrol_type_'.$default_language, 'id');
        return view('petrolprice.edit', compact('petrolPrice', 'petrolTypes'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'petrol_type_id' => 'required',
            'price' => 'required',
            'start_date_time' => 'required|date_format:d/m/Y',
            'end_date_time' => 'required|date_format:d/m/Y|after:start_date_time',
        ], [
            'petrol_type_id.required' => 'This field is required',
            'price.required' => 'This field is required',
            'start_date_time.required' => 'This field is required',
            'start_date_time.date_format' => 'The start date must be in the format d/m/Y.',
            'end_date_time.required' => 'This field is required',
            'end_date_time.date_format' => 'The end date must be in the format d/m/Y.',
            'end_date_time.after' => 'The end date must be after the start date',
        ]);

        $petrolPrice = PetrolPrice::findOrFail($id);

        try {
            $petrolPrice->petrol_type_id = $request->input('petrol_type_id');
            $petrolPrice->price = $request->input('price');
            $petrolPrice->start_date_time = Carbon::createFromFormat('d/m/Y', $request->input('start_date_time'));
            $petrolPrice->end_date_time = Carbon::createFromFormat('d/m/Y', $request->input('end_date_time'));
            $petrolPrice->save();
            return redirect()->route('petrolprice.index')->with('message', 'The record has been updated successfully');
        }
        catch (\Exception $e) {
            Log::error($e->getMessage());
            return Redirect::back()->withErrors(['error' => 'An error occurred.']);
        }
    }

    public function destroy(Request $request, $id)
    {
        if (!isset($request->status)) {
            return response()->json(['error' => 'Invalid request'], 400);
        }
        $record = PetrolPrice::find($request->status);
        if (!$record) {
            return response()->json(['error' => 'Petrol price not found'], 404);
        }
        $record->delete();

        $allData = PetrolPrice::with('petrolType')
            ->select('id', 'petrol_type_id', 'price', DB::raw('CONCAT(DATE(start_date_time), " - ", DATE(end_date_time)) as date_range'),
                'created_employee_id', 'updated_employee_id', 'created_date', 'updated_date')
            ->orderBy('id', 'DESC')
            ->get();

        $allData->transform(function ($allDataRow) {

            $allDataRow->petrol_type_id = $allDataRow->petrolType->getAttribute('petrol_type_' . get_default_language());
            $allDataRow->created_employee_id = $allDataRow->createdDateWithOrganization();
            $allDataRow->updated_employee_id = $allDataRow->updatedDateWithOrganization();

            $html = '<a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('petrolprice.edit', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                    <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="petrolprice" data-id="' . $allDataRow->id . '" data-url="' . route('petrolprice.destroy', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';

            $allDataRow->action = $html;
            unset($allDataRow->created_date);
            unset($allDataRow->updated_date);

            return $allDataRow;
        });

        return response()->json(['data' => $allData, 'message' => 'The record has been deleted successfully.'], 200);
    }

}
