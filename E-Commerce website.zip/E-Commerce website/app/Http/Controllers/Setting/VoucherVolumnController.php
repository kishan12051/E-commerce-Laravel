<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\VoucherVolumn;
use App\Models\VoucherType;
use App\Models\Employees;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;


class VoucherVolumnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct(){
        $this->middleware('permission:voucher-volumn-list', ['only' => ['index','show']]);
        $this->middleware('permission:voucher-volumn-create', ['only' => ['create','store']]);
        $this->middleware('permission:voucher-volumn-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:voucher-volumn-delete', ['only' => ['destroy']]);
    }
    
    public function index()
    {
        // $vouchervolumns = VoucherVolumn::get();
        $page_title = "Lists Of Voucher Volumn";
        $vouchervolumns = VoucherVolumn::with('VoucherType')->orderBy('id', 'DESC')->get();
        return view('voucher-volumn.index',compact('vouchervolumns','page_title'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $default_language = get_default_language();
        $vouchertypes = VoucherType::select('id', 'voucher_type_en')
        ->get()
        ->pluck('voucher_type_'.$default_language, 'id');
        return view('voucher-volumn.create',compact('vouchertypes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $userId = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();
        $errormsg = 'This field is required';
        $request->validate([
            'voucher_type' => 'required',
            'volumn' => 'required',
           
        ], [
            'voucher_type.required' =>  $errormsg,
            'volumn.required' =>  $errormsg,
        ]);

        $vouchervolumns = new VoucherVolumn();
        $vouchervolumns->user_id         = $userId;
        $vouchervolumns->employee_id     = $employee->id;
        $vouchervolumns->voucher_type    = $request->voucher_type;
        $vouchervolumns->volumn          = $request->volumn;
        $vouchervolumns->save();
        return redirect()->route('voucher-volumn.index')->with('message', 'Voucher Volumn created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $default_language = get_default_language();
        $vouchertypes = VoucherType::select('id', 'voucher_type_en')
        ->get()
        ->pluck('voucher_type_'.$default_language, 'id');
        $vouchervolumns = VoucherVolumn::findOrFail($id);
        return view('voucher-volumn.edit', compact('vouchervolumns','vouchertypes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'voucher_type' => 'required',
            'volumn' => 'required',
           
        ], [
            'voucher_type.required' =>  $errormsg,
            'volumn.required' =>  $errormsg,
        ]);

        $userId = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();

        $vouchervolumns = VoucherVolumn::findOrFail($id);
        try {
            $vouchervolumns->update([
                'user_id'           => $userId,
                'employee_id'       => $employee->id,
                'voucher_type'      => $request->input('voucher_type'),
                'volumn'            => $request->input('volumn'),
            ]);
            return redirect()->route('voucher-volumn.index')->with('message', 'Voucher Volumn updated successfully');
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            return Redirect::back()->withErrors('message', 'An error occurred.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = VoucherVolumn::find($request->status);
            if ($record) {
                $record->delete();
                $default_language = get_default_language();

                $allData = DB::table('voucher_volumn')
                ->join('voucher_type', 'voucher_volumn.voucher_type', '=', 'voucher_type.id')
                ->select(
                    'voucher_volumn.id',
                    'voucher_type.voucher_type_'.$default_language,
                    'voucher_volumn.volumn',
                )
                ->whereNull('voucher_volumn.deleted_at')
                ->orderBy('voucher_volumn.id', 'DESC')
                ->get();
            
                
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('voucher-volumn.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="voucher-volumn" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData, 'message' => 'Voucher Volumn deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Voucher Volumn not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
