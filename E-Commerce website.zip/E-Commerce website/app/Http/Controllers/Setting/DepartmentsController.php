<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Departments;
use App\Helpers\Helpers;
use Illuminate\Support\Facades\Log;
use Collective\Html\FormFacade as Form;
use Illuminate\Support\Facades\Response;


class DepartmentsController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
     */

     function __construct()
    {

         $this->middleware('permission:departments-list|departments-create|departments-edit|departments-delete', ['only' => ['index','show']]);
         $this->middleware('permission:departments-create', ['only' => ['create','store']]);
         $this->middleware('permission:departments-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:departments-delete', ['only' => ['destroy']]);

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
    */
    public function index()
    {
        $page_title       = 'LISTS OF DEPARTMENTS';
        $departments = Departments::with('parentDepartment')->orderBy('id', 'DESC')->get()->toArray();
        return view('departments.index',compact('departments','page_title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $default_language = get_default_language();
        $parentDepartment = Departments::where('is_parent', 0)
            ->where('status','Y')
            ->limit(200)
            ->pluck('title_' . $default_language, 'id');
        $page_title       = 'CREATE NEW DEPARTMENTS';
        return view('departments.create',compact('parentDepartment','page_title'));
        //return view('departments.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $errormsg = 'This field is required.';
        $request->validate([/* 'is_parent' => ['required'], */
            'title_en' => ['required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Departments::where('title_en', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for english already exists.');
                    }
                },
            ],
            'title_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Departments::where('title_ru', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for russian already exists.');
                    }
                },
            ],
            'title_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Departments::where('title_tu', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for Türkmen already exists.');
                    }
                },
            ],
        ], [
            /* 'is_parent.required' =>  $errormsg, */
            'title_en.required' =>  $errormsg,
            'title_ru.required' =>  $errormsg,
            'title_tu.required' =>  $errormsg,

        ]);
        if($request->ParentDepartments != '' && $request->ParentDepartments != NULL){
            $ParentDepartments = $request->ParentDepartments;
        }else{
            $ParentDepartments = 0;
        }

        $Departments                    = new Departments();
        $Departments->department_code   = "DEP-".rand("999999", '111111');
        $Departments->title_en          = $request->title_en;
        $Departments->title_ru          = $request->title_ru;
        $Departments->title_tu          = $request->title_tu;
        $Departments->is_parent         = $ParentDepartments;
        $Departments->created_at        = now();
        $Departments->save();
        return redirect()->route('departments.index')->with('message', 'Record has been saved successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $default_language = get_default_language();
        $page_title       = 'EDIT DEPARTMENTS';
        $alldepartment = Departments::pluck('title_en','id')->all();
        if(isset($id)){
            $parentDepartment = Departments::where('is_parent', 0)
            ->where('id', '<>', $id)
            ->where('status','Y')
            ->limit(200)
            ->pluck('title_' . $default_language, 'id');



         $record = Departments::findOrFail($id);
            $data = $record->toArray(); // Or use $user->attributesToArray()
            return view('departments.edit',compact('parentDepartment','record','alldepartment','page_title') );
        }else{
            $data = "No data Found";
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messages = [
            'title_en.required' => 'The field is required.',
            'title_ru.required' => 'The field is required.',
            'title_tu.required' => 'The field is required.',
            'title_en.unique' => 'Title for english already exists.',
            'title_ru.unique' => 'Title for russian already exists.',
            'title_tu.unique' => 'TTitle for Türkmen already exists.'
        ];

        $this->validate($request, [
            'title_en' => 'required|unique:departments,title_en,'.$id,
            'title_ru' => 'required|unique:departments,title_ru,'.$id,
            'title_tu' => 'required|unique:departments,title_tu,'.$id
        ], $messages);

        if($request->is_parent != '' && $request->is_parent != NULL){
            $is_parent = $request->is_parent;
        }else{
            $is_parent = 0;
        }

        $department = Departments::findOrFail($id);
        if($department){
        $department->title_en = $request->title_en;
        $department->title_ru = $request->title_ru;
        $department->title_tu = $request->title_tu;
        $department->is_parent = $is_parent;
        $department->updated_at = now();
        $department->save();
        return redirect()->route('departments.index')
        ->with('message', 'Record has been updated successfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = Departments::find($request->status);
            if ($record) {
                $record->delete();
                $allData = Departments::with('parentDepartment')
                    ->select('id', 'department_code', 'is_parent', 'title_en')
                    ->orderBy('id', 'DESC')
                    ->get();
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a href="' . route('departments.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="departments" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $matchingDepartment = $allData->where('id', $allDataRow->is_parent)->first();
                    if ($matchingDepartment) {
                        $allDataRow->is_parent = $matchingDepartment->title_en;
                    } else {
                        $allDataRow->is_parent = "-";
                    }
                    $allDataRow->action = $html;
                }
                return response()->json(['data' => $allData, 'message' => 'The Record Has been deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Department not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
