<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use App\Models\ShiftPetrolSales;
use Illuminate\Http\Request;
use App\Models\ShiftFillingReadings;
use App\Models\PetrolType;
use App\Models\Employees;
use App\Models\User;
use DB;
use Maatwebsite\Excel\Concerns\ToArray;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportShiftFillingReadings;
use Illuminate\Support\Facades\Auth;
use DataTables;

class ShiftFillingReadingsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct(){
        $this->middleware('permission:petrol-delivery-report-list', ['only' => ['index','show']]);
    }
    public function index(Request $request)
    {
        if (auth()->user()->type == 3 || auth()->user()->type == 1) {

            $admin_id_arr = ["0"];
            if (auth()->user()->type == 3) {
                if (auth()->user()->sub_emp_id == 0) {
                    $admin_id = auth()->user()->id;
                } else {
                    $admin_id = auth()->user()->sub_emp_id;
                }
                $admin_id_arr = [$admin_id];
                $response['draw'] = $request->draw;
                $offset = $request->start;
                $length = $request->length;
                $order = $request->order;

                $condition = ShiftFillingReadings::join('shift_report', 'shift_filling_readings.shift_report_id', '=', 'shift_report.id')
                    ->join('users', 'users.id', '=', 'shift_filling_readings.user_id')
                    ->whereIn('shift_filling_readings.user_id', $admin_id_arr)
                    ->select('shift_filling_readings.*', 'shift_report.*', 'users.*');

                if (request()->ajax()) {
                    if (!empty($request->organization_name)) {
                        $condition->where('shift_filling_readings.rdc_user_id', $request->organization_name);
                    }

                    if (!empty($request->petrol_type_id)) {
                        $condition->where('shift_filling_readings.petrol_typeid', $request->petrol_type_id);
                    }
                    if ($request->petrol_station_id && $request->petrol_station_id !== '') {
                        $petrol_station_ids = $request->petrol_station_id;

                        if (is_array($petrol_station_ids)) {
                            $condition->whereIn('shift_report.user_id', $petrol_station_ids);
                        }
                    }

                    if (!empty($request->start_date_time)) {
                        $condition->whereDate('shift_filling_readings.filling_delivery_date', '>=', $request->start_date_time);
                    }

                    if (!empty($request->end_date_time)) {
                        $condition->whereDate('shift_filling_readings.filling_delivery_date', '<=', $request->end_date_time);
                    }

                    if ($request->has('search')) {
                        $search = $request['search']['value'];
                        $date_arr = explode('/', $search);
                        $formattedDate = '%';
                        if (isset($date_arr[2]) && $date_arr[2] != "") {
                            $formattedDate .= $date_arr[2] . "-";
                        }
                        if (isset($date_arr[1]) && $date_arr[1] != "") {
                            $formattedDate .= $date_arr[1] . "-";
                        }
                        if (isset($date_arr[0]) && $date_arr[0] != "") {
                            $formattedDate .= $date_arr[0];
                        }
                        $formattedDate .= '%';
                        $condition->where(function ($query) use ($search, $formattedDate) {
                            $query->orWhere('shift_report.shiftid', 'like', "%$search%")
                                ->orWhere('users.username', 'like', "%$search%")
                                ->orWhere('shift_report.shift_name_en', 'like', "%$search%")
                                ->orWhere('shift_report.shift_date', 'like', "%$formattedDate%")
                                ->orWhere('shift_filling_readings.rdc_organization_name', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.petrol_type_name', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_volumn', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_ppd_value', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_mass', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_doc_number', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_delivery_doc_date', 'like', "%$formattedDate%")
                                ->orWhere('shift_filling_readings.filling_delivery_date', 'like', "%$formattedDate%")
                                ->orWhere('shift_filling_readings.filling_vehicle_plate_number', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filled_in_reservoir_name', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.feeling_temperature', 'like', "%$search%");
                        });
                    }


                    $shiftfillingreadings = $condition->with('shiftReport')
                        ->orderBy('shift_filling_readings.id', 'DESC');


                    $count = $shiftfillingreadings->count();
                    $filteredCount = $count;

                    // Get the data for the current page
                    $data = $shiftfillingreadings->skip($offset)->take($length)->Get();

                    // Format the response in the structure expected by DataTables
                    $formattedData = [
                        'draw' => $request->draw,
                        'recordsTotal' => $count,
                        'recordsFiltered' => $filteredCount,
                        'data' => $data,
                    ];
                    return response()->json($formattedData);

                }

                $find_distribution_admin_details = Employees::join('users', 'employees.user_id', '=', 'users.id')
                    ->where('users.type', 4)
                    ->pluck('organization_name', 'user_id');

                $reservoirs = DB::table('reservoirs')
                    ->select(DB::raw('GROUP_CONCAT(DISTINCT(petrol_type_id)) as petrol_type_ids'))
                    ->whereIn('user_id', $admin_id_arr)
                    ->where('status', 1)
                    ->first();

                $petrol_type_query = DB::table('petrol_types')
                    ->where('status', 'Y');

                if ($reservoirs && $reservoirs->petrol_type_ids != "") {
                    $petrolTypeIds = explode(",", $reservoirs->petrol_type_ids);
                    $petrol_type_query->whereIn('id', $petrolTypeIds);
                } else {
                    $petrol_type_query->whereIn('id', [0]);
                }
                $default_language = get_default_language();
                $petrolTypes = $petrol_type_query->pluck('petrol_type_' . $default_language, 'id');

                return view('petrol-delivery-report.index', compact('petrolTypes', 'find_distribution_admin_details'));

            } elseif (auth()->user()->type == 1) {
                if (auth()->user()->sub_emp_id == 0) {
                    $admin_id = auth()->user()->id;
                } else {
                    $admin_id = auth()->user()->sub_emp_id;
                }

                $users = User::all();
                $Employees = Employees::all();

                $petrolPumpCon = [
                    'users.type' => 3,
                    'users.sub_emp_id' => 0,
                    'users.id_parent_organisation' => $admin_id,
                    'users.status' => 'Y',
                ];

                // Retrieve employees with related User
                $petrol_pump = Employees::whereHas('user', function ($query) use ($petrolPumpCon) {
                    foreach ($petrolPumpCon as $field => $value) {
                        if (is_array($value)) {
                            // Handle special cases where the value is an array, e.g., for 'IN' conditions
                            $query->whereIn($field, $value);
                        } else {
                            $query->where($field, $value);
                        }
                    }
                })
                    ->orderBy('organization_name', 'ASC')
                    ->pluck('organization_name', 'user_id');

                $users = User::where($petrolPumpCon)
                    ->selectRaw('GROUP_CONCAT(DISTINCT(id)) as petrol_station_ids')
                    ->first();

                if ($users->petrol_station_ids != "") {
                    $admin_id_arr = explode(",", $users->petrol_station_ids);
                }

                $response['draw'] = $request->draw;
                $offset = $request->start;
                $length = $request->length;
                $order = $request->order;

                $condition = ShiftFillingReadings::join('shift_report', 'shift_filling_readings.shift_report_id', '=', 'shift_report.id')
                    ->join('users', 'users.id', '=', 'shift_filling_readings.user_id')
                    ->whereIn('shift_filling_readings.user_id', $admin_id_arr)
                    ->select('shift_filling_readings.*', 'shift_report.*', 'users.*');


                if (request()->ajax()) {

                    if (!empty($request->organization_name)) {
                        $condition->where('shift_filling_readings.rdc_user_id', $request->organization_name);
                    }

                    if (!empty($request->petrol_type_id)) {
                        $condition->where('shift_filling_readings.petrol_typeid', $request->petrol_type_id);
                    }
                    if ($request->petrol_station_id && $request->petrol_station_id !== '') {
                        $petrol_station_ids = $request->petrol_station_id;

                        if (is_array($petrol_station_ids)) {
                            $condition->whereIn('shift_report.user_id', $petrol_station_ids);
                        }
                    }

                    if (!empty($request->start_date_time)) {
                        $condition->whereDate('shift_filling_readings.filling_delivery_date', '>=', $request->start_date_time);
                    }

                    if (!empty($request->end_date_time)) {
                        $condition->whereDate('shift_filling_readings.filling_delivery_date', '<=', $request->end_date_time);
                    }

                    if ($request->has('search')) {
                        $search = $request['search']['value'];
                        $date_arr = explode('/', $search);
                        $formattedDate = '%';
                        if (isset($date_arr[2]) && $date_arr[2] != "") {
                            $formattedDate .= $date_arr[2] . "-";
                        }
                        if (isset($date_arr[1]) && $date_arr[1] != "") {
                            $formattedDate .= $date_arr[1] . "-";
                        }
                        if (isset($date_arr[0]) && $date_arr[0] != "") {
                            $formattedDate .= $date_arr[0];
                        }
                        $formattedDate .= '%';
                        $condition->where(function ($query) use ($search, $formattedDate) {
                            $query->orWhere('shift_report.shiftid', 'like', "%$search%")
                                ->orWhere('users.username', 'like', "%$search%")
                                ->orWhere('shift_report.shift_name_en', 'like', "%$search%")
                                ->orWhere('shift_report.shift_date', 'like', "%$formattedDate%")
                                ->orWhere('shift_filling_readings.rdc_organization_name', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.petrol_type_name', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_volumn', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_ppd_value', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_mass', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_doc_number', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filling_delivery_doc_date', 'like', "%$formattedDate%")
                                ->orWhere('shift_filling_readings.filling_delivery_date', 'like', "%$formattedDate%")
                                ->orWhere('shift_filling_readings.filling_vehicle_plate_number', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.filled_in_reservoir_name', 'like', "%$search%")
                                ->orWhere('shift_filling_readings.feeling_temperature', 'like', "%$search%");
                        });
                    }


                    $shiftfillingreadings = $condition->with('shiftReport')
                        ->orderBy('shift_filling_readings.id', 'DESC');

                    if (isset($shiftfillingreadings) && $shiftfillingreadings) {
                        // dd('heh');
                        foreach ($shiftfillingreadings as $shiftfillingreadingss) {
                            dd('heh');
                            $default_language = get_default_language();
                            // dd($default_language);
                            // $shift_name_type = 'shift_name_' . $default_language;
                            if ($default_language == "ru") {
                                $cur_key = 1;
                            } elseif ($default_language == "tu") {
                                $cur_key = 2;
                            } else {
                                $cur_key = 0;
                            }
                            dd($shiftfillingreadingss);
                            $find_reservoir_list = json_decode($shiftfillingreadings->filled_in_reservoir_name, true);

                            foreach ($find_reservoir_list as $f_key => $f_val) {
                                $reservoir_arr = explode("#@@#", $f_val);
                                dd($reservoir_arr);
                                echo $reservoir_arr[$cur_key] . "<br/>";
                            }

                            if (count($find_reservoir_list) == 1) {
                                $filled_in_reservoir_name[trim($shiftfillingreadings->filled_in_reservoir, ",")][] = $shiftfillingreadings->filling_volume;
                            }
                        }
                    }

                    $count = $shiftfillingreadings->count();
                    $filteredCount = $count;

                    // Get the data for the current page
                    $data = $shiftfillingreadings->skip($offset)->take($length)->Get();

                    // Format the response in the structure expected by DataTables
                    $formattedData = [
                        'draw' => $request->draw,
                        'recordsTotal' => $count,
                        'recordsFiltered' => $filteredCount,
                        'data' => $data,
                    ];
                    return response()->json($formattedData);

                }


                $find_distribution_admin_details = Employees::join('users', 'employees.user_id', '=', 'users.id')
                    ->where('users.type', 4)
                    ->pluck('organization_name', 'user_id');

                $reservoirs = DB::table('reservoirs')
                    ->select(DB::raw('GROUP_CONCAT(DISTINCT(petrol_type_id)) as petrol_type_ids'))
                    ->whereIn('user_id', $admin_id_arr)
                    ->where('status', 1)
                    ->first();

                $petrol_type_query = DB::table('petrol_types')
                    ->where('status', 'Y');

                if ($reservoirs && $reservoirs->petrol_type_ids != "") {
                    $petrolTypeIds = explode(",", $reservoirs->petrol_type_ids);
                    $petrol_type_query->whereIn('id', $petrolTypeIds);
                } else {
                    $petrol_type_query->whereIn('id', [0]);
                }
                $default_language = get_default_language();
                $petrolTypes = $petrol_type_query->pluck('petrol_type_' . $default_language, 'id');

                return view('petrol-delivery-report.index', compact('petrolTypes', 'find_distribution_admin_details', 'petrol_pump'));

            }

        } else {
            return redirect()->route('dashboard')
                ->with('error', 'You are not authorized to view this record.');
        }


    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}