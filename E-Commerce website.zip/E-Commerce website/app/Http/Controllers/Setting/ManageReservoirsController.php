<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use App\Models\Employees;
use App\Models\MatrixTemplates;
use App\Models\PetrolPumps;
use App\Models\PetrolType;
use App\Models\Reservoirs;
use App\Models\ShiftTankReadings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class ManageReservoirsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {

         $this->middleware('permission:reservoir-list|reservoir-create|reservoir-edit|reservoir-delete', ['only' => ['index','show']]);
         $this->middleware('permission:reservoir-create', ['only' => ['create','store']]);
         $this->middleware('permission:reservoir-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:reservoir-delete', ['only' => ['destroy']]);

    }
    public function index(Request $request)
    {
        $page_title = 'List Of Reservoirs';
        $userId = Auth::user()->id;
        $default_language = get_default_language();
        $reservoirs = DB::table('reservoirs')
            ->select('reservoirs.*', 'matrix_templates.template_name_' . $default_language . ' as template_name', 'petrol_types.petrol_type_' . $default_language . ' as petrol_type_title')
            ->join('matrix_templates', 'reservoirs.matrix_template_id', '=', 'matrix_templates.id')
            ->join('petrol_types', 'reservoirs.petrol_type_id', '=', 'petrol_types.id')
            ->where('matrix_templates.user_id', $userId)
            ->whereNull('reservoirs.deleted_at')
            ->get();
        return view('manage-reservoirs.index', compact('reservoirs', 'page_title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $default_language = get_default_language();
        $petrolTypes = PetrolType::where('status', 'Y')->pluck('petrol_type_'.$default_language, 'id');
        $userId = auth()->user()->id;

        $matrixTemplate = MatrixTemplates::select('id', 'template_name_'.$default_language)
        ->where('user_id',$userId)
        ->get()->toArray();

        return view('manage-reservoirs.create', compact('petrolTypes','matrixTemplate'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'reservoir_type_en' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Reservoirs::where('reservoir_type_en', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for english already exists');
                    }
                },
            ],
            'reservoir_type_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Reservoirs::where('reservoir_type_ru', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for russian already exists');
                    }
                },
            ],
            'reservoir_type_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = Reservoirs::where('reservoir_type_tu', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for turkmenistan already exists');
                    }
                },
            ],
            'capacity_kg' => 'required|regex:/^\d*(\.\d{1,2})?$/',
            'capacity_liter' => 'required|regex:/^\d*(\.\d{1,2})?$/',
            'matrix_template_id' => 'required',

        ], [
            'reservoir_type_en.required' =>  $errormsg,
            'reservoir_type_ru.required' =>  $errormsg,
            'reservoir_type_tu.required' =>  $errormsg,
            'capacity_kg.required' =>  $errormsg,
            'capacity_kg.regex' => 'Please Enter Digits in proper Format',
            'capacity_liter.required' =>  $errormsg,
            'capacity_liter.regex' => 'Please Enter Digits in proper Format',
            'matrix_template_id' => $errormsg,

        ]);

        $userId = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();

        $reservoirs = new Reservoirs();
        $reservoirs->user_id  = $userId;
        $reservoirs->employee_id  = $employee->id;
        $reservoirs->reservoir_type_en  = $request->reservoir_type_en;
        $reservoirs->reservoir_type_ru  = $request->reservoir_type_ru;
        $reservoirs->reservoir_type_tu  = $request->reservoir_type_tu;
        $reservoirs->petrol_type_id = $request->input('petrol_type_id');
        $reservoirs->capacity_kg  = $request->input('capacity_kg');
        $reservoirs->capacity_liter  = $request->input('capacity_liter');
        $reservoirs->matrix_template_id  = $request->input('matrix_template_id') ?? 0; //if the value is null and then assigning 0

        if ($reservoirs->save()) {
            return redirect()->route('manage-reservoirs.index')->with('message', __('Reservoir has been added successfully'));
        } else {
            return redirect()->back()->with('error', __('Failed to add Reservoir. Please try again.'));
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $default_language = get_default_language();
        $petrolTypes = PetrolType::where('status', 'Y')->pluck('petrol_type_'.$default_language, 'id');
        $userId = auth()->user()->id;
        $matrixTemplate = MatrixTemplates::select('id', 'template_name_en')
        ->where('user_id',$userId)
        ->limit(200)
        ->get()
        ->pluck('template_name_en', 'id');

        if(isset($id)){
            $record = Reservoirs::findOrFail($id);
            $data = $record->toArray();
            return view('manage-reservoirs.edit',compact('record','default_language','petrolTypes','matrixTemplate') );
        }else{
            return redirect()->back()->with('error', __('Failed to edit Reservoir. Please try again.'));
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'reservoir_type_en' => [
                'required',
                function ($attribute, $value, $fail) use ($id) {
                    $existingDesignation = Reservoirs::where('reservoir_type_en', $value)
                        ->where('id', '!=', $id) // Exclude the current record being edited
                        ->first();
                    if ($existingDesignation) {
                        $fail('Title for english already exists');
                    }
                },
            ],
            'reservoir_type_ru' => [
                'required',
                function ($attribute, $value, $fail) use ($id){
                    $existingDesignation = Reservoirs::where('reservoir_type_ru', $value)
                    ->where('id', '!=', $id) // Exclude the current record being edited
                    ->first();
                    if ($existingDesignation) {
                        $fail('Title for russian already exists');
                    }
                },
            ],
            'reservoir_type_tu' => [
                'required',
                function ($attribute, $value, $fail) use ($id){
                    $existingDesignation = Reservoirs::where('reservoir_type_tu', $value)
                    ->where('id', '!=', $id) // Exclude the current record being edited
                    ->first();
                    if ($existingDesignation) {
                        $fail('Title for turkmenistan already exists');
                    }
                },
            ],
            'capacity_kg' => 'required|regex:/^\d*(\.\d{1,2})?$/',
            'capacity_liter' => 'required|regex:/^\d*(\.\d{1,2})?$/',
            // 'matrix_template_id' => 'required',

        ], [
            'reservoir_type_en.required' =>  $errormsg,
            'reservoir_type_ru.required' =>  $errormsg,
            'reservoir_type_tu.required' =>  $errormsg,
            'capacity_kg.required' =>  $errormsg,
            'capacity_kg.regex' => 'Please Enter Digits in proper Format',
            'capacity_liter.required' =>  $errormsg,
            'capacity_liter.regex' => 'Please Enter Digits in proper Format',
            'matrix_template_id' => $errormsg,

        ]);

        $adminId = auth()->user()->id;
        $employee = Employees::where('user_id', $adminId)->first();

        $reservoirs = Reservoirs::findOrFail($id);
        $reservoirs->user_id  = $adminId;
        $reservoirs->employee_id  = $employee->id;
        $reservoirs->reservoir_type_en  = $request->reservoir_type_en;
        $reservoirs->reservoir_type_ru  = $request->reservoir_type_ru;
        $reservoirs->reservoir_type_tu  = $request->reservoir_type_tu;
        $reservoirs->petrol_type_id = $request->input('petrol_type_id');
        $reservoirs->capacity_kg  = $request->input('capacity_kg');
        $reservoirs->capacity_liter  = $request->input('capacity_liter');
        $reservoirs->matrix_template_id  = $request->input('matrix_template_id') ?? 0; //if the value is null and then assigning 0

        if ($reservoirs->save()) {
            return redirect()->route('manage-reservoirs.index')->with('message', __('Reservoir has been updated successfully'));
        } else {
            return redirect()->back()->with('error', __('Failed to update Reservoir. Please try again.'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function destroy(Request $request)
    {
        if (empty($request->status)) {
            return response()->json(['error' => 'Invalid ID'], 422);
        }

        $userType = auth()->user()->type;
        $adminId = auth()->user()->id;
        $subEmpId = auth()->user()->sub_emp_id;

        if ($userType == 3) {
            $adminIdToCheck = $subEmpId == 0 ? $adminId : $subEmpId;
        } else {
            $adminIdToCheck = $request->status;
        }

        $reservoir = Reservoirs::where('user_id', $adminIdToCheck)->where('id', $request->status)->first();

        if ($reservoir) {
            $shiftTankReadings = ShiftTankReadings::where('reservoir_id', $request->status)->first();

            if (!empty($shiftTankReadings)) {
                return response()->json(['error' => 'At first delete all related shift reports then try again.']);
            }

            $petrolPumps = PetrolPumps::where('reservoir_id', $request->status)->first();

            if (!empty($petrolPumps)) {
                return response()->json(['error' => 'At first delete all related petrol pumps then try again.']);
            }

            $reservoirId = $reservoir->id; // Get the ID before deleting

            if ($reservoir->delete()) {
                // Retrieve the updated list of reservoirs without the deleted one
                $userId = auth()->user()->sub_emp_id == 0 ? auth()->user()->id : auth()->user()->sub_emp_id;
                $allData = DB::table('reservoirs')
                    ->join('matrix_templates', 'reservoirs.matrix_template_id', '=', 'matrix_templates.id')
                    ->join('petrol_types', 'reservoirs.petrol_type_id', '=', 'petrol_types.id')
                    ->select(
                        'reservoirs.id',
                        'reservoirs.reservoir_type_' . get_default_language(),
                        'matrix_templates.template_name_' . get_default_language(),
                        'petrol_types.petrol_type_' . get_default_language(),
                        'reservoirs.capacity_kg',
                        'reservoirs.capacity_liter',
                        'reservoirs.status'
                    )
                    ->where('matrix_templates.user_id', $userId)
                    ->whereNull('reservoirs.deleted_at')
                    ->get();

                $allData->transform(function ($allDataRow) {
                    $html = '<a href="' . route('manage-reservoirs.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="manage-reservoirs" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                    $status = '<button class="btn btn-' . ($allDataRow->status == 1 ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="manage-reservoirs" data-id="' . $allDataRow->id . '">'
                        . ($allDataRow->status == 1 ? 'Activate' : 'Deactivate') . ''
                        . '</button>';
                    $allDataRow->status = $status;
                    $allDataRow->action = $html;
                    unset($allDataRow->id);
                    return $allDataRow;
                });

                return response()->json(['data' => $allData, 'message' => 'Reservoir deleted successfully.']);
            } else {
                return response()->json(['error' => 'The record could not be deleted. Please, try again.']);
            }
        } else {
            return response()->json(['error' => 'The record could not be deleted. Please, try again.']);
        }
    }
    public function changereservoirsStatus(Request $request)
    {
        $data = $request->all();
        $reservoirs = Reservoirs::find($data['id']);
        // dd($reservoirs);

        if (!$reservoirs) {
            return response()->json(['message' => 'Reservoirs not found'], 404);
        }

        $reservoirs->status = ($reservoirs->status === 1) ? 0 : 1;
        $newStatus = $reservoirs->status === 1 ? 'Active' : 'Deactivate';
        if ($reservoirs->save()) {
            return response()->json(['success' => true, 'newStatus' => $newStatus, 'message' => 'Reservoir status updated successfully']);
        } else {
            return response()->json(['success' => false, 'newStatus' => $newStatus, 'message' => 'Something Went wrong']);
        }
    }
}
