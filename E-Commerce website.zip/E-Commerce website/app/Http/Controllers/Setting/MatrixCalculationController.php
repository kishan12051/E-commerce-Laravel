<?php

namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Controller;
use App\Models\DefaultMatrixRecords;
use App\Models\Employees;
use App\Models\MainMatrixCalculations;
use App\Models\PetrolType;
use App\Models\Reservoirs;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;

class MatrixCalculationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct(){
        $this->middleware('permission:matrix-calculation-list', ['only' => ['index','show']]);
        $this->middleware('permission:matrix-calculation-create', ['only' => ['create','store']]);
        $this->middleware('permission:matrix-calculation-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:matrix-calculation-delete', ['only' => ['destroy']]);
    }
     public function index()
     {
         $page_title = "List(s) Of Matrix Calculation";
         $default_language = get_default_language();
         $matrixCalculations = MainMatrixCalculations::with(['reservoir', 'petrolType']) // Eager loading relationships
         ->join('petrol_types', 'main_matrix_calculations.petrol_type_id', '=', 'petrol_types.id')
         ->select('main_matrix_calculations.*', 'petrol_types.petrol_type_' . $default_language . ' as petrol_type_name', 'petrol_types.type_code as petrol_type_code')->orderBy('main_matrix_calculations.id','DESC')
         ->get();
         return view('matrix-calculation.index', compact('matrixCalculations', 'page_title'));
     }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $adminId = auth()->user()->id;
        $user = User::select('username')->where('id', $adminId)->get()->toArray();
        $default_language = get_default_language();
        $petrolTypes = PetrolType::where('status', 'Y')->pluck('petrol_type_'.$default_language, 'id');
        $reservoir = Reservoirs::pluck('reservoir_type_'.$default_language, 'id');
        return view('matrix-calculation.create',compact('petrolTypes','user','reservoir'));
    }

    public function changereservoir(Request $request){

        $data = [];


        $selectedReservoirId = $request->input('contryid');

        $reservoirs = Reservoirs::find($selectedReservoirId);

        if ($reservoirs) {
            $petroltype_id = $reservoirs->petrol_type_id;
            $default_language = get_default_language();
            $petroltype_name = 'petrol_type_' . $default_language;

            $petrolType = PetrolType::find($petroltype_id);

            if ($petrolType) {
                $data = [
                    'name' => $petrolType->$petroltype_name,
                ];
            }
        }
        return Response::json([$data]);
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $errormsg = 'This field is required';
         $request->validate([
             'reservoir_id' => 'required',
             'petrol_type_id' => 'required',
             'document_details_en' => 'required',
             'document_details_ru' => 'required',
             'document_details_tu' => 'required',
             'error_rate' => [
                'required',
                'numeric',
            ],
             'issued_date' => 'required|date_format:Y/m/d',
             'valid_through' => 'required|date_format:Y/m/d|after:issued_date',

         ], [
             'reservoir_id.required' => $errormsg,
             'petrol_type_id.required' => $errormsg,
             'document_details_en.required' => $errormsg,
             'document_details_ru.required' => $errormsg,
             'document_details_tu.required' => $errormsg,
             'error_rate.required' => $errormsg,
             'error_rate.numeric' => 'Invalid floating decimal number',
             'issued_date.required' => $errormsg,
             'issued_date.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD',
             'valid_through.required' => $errormsg,
             'valid_through.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD',
             'valid_through.after' => 'End date must be after the start date',

         ]);

         $adminId = auth()->user()->id;
         $employee = Employees::where('user_id', $adminId)->first();
         $petroltype_id = $request->input('reservoir_id');
         $petrolType = Reservoirs::where('id', $petroltype_id)->value('petrol_type_id');

         $matrixCalculations = new MainMatrixCalculations();
         $matrixCalculations->user_id = $adminId;
         $matrixCalculations->employee_id = $employee->id;
         $matrixCalculations->reservoir_id = $request->input('reservoir_id');
         $matrixCalculations->petrol_type_id = $petrolType;
         $matrixCalculations->document_details_en = $request->input('document_details_en');
         $matrixCalculations->document_details_ru = $request->input('document_details_ru');
         $matrixCalculations->document_details_tu = $request->input('document_details_tu');
         $matrixCalculations->error_rate = $request->input('error_rate');
         $matrixCalculations->issued_date = Carbon::createFromFormat('Y/m/d', $request->input('issued_date'));
         $matrixCalculations->valid_through = Carbon::createFromFormat('Y/m/d', $request->input('valid_through'));
         $matrixCalculations->created_at = now();
        //  dd($matrixCalculations);


         if ($matrixCalculations->save()) {
             return redirect()->route('matrix-calculation.index')->with('message', __('Matrix Calculation has been added successfully'));
         } else {
             return redirect()->back()->with('error', __('Failed to add Matrix Calculation. Please try again.'));
         }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $matrixCalculations = MainMatrixCalculations::findOrFail($id);
        $matrixCalculations->issued_date = Carbon::createFromFormat('Y-m-d', $matrixCalculations->issued_date)->format('Y/m/d');
        $matrixCalculations->valid_through = Carbon::createFromFormat('Y-m-d', $matrixCalculations->valid_through)->format('Y/m/d');
        $adminId = auth()->user()->id;
        $user = User::select('username')->where('id', $adminId)->get()->toArray();
        $default_language = get_default_language();
        $petrolTypes = PetrolType::where('status', 'Y')->pluck('petrol_type_'.$default_language, 'id');
        $reservoir = Reservoirs::pluck('reservoir_type_'.$default_language, 'id');
        // dd($reservoir);

        $defaultMatrixRecords = DefaultMatrixRecords::all();
        return view('matrix-calculation.edit', compact('matrixCalculations','user','petrolTypes','reservoir','defaultMatrixRecords'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $matrixCalculations = MainMatrixCalculations::findOrFail($id);

        $errormsg = 'This field is required';
         $request->validate([
             'reservoir_id' => 'required',
             'petrol_type_id' => 'required',
             'document_details_en' => 'required',
             'document_details_ru' => 'required',
             'document_details_tu' => 'required',
             'error_rate' => 'required|numeric|',
             'issued_date' => 'required|date_format:Y/m/d',
             'valid_through' => 'required|date_format:Y/m/d|after:issued_date',

         ], [
             'reservoir_id.required' => $errormsg,
             'petrol_type_id.required' => $errormsg,
             'document_details_en.required' => $errormsg,
             'document_details_ru.required' => $errormsg,
             'document_details_tu.required' => $errormsg,
             'error_rate.required' => $errormsg,
             'error_rate.numeric' => 'Invalid floating decimal number',
             'issued_date.required' => $errormsg,
             'issued_date.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD',
             'valid_through.required' => $errormsg,
             'valid_through.date_format' => 'Invalid date format. Please use the format YYYY/MM/DD',
             'valid_through.after' => 'End date must be after the start date',

         ]);


        // dd($matrixCalculations);

        if ($matrixCalculations) {
            $adminId = auth()->user()->id;
            $employee = Employees::where('user_id', $adminId)->first();
            $petroltype_id = $request->input('reservoir_id');
            $petrolType = Reservoirs::where('id', $petroltype_id)->value('petrol_type_id');

            // $matrixCalculations = new MainMatrixCalculations();
            $matrixCalculations->user_id = $adminId;
            $matrixCalculations->employee_id = $employee->id;
            $matrixCalculations->reservoir_id = $request->reservoir_id;
            $matrixCalculations->petrol_type_id = $petrolType;
            $matrixCalculations->document_details_en = $request->document_details_en;
            $matrixCalculations->document_details_ru = $request->document_details_ru;
            $matrixCalculations->document_details_tu = $request->document_details_tu;
            $matrixCalculations->error_rate = $request->error_rate;
            $matrixCalculations->issued_date = Carbon::createFromFormat('Y/m/d', $request->input('issued_date'));
            $matrixCalculations->valid_through = Carbon::createFromFormat('Y/m/d', $request->input('valid_through'));
            $matrixCalculations->updated_at = now();
            $matrixCalculations->save();
            // dd($matrixCalculations);
            return redirect()->route('matrix-calculation.index')->with('message', 'Matrix Calculation updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = MainMatrixCalculations::find($request->status);
            if ($record) {
                $record->delete();
                $default_language = get_default_language();
                $allData = DB::table('main_matrix_calculations')
                    ->select(
                        'main_matrix_calculations.id',
                        'reservoirs.reservoir_type_'.$default_language,
                        'petrol_types.petrol_type_'.$default_language,
                        'main_matrix_calculations.document_details_'.$default_language,
                        'petrol_types.type_code',
                        'main_matrix_calculations.error_rate',
                        'main_matrix_calculations.issued_date',
                        'main_matrix_calculations.valid_through'
                    )
                    ->join('reservoirs', 'main_matrix_calculations.reservoir_id', '=', 'reservoirs.id')
                    ->join('petrol_types', 'main_matrix_calculations.petrol_type_id', '=', 'petrol_types.id')
                    ->whereNull('main_matrix_calculations.deleted_at')
                    ->orderBy('main_matrix_calculations.id','DESC')
                    ->get();

                foreach ($allData as $allDataRow) {
                    $html = '<a class="btn btn-warning btn-circle btn-sm" title="Edit" href=""><i class="fas fa-edit"></i></a>
                             <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="matrix-calculation" data-id="' . $allDataRow->id . '" 
                                    data-url=""><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                    unset($allDataRow->id);
                }
                return response()->json(['data' => $allData,'message'=>'Matrix Template deleted successfully.'], 200);
            } else {
                return Response::json(['message' => 'Matrix Calculation not found.'], 404);
            }
        } else {
            return Response::json(['message' => 'Invalid request.'], 400);
        }
    }

    public function storeMatrixRecord(Request $request)
    {
        $errormsg = 'This field is required';
        $errordupmsg = 'You can not enter duplicate value';
        $request->validate([
            'height' => 'required|unique:default_matrix_records,height',
            'volumn_liter' => 'required|unique:default_matrix_records,volumn_liter',
            'volumn_ml' => 'required|unique:default_matrix_records,volumn_ml',


        ], [
            'height.required' => $errormsg,
            'height.unique' => $errordupmsg,
            'volumn_liter.required' => $errormsg,
            'volumn_liter.unique' => $errordupmsg,
            'volumn_ml.required' => $errormsg,
            'volumn_ml.unique' => $errordupmsg,
        ]);

        $adminId = auth()->user()->id;
        $employee = Employees::where('user_id', $adminId)->first();

        $defaultMatrixRecords = new DefaultMatrixRecords();
        $defaultMatrixRecords->user_id = $adminId;
        $defaultMatrixRecords->employee_id = $employee->id;
        $defaultMatrixRecords->height = $request->input('height');
        $defaultMatrixRecords->volumn_liter = $request->input('volumn_liter');
        $defaultMatrixRecords->volumn_ml = $request->input('volumn_ml');
        $defaultMatrixRecords->created_at = now();

        if ($defaultMatrixRecords->save()) {
            return Response::json(['message' => 'Matrix Data added successfully.']);
        } else {
            return Response::json(['message' => 'Failed to add Matrix Data. Please try again.']);
        }
    }

    public function editMatrixRecord($id)
    {
        $defaultMatrixRecord = DefaultMatrixRecords::findOrFail($id);
        return response()->json($defaultMatrixRecord);
    }



    public function updateMatrixRecord(Request $request, $id)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'height' => 'required',
            'volumn_liter' => 'required',
            'volumn_ml' => 'required',
        ], [
            'height.required' => $errormsg,
            'volumn_liter.required' => $errormsg,
            'volumn_ml.required' => $errormsg,
        ]);

        $defaultMatrixRecords = DefaultMatrixRecords::findOrFail($id);

        if ($defaultMatrixRecords) {
            $adminId = auth()->user()->id;
            $employee = Employees::where('user_id', $adminId)->first();

            $defaultMatrixRecords->user_id = $adminId;
            $defaultMatrixRecords->employee_id = $employee->id;
            $defaultMatrixRecords->height = $request->height;
            $defaultMatrixRecords->volumn_liter = $request->volumn_liter;
            $defaultMatrixRecords->volumn_ml = $request->volumn_ml;
            $defaultMatrixRecords->updated_at = now();
            $defaultMatrixRecords->save();

            return Response::json(['message' => 'Matrix Data updated successfully.']);
        }
    }



    public function destroyMatrixRecord(Request $request,$id)
    {
       if (isset($request->status))
        {
            $record = DefaultMatrixRecords::find($request->status);
            if ($record)
            {
                $record->delete();
                return Response::json(['message' => 'Matrix Data deleted successfully.']);
            }
            else
            {
                return Response::json(['message' => 'Matrix Data not found.'], 404);
            }
        } else {
        return Response::json(['message' => 'Invalid request.'], 400);
        }

    }
}
