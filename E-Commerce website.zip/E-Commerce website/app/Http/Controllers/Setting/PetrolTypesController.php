<?php

namespace App\Http\Controllers\setting;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PetrolTypes;
use Illuminate\Support\Facades\Response;

class PetrolTypesController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:petrol-types-list', ['only' => ['index','show']]);
        $this->middleware('permission:petrol-types-create', ['only' => ['create','store']]);
        $this->middleware('permission:petrol-types-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:petrol-types-delete', ['only' => ['destroy']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $page_title = "Lists Of Petrol Types";
        $PetrolTypes = PetrolTypes::orderBy('id', 'DESC')->get();
         return view('petroltypes.index',compact('PetrolTypes','page_title'))->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('petroltypes.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $errormsg = 'This field is required';
        $request->validate([
            'title_en' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = PetrolTypes::where('petrol_type_en', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for english already exists');
                    }
                },
            ],
            'title_ru' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = PetrolTypes::where('petrol_type_ru', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for russian already exists');
                    }
                },
            ],
            'title_tu' => [
                'required',
                function ($attribute, $value, $fail) {
                    $existingDesignation = PetrolTypes::where('petrol_type_tu', $value)->first();
                    if ($existingDesignation) {
                        $fail('Title for Türkmen already exists');
                    }
                },
            ],
        ], [
            'title_en.required' =>  $errormsg,
            'title_ru.required' =>  $errormsg,
            'title_tu.required' =>  $errormsg,

        ]);
        $PetrolTypes = new PetrolTypes();
            $PetrolTypes->type_code       = "PET-".rand("999999", '111111');
            $PetrolTypes->petrol_type_en  = $request->title_en;
            $PetrolTypes->petrol_type_ru  = $request->title_ru;
            $PetrolTypes->petrol_type_tu  = $request->title_tu;
            $PetrolTypes->created_at      = now();
            $PetrolTypes->save();
            return redirect()->route('petroltypes.index')
        ->with('message', 'The record has been saved successfully.');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if(isset($id)){
            $record = PetrolTypes::findOrFail($id);
            $data = $record->toArray(); // Or use $user->attributesToArray()
            return view('petroltypes.edit',compact('record') );
        }else{
            $data = "No data Found";
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $errormsg = 'This field is required';
        $request->validate([
            'title_en' => 'required|unique:petrol_types,petrol_type_en,'.$id,
            'title_ru' => 'required|unique:petrol_types,petrol_type_ru,'.$id,
            'title_tu' => 'required|unique:petrol_types,petrol_type_tu,'.$id,
        ], [
            'title_en.required' => $errormsg,
            'title_ru.required' => $errormsg,
            'title_tu.required' => $errormsg,
            'title_en.unique' => 'Title for English already exists.',
            'title_ru.unique' => 'Title for Russian already exists.',
            'title_tu.unique' => 'Title for Türkmen already exists.',
        ]);

        $petrolType = PetrolTypes::find($id);

        if ($petrolType) {
            $petrolType->petrol_type_en = $request->title_en;
            $petrolType->petrol_type_ru = $request->title_ru;
            $petrolType->petrol_type_tu = $request->title_tu;
            $petrolType->updated_at = now();
            $petrolType->save();
            return redirect()->route('petroltypes.index')
            ->with('message', 'The record has been updated successfully.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

     public function destroy(Request $request)
     {
         if (isset($request->status)) {
             $record = PetrolTypes::find($request->status);
             if ($record) {
                 $record->delete();
                 $default_language = get_default_language();
                 $allData = PetrolTypes::select('id', 'type_code','petrol_type_'.$default_language)->orderBy('id', 'DESC')->get();
                 foreach ($allData as $key => $allDataRow) {
                     $html = '<a href="' . route('petroltypes.edit', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                             <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="petroltypes" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                     $allDataRow->action = $html;
                 }
                 return response()->json(['data' => $allData, 'message' => 'The record has been deleted successfully.'], 200);
             } else {
                 return response()->json(['error' => 'Petrol Type not found'], 404);
             }
         } else {
             return response()->json(['error' => 'Invalid request'], 400);
         }
     }
}
