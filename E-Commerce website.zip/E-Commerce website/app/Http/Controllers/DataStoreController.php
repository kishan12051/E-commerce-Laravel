<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Hash;
use DB;

class DataStoreController extends Controller
{

    public function dataStore()
    {

        $query = DB::table('admins')->get();

        foreach ($query as $key => $value) {
            
            if ($value->type == 0) {
                $type = 2;
            } elseif ($value->type == 1) {
                $type = 4;
            } elseif ($value->type == 2) {
                $type = 1;
            } elseif ($value->type == 3) {
                $type = 3;
            }

            $user = User::create([
                'type' => $type,
                'sub_emp_id' => $value->sub_emp_id,
                'id_parent_organisation' => $value->id_parent_organisation,
                'username' => $value->username,
                'email' => $value->email,
                'password' =>  Hash::make(12345678),
                'default_language' => $value->default_language,
                'status' => $value->status,
                'created_at' => $value->created,
                'updated_at' => $value->modified,
            ]);

            $user->assignRole($type);
            echo "data store";
        }
    }
}
