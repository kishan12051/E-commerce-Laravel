<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Departments;
use App\Models\Designations;
use App\Models\Employees;
use App\Models\User;
use App\Models\WorkingRegion;
use File;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Hash;
use Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Response;

class EmployeesController extends Controller
{
    /**
     * Set permission for module.
     *
     * @return \Illuminate\Http\Response
    */
    function __construct(){
        $this->middleware('permission:employees-list', ['only' => ['index','show']]);
        $this->middleware('permission:employees-create', ['only' => ['create','store']]);
        $this->middleware('permission:employees-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:employees-delete', ['only' => ['destroy']]);
        $this->middleware('permission:employees-show', ['only' => ['show']]);

        /* Petrol Station Permission */
        $this->middleware('permission:rhq-ps-list', ['only' => ['indexPs','show']]);
        $this->middleware('permission:rhq-ps-create', ['only' => ['addPs','storePs','fetchAuditCenter']]);
        $this->middleware('permission:rhq-ps-edit', ['only' => ['editPs','updatePs']]);
        $this->middleware('permission:rhq-ps-delete', ['only' => ['destroyPS']]);

        /* RAC Permission */
        $this->middleware('permission:rhq-rac-list', ['only' => ['indexRac','show']]);
        $this->middleware('permission:rhq-rac-create', ['only' => ['addRac','storeRac']]);
        $this->middleware('permission:rhq-rac-edit', ['only' => ['editRac','updateRac']]);
        $this->middleware('permission:rhq-rac-delete', ['only' => ['destroyRac']]);

        /* RDC Permission */
        $this->middleware('permission:rhq-rdc-list', ['only' => ['listOfRDC','show']]);
        $this->middleware('permission:rhq-rdc-create', ['only' => ['addRDC','storeRDC']]);
        $this->middleware('permission:rhq-rdc-edit', ['only' => ['editRDC','updateRDC']]);
        $this->middleware('permission:rhq-rdc-delete', ['only' => ['deleteRDC']]);
    }

    public function edit()
    {
        $userId = Auth::user()->id;
        $user = User::find($userId);
        $employees = Employees::where('user_id', $userId)->first();
        $page_title       = "UPDATE PROFILE DETAILS";
        return view('userprofile.edit', compact('employees','user','page_title'));
    }

    public function update(Request $request)
    {
        $messages = [
            'user_avtar' => 'The User avtar has invalid image dimensions use 120 X 120',
            'profile_picture'  => 'The Organization Logo has invalid image dimensions use 120 X 120',
            'password.same' => 'The password and confirm password must be same.',

        ];
        $this->validate($request, [
            'user_avtar' => 'dimensions:height=120',
            'profile_picture' => 'dimensions:height=120',
            'password' => 'same:password_confirmation',

        ], $messages);
        if($request->id == '' || empty($request->id)){
            return redirect('edit')->with('message', 'User not found');
        }
        if($request->isMethod('post')) {
            $usersaveFlag = false;
            $employeesaveFlag = false;
            $user = User::find($request->id);
            $employee = Employees::where('user_id', $request->id)->first();
            $oldAvatar = $user->user_avtar;
            $oldProfilePicture = $employee->profile_picture;

            if ($request->filled('password')) {
                $user->password = bcrypt($request->password);
            }
            /*profile picture upload logic start*/
            if ($request->hasFile('profile_picture') && $request->file('profile_picture')->isValid()) {
                $extension = $request->file('profile_picture')->getClientOriginalExtension();
                $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
                $profile_picture = 'profile_picture_' . time() . "." . $extension;
                if (in_array($extension, $file_extension)) {
                    $profile_picture_flag = true;
                    $employee->profile_picture = $profile_picture;
                    $directoryPath = storage_path('app/public/') . config('app.upload_folder') . '/' . config('app.organization_logo_folder');
                    if (!Storage::exists($directoryPath)) {
                        Storage::makeDirectory($directoryPath, 0777, true);
                    }
                } else {
                    $profile_picture_flag = false;
                }
            }
            if ($employee->save()) {
                $employeesaveFlag = true;
                if ($request->hasFile('profile_picture') && $profile_picture_flag == true) {
                    $request->file('profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                    if (!empty($oldAvatar)) {
                        $oldProfilePicturePath = public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder') . DIRECTORY_SEPARATOR . $oldProfilePicture);
                        if (file_exists($oldProfilePicturePath)) {
                            unlink($oldProfilePicturePath);
                        }
                    }
                }
            }
            /*profile picture upload logic end*/

            /*user avtart upload logic start*/
            if ($request->hasFile('user_avtar') && $request->file('user_avtar')->isValid()) {
                $extension = $request->file('user_avtar')->getClientOriginalExtension();
                $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
                $user_avtar = 'user_avtar_' . time() . "." . $extension;
                if (in_array($extension, $file_extension)) {
                    $user_avtarflag = true;
                    $user->user_avtar = $user_avtar;
                    $directoryPath = storage_path('app/public/') . config('app.upload_folder') . '/' . config('app.user_avtar_folder');
                    if (!Storage::exists($directoryPath)) {
                        Storage::makeDirectory($directoryPath, 0777, true);
                    }
                } else {
                    $user_avtarflag = false;
                }
            }
            if ($user->save()) {
                $usersaveFlag = true;
                if ($request->hasFile('user_avtar') && $user_avtarflag == true) {
                    $request->file('user_avtar')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.user_avtar_folder')), $user_avtar);

                    if (!empty($oldAvatar)) {
                        $oldAvatarPath = public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.user_avtar_folder') . DIRECTORY_SEPARATOR . $oldAvatar);
                        if (file_exists($oldAvatarPath)) {
                            unlink($oldAvatarPath);
                        }
                    }
                }
            }
            /*user avtar upload logic end*/

            if($employeesaveFlag == true && $usersaveFlag == true){
                return redirect('edit')->with('message', 'Data updated successfully');
            }else{
                return redirect('edit')->with('message', 'Something wents wrong');
            }
        }else{
            return redirect('edit')->with('message', 'Error occurs on update profile');
        }

    }

    //========================Start Employee===========================//
    public function index()
    {
        $emp_con = [];
        $emp_con = ['users.type' => auth()->user()->type];
        $emp_con['users.sub_emp_id'] = auth()->user()->id;
        if (auth()->user()->type == 1) {
            if (auth()->user()->sub_emp_id > 0) {
                $emp_con['users.sub_emp_id'] = auth()->user()->sub_emp_id;
            }
        }
        $employees = Employees::with(['department', 'designation', 'user'])
            ->whereHas('user', function ($query) use ($emp_con) {
                $query->where($emp_con);
            })
            ->get();

        return view('employees.index', compact('employees'))->with('i');
    }

    public function changeEmployeeStatus(Request $request)
    {
        $userId = $request->id;
        $user = User::find($userId);
        if (!$user) {
            return response()->json(['message' => 'Employee not found'], 404);
        }
        /* Toggle the employee's status */
        $user->status = ($user->status === 'Y') ? 'N' : 'Y';
        if($user->save()){

            $newStatus = $user->status === 'Y' ? 'Active' : 'Deactivate';
            // return redirect()->route('employees.index') ->with('message','Status has been updated successfully');
            return response()->json(['success' => true ,'newStatus' => $newStatus ,'message' => 'Employee status updated successfully.']);
        }else{
            return response()->json(['success' => false ,'newStatus' => $newStatus, 'message' => 'Something Wents wrong']);
        }
    }

    public function create()
    {
        $default_language = get_default_language();
        $userId = auth()->user()->id;
        $employee = Employees::where('user_id', $userId)->first();
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->pluck('title_' . $default_language, 'id');
        $designations = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $Compact = ['departments', 'designations', 'employee'];
        if (auth()->user()->type == 1) {
            $emp_con = ['users.type' => 3, 'users.sub_emp_id' => 0, 'users.id_parent_organisation' => auth()->user()->id];
            if (auth()->user()->sub_emp_id > 0) {
                $emp_con['users.id_parent_organisation'] = auth()->user()->sub_emp_id;
            }
            $petrol_pump = Employees::whereHas('user', function ($query) use ($emp_con) {
                $query->where($emp_con);
            })->orderBy('organization_name', 'ASC')->get();
            $Compact[] = 'petrol_pump';
        }
        return view('employees.create', compact($Compact));
    }

    public function store(Request $request)
    {
        $messages = [
            'department_id.required' => 'The Department field is required.',
            'designation_id.required' => 'The Designation field is required.',
            'username' => 'The username field is required',
            'username.unique' => 'This username is already taken.',
            'password.required' => 'The password field is required.',
            'password_confirmation.required' => 'The password field is required.',
            'password.same' => 'The password and confirm password must be same.',
            'name.required' => 'The name field is required.',
            'phone_number.integer' => 'Please enter valid number',
            'date_of_birth' => 'The Date of birth field is required',
            'joining_date' => 'The Date of joining field is required',
            'joining_date.after' => 'The Date of joining field should be after Date of Birth',
            /* 'email.email' => 'Please enter a valid email address.',
            'email.unique' => 'This email is already taken.', */
        ];
        $this->validate($request, [
            'department_id' => 'required',
            'designation_id' => 'required',
            'username' => 'required|unique:users,username',
            'name' => 'required',
            'phone_number' => 'integer',
            'date_of_birth' => 'required|date',
            'joining_date' => 'required|date|after:start_date',
            /* 'email' => 'email|unique:users,email', */
            'password' => 'required|same:password_confirmation',

        ], $messages);
        if ($request->isMethod('post')) {
            $employee = new Employees();
            $employee->fill($request->all());
            $user = new User();
            $user->username = $request->input('username');
            $user->email = $request->input('email') == '' ? $request->input('email') : NULL ;
            $user->password = bcrypt($request->input('password'));
            $user->type = Auth()->user()->type;
            $user->sub_emp_id = Auth()->user()->id;
            if ($user->save()) {
                $lastUserId = User::latest('id')->first()->id;
                $employee->emp_id = "EMP-".rand("999999", '111111');
				$employee->user_id = $lastUserId;

                if(Auth()->user()->type == 1 && $request->input('assign_petrol_pump') && is_array($request->input('assign_petrol_pump'))){
                    $employee->assign_petrol_pump = json_encode(array_values($request->input('assign_petrol_pump')));
                }else {
                    $employee->assign_petrol_pump = NULL;
				}
                if ($employee->save()) {
                if (auth()->user()->type == 1 && $request->has('assign_petrol_pump') && is_array($request->input('assign_petrol_pump'))) {
                    $employee->assign_petrol_pump = json_encode($request->input('assign_petrol_pump'));
                } else {
                    $employee->assign_petrol_pump = null;
                }

                $employee->save();
                    return redirect()->route('employees.index')->with('success', 'Employee created successfully.');
                } else {
                    return redirect()->back()->with('message', 'Employee not created.');
                }
            }
        } else {
            return redirect()->back()->with('message', 'User not created.');
        }
    }

    public function show($id)
    {
        $employee = Employees::with(['department', 'designation', 'user'])->findOrFail($id);
        return view('employees.show', compact('employee'));
    }

    public function editemployee($id)
    {
        $default_language = get_default_language();
        $employee = Employees::with('user')->findOrFail($id);
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->pluck('title_' . $default_language, 'id');
        $designations = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        $Compact = ['departments', 'designations', 'employee','workingregions'];
        if (auth()->user()->type == 1) {
            $emp_con = ['users.type' => 3, 'users.sub_emp_id' => 0, 'users.id_parent_organisation' => auth()->user()->id];
            if (auth()->user()->sub_emp_id > 0) {
                $emp_con['users.id_parent_organisation'] = auth()->user()->sub_emp_id;
            }
            $petrol_pump = Employees::whereHas('user', function($query) use ($emp_con) {
                $query->where($emp_con);
            })->orderBy('organization_name', 'ASC')->get();
            $Compact[] = 'petrol_pump';
        }
        return view('employees.edit',  compact($Compact));
    }

    public function updateemployee(Request $request)
    {
        $id = $request->id;
        $user_id = $request->user_id;
        $messages = [
            'department_id.required' => 'The Department field is required.',
            'designation_id.required' => 'The Designation field is required.',
            'username' => 'The username field is required',
            'username.unique' => 'This username is already taken.',
            'password_confirmation.required' => 'The password field is required.',
            'password.same' => 'The password and confirm password must be same.',
            'name.required' => 'The name field is required.',
            'phone_number.integer' => 'Please enter valid number',
            'date_of_birth' => 'The Date of birth field is required',
            'joining_date' => 'The Date of joining field is required',
            /* 'email.email' => 'Please enter a valid email address.',
            'email.unique' => 'This email is already taken.', */
        ];
        $this->validate($request, [
            'department_id' => 'required',
            'designation_id' => 'required',
            'username' => 'required|unique:users,username,'.$user_id,
            'name' => 'required',
            'phone_number' => 'integer',
            'date_of_birth' => 'required',
            'joining_date' => 'required',
            /* 'email' => 'required|email|max:160|unique:users,email,'.$user_id, */
            'password' => 'same:password_confirmation',

        ], $messages);
        if ($request->isMethod('post')) {
            $employee = Employees::find($id);
            $employee->fill($request->all());
            $user = $employee->user;
            $user->username = $request->username;
            $user->email = $request->email;
            if ($request->filled('password')) {
                $user->password = bcrypt($request->password);
            }
            if ($user->save()) {
                if ($request->input('assign_petrol_pump') && $request->input('assign_petrol_pump')) {
                    $employee->assign_petrol_pump = json_encode(array_values($request->input('assign_petrol_pump')));
                } else {
                    $employee->assign_petrol_pump = null;
                }
                if ($employee->save()) {
                    return redirect()->route('employees.index')->with('success', 'Employee updated successfully.');
                } else {
                    return redirect()->back()->with('message', 'Employee not updated.');
                }
            }
        } else {
            return redirect()->back()->with('message', 'User not updated.');
        }
    }

    public function deleteemployee(Request $request)
    {
        if ($request->has('status')) {
            $id = $request->status;
            $default_language = get_default_language();

            // Check if the employee exists
            $employee = Employees::with('user')->find($id);

            if ($employee) {
                $user = User::find($employee->user_id);

                // Delete the employee and related user
                if ($user) {
                    $user->delete();
                    $employee->delete();

                    // Delete profile pictures and organization logos if they exist
                    if ($employee->profile_picture) {
                        unlink(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder') . DIRECTORY_SEPARATOR . $employee->profile_picture));
                    }
                    if ($employee->organization_logo) {
                        unlink(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder') . DIRECTORY_SEPARATOR . $employee->organization_logo));
                    }

                    // Get sub-employees
                    $subEmployees = Employees::with('user')->where('user_id', $user->id)->get();

                    if (!$subEmployees->isEmpty()) {
                        foreach ($subEmployees as $subEmployee) {
                            $subUser = User::find($subEmployee->user_id);

                            if ($subUser && $subUser->delete()) {
                                $subEmployee->delete();

                                // Delete profile pictures and organization logos for sub-employees
                                if ($subEmployee->profile_picture) {
                                    unlink(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder') . DIRECTORY_SEPARATOR . $subEmployee->profile_picture));
                                }
                                if ($subEmployee->organization_logo) {
                                    unlink(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder') . DIRECTORY_SEPARATOR . $subEmployee->organization_logo));
                                }
                            }
                        }
                    }

                    // Retrieve updated data for the table
                    $allData = DB::table('employees')
                        ->select('employees.id', 'employees.emp_id', 'employees.name', DB::raw('departments.title_' . $default_language . ' as department_title'), DB::raw('designations.title_' . $default_language . ' as designation_title'), 'users.username', 'employees.phone_number', 'users.status')
                        ->join('departments', 'employees.department_id', '=', 'departments.id')
                        ->join('designations', 'employees.designation_id', '=', 'designations.id')
                        ->join('users', 'employees.user_id', '=', 'users.id')
                        ->where('users.type', auth()->user()->type)
                        ->where('users.sub_emp_id', auth()->user()->id)
                        ->where(function ($query) {
                            $query->where('users.type', 1)
                                ->orWhere('users.sub_emp_id', '>', 0);
                        })
                        ->whereNull('employees.deleted_at')
                        ->get();
                    foreach ($allData as $key => $allDataRow) {
                        $html = '<a href="" class="btn btn-warning btn-circle btn-sm"><i class="fas fa-edit"></i></a>
                                <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="employees" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                        $status = '<button class="btn btn-' . ($allDataRow->status == 'Y' ? 'success' : 'danger') . ' btn-circle update-status" data-status-module="employees" data-id="' . $allDataRow->id . '">'
                            . ($allDataRow->status == 'Y' ? 'Activate' : 'Deactivate') . '</button>';
                        $allDataRow->status = $status;
                        $allDataRow->action = $html;
                    }

                    return response()->json(['data' => $allData, 'message' => 'Employee deleted successfully.'], 200);
                } else {
                    return response()->json(['error' => 'Employee not found'], 404);
                }
            } else {
                return response()->json(['error' => 'Invalid request'], 400);
            }
        }
    }

    //========================End Employee===========================//

    //========================Start Petrol Pump===========================//
    public function indexPs(Request $request){
        $emp_con = ['users.type' => 3];
        $emp_con['users.sub_emp_id'] = 0;
        if (Auth::user()->type == 1) {
            $emp_con['users.id_parent_organisation'] = Auth::user()->id;
            if (Auth::user()->sub_emp_id > 0) {
                $emp_con['users.id_parent_organisation'] = Auth::user()->sub_emp_id;
            }
        }
        $employees = Employees::whereHas('user', function ($query) use ($emp_con) {
                $query->where($emp_con);
            })
            ->with(['user', 'working_region'])
            //->orderByDesc('user.id')
            ->get();
        return view('employees.index_ps', compact('employees'))->with('i');
    }

    public function addPs(Request $request)
    {
        $racData = ['users.type' => 1];
        $distribute_center = Employees::whereHas('user', function ($query) use ($racData) {
                            $query->where($racData);
                            })
                            ->with(['user'])
                            ->orderBy('id', 'ASC')->pluck('organization_name','user_id');
        $default_language = get_default_language();
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.add_ps', compact('departments', 'designation', 'workingregions','distribute_center'));
    }

    public function storePs(Request $request)
    {
        $default_language = get_default_language();
        $employee = new Employees();
        $errormsg = 'This field is required';
        $request->validate([
            'working_region_id' => 'required',
            'distributecenter' => 'required',
            'emp_id' => 'required',
            'username' => 'required|unique:users,username',
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
            'organization_name' => 'required',
            'up_profile_picture' => 'required',
            'organization_phone' => 'required',
            'organization_address' => 'required',
        ], [
            'working_region_id.required' =>  $errormsg,
            'distributecenter.required' =>  $errormsg,
            'emp_id.required' =>  $errormsg,
            'username.required' =>  $errormsg,
            'username.unique' => 'This username is already taken.',
            'password.required' => 'Password and Confirm Password are required',
            'password.confirmed' => 'Password and Confirm Password do not match',
            'password_confirmation.required' => $errormsg,
            'organization_name.required' =>  $errormsg,
            'up_profile_picture.required' =>  $errormsg,
            'organization_phone.required' =>  $errormsg,
            'organization_address.required' =>  $errormsg,
        ]);
        if ($request->isMethod('post')) {
            $flag1 = true;
            $employee->fill($request->all());
            if ($request->hasFile('up_profile_picture') && $request->file('up_profile_picture')->isValid()) {
                $extension = $request->file('up_profile_picture')->getClientOriginalExtension();
                $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
                $profile_picture = 'profile_picture_' . time() . "." . $extension;
                $move_location_profile_picture = storage_path('app/public/') . config('app.upload_folder') . '/' . config('app.organization_logo_folder') . '/' . $profile_picture;
                if (in_array($extension, $file_extension)) {
                    $flag1 = true;
                    $employee->profile_picture = $profile_picture;
                } else {
                    $flag1 = false;
                }
            }

            $user = new user();
            $user->username = $request->input('username');
            $user->email = $request->input('email');
            $user->password = bcrypt($request->input('password'));
            $user->type = $request->input('type');
            $user->id_parent_organisation = $request->input('distributecenter');
            $user->created_at = now();
            $user->updated_at = now();
            $save_user = $user->save();
            if ($save_user) {
                $employee->user_id = $user->id;
                if ($employee->save()) {
                    if ($request->hasFile('up_profile_picture') && $flag1 == true) {
                        $request->file('up_profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                    }
                    return redirect()->route('index-ps')->with('message', 'Account created successfully');
                } else {
                    $error_msg = $employee->errors()->all();
                }
            } else {
                $error_msg = $user->errors()->all();
            }
        }
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.add_ps', compact('employee', 'departments', 'designation', 'workingregions'));
    }

    public function fetchAuditCenter(Request $request)
    {

        $data = [];
        $data['msg'] = 'Some data missing.';
        if ($request->isMethod('post')) {
            if ($request->input('working_region_id') != "") {

                $users = User::join("employees","employees.user_id","=","users.id")->where('users.status', 'Y')
                        ->where('users.type', 1)->where('users.sub_emp_id', 0)->orderBy('employees.organization_name', 'ASC')
                        ->limit(1000)
                        ->where("employees.working_region_id",$request->input('working_region_id'))
                        ->get();

                if ($users->count() > 0) {
                        $data['msg'] = "success";
                        $data['content'] = $users->toArray();
                } else {
                        $data['msg'] = "No data found";
                }
            }
        }
        return response()->json($data);
    }

    public function editPs(Request $request)
    {
        $default_language = get_default_language();
        try {
            $employee = Employees::with('user')->findOrFail($request->id);
        } catch (ModelNotFoundException $exception) {
            dd("Employee not found"); // Debugging: Handle the case where no employee is found
        }

        //dd($employee->user->id_parent_organisation);
        $departments = Departments::where('status', 'Y')->where('is_parent', 0)->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.edit_ps', compact('employee','departments', 'designation', 'workingregions'));
    }

    public function updatePs(Request $request, $id){
        $employee = Employees::find($id);
        $user_id = $employee->user_id;
        $errormsg = 'This field is required';
        $request->validate([
            'working_region_id' => 'required',
            'id_parent_organisation' => 'required',
            'emp_id' => 'required',
            'username' => 'required|unique:users,username,'.$user_id,
            'password' => 'confirmed',
            'organization_name' => 'required',
            'organization_phone' => 'required',
            'organization_address' => 'required',

        ], [
            'working_region_id.required' =>  $errormsg,
            'id_parent_organisation.required' =>  $errormsg,
            'emp_id.required' =>  $errormsg,
            'username.required' =>  $errormsg,
            'username.unique' => 'This username is already taken.',
            'password.confirmed' => 'Password and Confirm Password do not match',
            'organization_name.required' =>  $errormsg,
            'organization_phone.required' =>  $errormsg,
            'organization_address.required' =>  $errormsg,

        ]);

        $employee->fill($request->all());
        $user = $employee->user;
        $user->username  = $request->input('username');
        $user->email = $request->input('email');
        if ($request->input('password') != '') {
            $user->password = bcrypt($request->input('password'));
        }
        $user->type = $request->type;
		$user->id_parent_organisation = $request->id_parent_organisation;
        if ($user->save()) {
            if ($employee->save()) {
                if ($request->hasFile('up_profile_picture') && $request->file('up_profile_picture')->isValid()) {
                        $extension = $request->file('up_profile_picture')->getClientOriginalExtension();
                        $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
                        $profile_picture = 'profile_picture_' . time() . "." . $extension;
                        $move_location_profile_picture = storage_path('app/public/') . config('app.upload_folder') . '/' . config('app.organization_logo_folder') . '/' . $profile_picture;
                        if (in_array($extension, $file_extension)) {
                            $flag1 = true;
                            $employee->profile_picture = $profile_picture;
                        } else {
                            $flag1 = false;
                            // Flash message for invalid image format
                        }
                        $request->file('up_profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                }
                return redirect()->route('index-ps')->with('success', 'Record has been updated successfully');
            } else {
                $employeeErrors = $employee->getErrors();
                if (!empty($employeeErrors)) {
                    $errorMessages = [];
                    foreach ($employeeErrors as $key => $errors) {
                        $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                    }
                    redirect()->route('index-ps')->with('error', 'The record could not be saved. ' . implode(' and ', $errorMessages));
                }
            }
        } else {
            $userErrors = $user->getErrors();
            if (!empty($userErrors)) {
                $errorMessages = [];
                foreach ($userErrors as $key => $errors) {
                    $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                }
                session()->flash('error', 'The record could not be saved. Try with different login credential. ' . implode(' and ', $errorMessages));
            }
        }
        redirect()->route('index-ps');
    }

    public function destroyPS($id)
    {
        if ($id == '' || $id == null) {
            return Response::json(['message' => 'User not found.'], 404);
        }
        $default_language = get_default_language();
        $employee = Employees::with('user')->find($id);
        if (empty($employee)) {
            return Response::json(['message' => 'User not found.'], 404);
        } else {
            $user = $employee->user;
            if ($user->delete()) {
                if ($employee->delete()) {
                    // Handle profile picture and organization logo deletion
                    if ($employee->profile_picture != '' && Storage::disk('public')->exists($employee->profile_picture)) {
                        Storage::disk('public')->delete($employee->profile_picture);
                    }
                    if ($employee->organization_logo != '' && Storage::disk('public')->exists($employee->organization_logo)) {
                        Storage::disk('public')->delete($employee->organization_logo);
                    }

                    $emp_con = ['users.type' => 3];
                    $emp_con['users.sub_emp_id'] = 0;

                    if (Auth::user()->type == 1) {
                        $emp_con['users.id_parent_organisation'] = Auth::user()->sub_emp_id > 0 ? Auth::user()->sub_emp_id : Auth::user()->id;
                    }

                    $allData = DB::table('employees')
                        ->select('employees.id', 'employees.emp_id', 'working_regions.region_name_' . $default_language, 'employees.organization_name', 'users.username', 'employees.organization_phone')
                        ->join('working_regions', 'employees.working_region_id', '=', 'working_regions.id')
                        ->join('users', 'employees.user_id', '=', 'users.id')
                        ->where($emp_con)
                        ->whereNull('employees.deleted_at')
                        ->get();

                    foreach ($allData as $allDataRow) {
                        $html = '<a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('edit-ps', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                                <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="delete-ps" data-id="' . $allDataRow->id . '" data-url="' . route('delete-ps', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';
                        $allDataRow->action = $html;
                    }
                    return response()->json(['data' => $allData, 'message' => 'User deleted successfully.'], 200);
                } else {
                    return Response::json(['message' => 'Invalid request.'], 400);
                }
            } else {
                return Response::json(['message' => 'Invalid request.'], 400);
            }
        }
    }
    //========================End Petrol Pump===========================//

    //========================Start Regional Audit Center===========================//
    public function indexRac(Request $request){
        $employees = Employees::whereHas('user', function ($query) {
            $query->where('type', 1);
        })
            ->with(['user', 'working_region'])
            ->get();
        return view('employees.index_rac', compact('employees'))->with('i');
    }

    public function addRac(Request $request)
    {
        $default_language = get_default_language();
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.add_rac', compact('departments', 'designation', 'workingregions'));
    }

    public function storeRac(Request $request)
    {
        $default_language = get_default_language();
        $employee = new Employees();
        $errormsg = 'This field is required';
        $request->validate([
            'working_region_id' => 'required',
            'emp_id' => 'required',
            'username' => 'required|unique:users,username',
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
            'organization_name' => 'required',
            'up_profile_picture' => 'required',
            'organization_phone' => 'required|integer',
            'organization_address' => 'required',
        ], [
            'working_region_id.required' =>  $errormsg,
            'emp_id.required' =>  $errormsg,
            'username.required' =>  $errormsg,
            'username.unique' => 'This username is already taken.',
            'password.required' => 'Password and Confirm Password are required',
            'password.confirmed' => 'Password and Confirm Password do not match',
            'password_confirmation.required' => $errormsg,
            'organization_name.required' =>  $errormsg,
            'up_profile_picture.required' =>  $errormsg,
            'organization_phone.required' =>  $errormsg,
            'organization_phone.integer' => 'Enter Valid Number',
            'organization_address.required' =>  $errormsg,
        ]);
        if ($request->isMethod('post')) {
            $flag1 = true;
            $employee->fill($request->all());
            if ($request->hasFile('up_profile_picture') && $request->file('up_profile_picture')->isValid()) {
                $extension = $request->file('up_profile_picture')->getClientOriginalExtension();
                $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
                $profile_picture = 'profile_picture_' . time() . "." . $extension;
                if (in_array($extension, $file_extension)) {
                    $flag1 = true;
                    $employee->profile_picture = $profile_picture;
                } else {
                    $flag1 = false;
                }
                if (in_array($extension, $file_extension)) {
                    $flag1 = true;
                    $employee->profile_picture = $profile_picture;
                } else {
                    $flag1 = false;
                }
            }

            $user = new User();
            $user->username = $request->input('username');
            $user->email = $request->input('email');
            $user->password = bcrypt($request->input('password'));
            $user->type = $request->input('type');
            $user->created_at = now();
            $user->updated_at = now();
            $save_user = $user->save();
            if ($save_user) {
                $employee->user_id = $user->id;
                if ($employee->save()) {
                    if ($request->hasFile('up_profile_picture') && $flag1 == true) {
                        $request->file('up_profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                    }
                    return redirect()->route('index-rac')->with('message', 'Account created successfully');
                } else {
                    $error_msg = $employee->errors()->all();
                }
            } else {
                $error_msg = $user->errors()->all();
            }
        }
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.add_rac', compact('employee', 'departments', 'designation', 'workingregions'));
    }

    public function editRac(Request $request)
    {
        $default_language = get_default_language();
        try {
            $employee = Employees::with('user')->findOrFail($request->id);
        } catch (ModelNotFoundException $exception) {
            dd("Employee not found"); // Debugging: Handle the case where no employee is found
        }

        $departments = Departments::where('status', 'Y')->where('is_parent', 0)->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.edit_rac', compact('employee','departments', 'designation', 'workingregions'));
    }

    public function updateRac(Request $request, $id){

        $employee = Employees::find($id);
        $user_id = $employee->user_id;
        $errormsg = 'This field is required';
        $request->validate([
            'working_region_id' => 'required',
            'emp_id' => 'required',
            'username' => 'required|unique:users,username,'.$user_id,
            'password' => 'confirmed',
            'organization_name' => 'required',
            'organization_phone' => 'required|integer',
            'organization_address' => 'required',

        ], [
            'working_region_id.required' =>  $errormsg,
            'emp_id.required' =>  $errormsg,
            'username.required' =>  $errormsg,
            'username.unique' => 'This username is already taken.',
            'password.confirmed' => 'Password and Confirm Password do not match',
            'organization_name.required' =>  $errormsg,
            'organization_phone.required' =>  $errormsg,
            'organization_phone.integer' => 'Enter Valid Number',
            'organization_address.required' =>  $errormsg,

        ]);

        $employee->fill($request->all());
        if ($request->hasFile('up_profile_picture') && $request->file('up_profile_picture')->isValid()) {
            $extension = $request->file('up_profile_picture')->getClientOriginalExtension();
            $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
            $profile_picture = 'profile_picture_' . time() . "." . $extension;
            if (in_array($extension, $file_extension)) {
                $flag1 = true;
                $employee->profile_picture = $profile_picture;
            } else {
                $flag1 = false;
            }
        }
        $user = $employee->user;
        $user->username  = $request->input('username');
        $user->email = $request->input('email');
        if ($request->input('password') != '') {
           // $user->password = bcrypt($request->input('password'));
            $user->password = bcrypt($request->input('password'));
        }
        $user->type = $request->input('type');
        if ($user->save()) {
            if ($employee->save()) {
                if ($request->hasFile('up_profile_picture') && $flag1 == true) {
                    $request->file('up_profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                }
                return redirect()->route('index-rac')->with('success', 'Record has been updated successfully');
            } else {
                $employeeErrors = $employee->getErrors();
                if (!empty($employeeErrors)) {
                    $errorMessages = [];
                    foreach ($employeeErrors as $key => $errors) {
                        $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                    }
                    redirect()->route('index-rac')->with('error', 'The record could not be saved. ' . implode(' and ', $errorMessages));
                }
            }
        } else {
            $userErrors = $user->getErrors();
            if (!empty($userErrors)) {
                $errorMessages = [];
                foreach ($userErrors as $key => $errors) {
                    $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                }
                session()->flash('error', 'The record could not be saved. Try with different login credential. ' . implode(' and ', $errorMessages));
            }
        }
        redirect()->route('index-rac');
    }

    public function destroyRac($id)
    {
        if ($id == '' || $id == null) {
            return Response::json(['message' => 'User not found.'], 404);
        }
        $employee = Employees::with('user')->find($id);
        if (empty($employee)) {
            return Response::json(['message' => 'User not found.'], 404);
        } else {
            $user = $employee->user;
            if ($user->delete()) {
                if ($employee->delete()) {
                    // Handle profile picture and organization logo deletion
                    if ($employee->profile_picture != '' && file_exists(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')) . DIRECTORY_SEPARATOR . $employee->profile_picture)) {
                        Storage::disk('public')->delete(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')) . DIRECTORY_SEPARATOR . $employee->profile_picture);
                    }
                    if ($employee->organization_logo != '' && file_exists(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')) . DIRECTORY_SEPARATOR . $employee->organization_logo)) {
                        Storage::disk('public')->delete($employee->organization_logo);
                    }
                    $default_language = get_default_language();
                    $allData = DB::table('employees')
                        ->select('employees.id', 'employees.emp_id', 'working_regions.region_name_' . $default_language, 'employees.organization_name', 'users.username', 'employees.organization_phone')
                        ->join('working_regions', 'employees.working_region_id', '=', 'working_regions.id')
                        ->join('users', 'employees.user_id', '=', 'users.id')
                        ->where('users.type', 1)
                        ->whereNull('employees.deleted_at')
                        ->get();
                    foreach ($allData as $allDataRow) {
                        $html = '<a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('edit-rac', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                                <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="delete-rac" data-id="' . $allDataRow->id . '" data-url="' . route('delete-rac', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';
                        $allDataRow->action = $html;
                    }
                    return response()->json(['data' => $allData, 'message' => 'User deleted successfully.'], 200);
                } else {
                    return Response::json(['message' => 'Invalid request.'], 400);
                }
            } else {
                return Response::json(['message' => 'Invalid request.'], 400);
            }
        }
    }
    //========================End Regional Audit Center===========================//

    //========================Start Regional Distribution Center===========================//
    public function addRDC()
    {
        $pageTitle ="Create New Regional Distribution Center Account";
        $default_language = get_default_language();
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.add-rdc', compact('departments', 'designation', 'workingregions','pageTitle'));
    }

    public function listOfRDC(Request $request)
    {
        $pageTitle = 'List(s) Of Regional Distribution Center';
        $emp_con = ['users.type' => 4];
        $employees = Employees::whereHas('user', function ($query) use ($emp_con) {
                $query->where($emp_con);
            })
            ->with(['user', 'working_region'])
            ->get();
        return view('employees.index-rdc', compact('employees','pageTitle'))->with('i');
    }

    public function storeRDC(Request $request)
    {
        $default_language = get_default_language();
        $errormsg = 'This field is required';
        $request->validate([
            'working_region_id' => 'required',
            'emp_id' => 'required',
            'username' => 'required|unique:users,username',
            'password' => 'required|confirmed',
            'password_confirmation' => 'required',
            'organization_name' => 'required',
            'up_profile_picture' => 'required|image|mimes:jpeg,png,jpg,gif,JPEG,PNG,JPG,GIF',
            'organization_phone' => 'required|integer',
            'organization_address' => 'required',
        ], [
            'working_region_id.required' =>  $errormsg,
            'emp_id.required' =>  $errormsg,
            'username.required' =>  $errormsg,
            'username.unique' => 'This username is already taken.',
            'password.required' => 'Password and Confirm Password are required',
            'password.confirmed' => 'Password and Confirm Password do not match',
            'password_confirmation.required' => $errormsg,
            'organization_name.required' =>  $errormsg,
            'up_profile_picture.required' =>  $errormsg,
            'up_profile_picture.image' => 'The selected file is not a valid image.',
            'up_profile_picture.mimes' => 'Only JPEG, PNG, JPG, GIF, jpeg, png, jpg, and gif image formats are allowed.',
            'organization_phone.required' =>  $errormsg,
            'organization_phone.integer' => 'Enter Valid Number',
            'organization_address.required' =>  $errormsg,
        ]);
        $employee = new Employees();

        if ($request->isMethod('post')) {
            $flag1 = true;
            $employee->fill($request->all());
            if ($request->hasFile('up_profile_picture') && $request->file('up_profile_picture')->isValid()) {
                $extension = $request->file('up_profile_picture')->getClientOriginalExtension();
                $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
                $profile_picture = 'profile_picture_' . time() . "." . $extension;
                $move_location_profile_picture = storage_path('app/public/') . config('app.upload_folder') . '/' . config('app.organization_logo_folder') . '/' . $profile_picture;
                if (in_array($extension, $file_extension)) {
                    $flag1 = true;
                    $employee->profile_picture = $profile_picture;
                } else {
                    $flag1 = false;
                }
            }

            $user = new User();
            $user->username = $request->input('username');
            $user->email = $request->input('email');
            $user->password = bcrypt($request->input('password'));
            $user->type = $request->input('type');
            $user->created_at = now();
            /* $user->updated_at = now(); */
            $save_user = $user->save();
            if ($save_user) {
                $employee->user_id = $user->id;
                if ($employee->save()) {
                    if ($request->hasFile('up_profile_picture') && $flag1 == true) {
                        $request->file('up_profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                    }
                    return redirect()->route('index-rdc')->with('message', 'Account created successfully');
                } else {
                    $error_msg = $employee->errors()->all();
                }
            } else {
                $error_msg = $user->errors()->all();
            }
        }
        $departments = Departments::where(['status' => 'Y', 'is_parent' => 0])->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.index-rdc', compact('employee', 'departments', 'designation', 'workingregions'));
    }

    public function editRDC(Request $request)
    {
        $default_language = get_default_language();
        try {
            $employee = Employees::with('user')->findOrFail($request->id);
        } catch (ModelNotFoundException $exception) {
            redirect()->route('index-rdc')->with('message', 'Employee not found'); // Debugging: Handle the case where no employee is found
        }
        $departments = Departments::where('status', 'Y')->where('is_parent', 0)->get();
        $designation = Designations::where('status', 'Y')->pluck('title_' . $default_language, 'id');
        $workingregions = WorkingRegion::where('status', 'Y')->orderBy('id', 'ASC')->pluck('region_name_' . $default_language, 'id');
        return view('employees.edit-rdc', compact('employee','departments', 'designation', 'workingregions'));
    }

    public function updateRDC(Request $request, $id)
    {
        $employee = Employees::find($id);
        $user_id = $employee->user_id;
        $errormsg = 'This field is required';
        $request->validate([
            'working_region_id' => 'required',
            'emp_id' => 'required',
            'username' => 'required|unique:users,username,'.$user_id,
            'password' => 'confirmed',
            'organization_name' => 'required',
            'organization_phone' => 'required|integer',
            'up_profile_picture' => 'image|mimes:jpeg,png,jpg,gif,JPEG,PNG,JPG,GIF',
            'organization_address' => 'required',

        ], [
            'working_region_id.required' =>  $errormsg,
            'emp_id.required' =>  $errormsg,
            'username.required' =>  $errormsg,
            'username.unique' => 'This username is already taken.',
            'password.confirmed' => 'Password and Confirm Password do not match',
            'organization_name.required' =>  $errormsg,
            'organization_phone.required' =>  $errormsg,
            'organization_phone.integer' => 'Enter Valid Number',
            'up_profile_picture.image' => 'The selected file is not a valid image.',
            'up_profile_picture.mimes' => 'Only JPEG, PNG, JPG, GIF, jpeg, png, jpg, and gif image formats are allowed.',
            'organization_address.required' =>  $errormsg,

        ]);
       $employee->fill($request->all());
        if ($request->hasFile('up_profile_picture') && $request->file('up_profile_picture')->isValid()) {
            $extension = $request->file('up_profile_picture')->getClientOriginalExtension();
            $file_extension = array("jpg", "gif", "png", "jpeg","JPG", "GIF", "PNG", "JPEG");
            $profile_picture = 'profile_picture_' . time() . "." . $extension;
            if (in_array($extension, $file_extension)) {
                $flag1 = true;
                $employee->profile_picture = $profile_picture;
            } else {
                $flag1 = false;
            }
        }
        $user = $employee->user;
        $user->username  = $request->input('username');
        $user->email = $request->input('email');
        if ($request->input('password') != '') {
           // $user->password = bcrypt($request->input('password'));
            $user->password = bcrypt($request->input('password'));
        }
        $user->type = $request->input('type');
        if ($user->save()) {
            if ($employee->save()) {
                if ($request->hasFile('up_profile_picture') && $flag1 == true) {
                    $request->file('up_profile_picture')->move(public_path(config('app.upload_folder') . DIRECTORY_SEPARATOR . config('app.organization_logo_folder')), $profile_picture);
                }
                return redirect()->route('index-rdc')->with('success', 'Record has been updated successfully');
            } else {
                $employeeErrors = $employee->getErrors();
                if (!empty($employeeErrors)) {
                    $errorMessages = [];
                    foreach ($employeeErrors as $key => $errors) {
                        $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                    }
                    redirect()->route('index-rdc')->with('error', 'The record could not be saved. ' . implode(' and ', $errorMessages));
                }
            }
        } else {
            $userErrors = $user->getErrors();
            if (!empty($userErrors)) {
                $errorMessages = [];
                foreach ($userErrors as $key => $errors) {
                    $errorMessages[] = is_array($errors) ? implode(' and ', $errors) : $errors;
                }
                session()->flash('error', 'The record could not be saved. Try with different login credential. ' . implode(' and ', $errorMessages));
            }
        }
        redirect()->route('index-rdc');
    }

    public function deleteRDC(Request $request)
    {
        $emp_con = ['users.type' => 4];
        if ($request->has('status')) {
            $record = Employees::with('user')->find($request->status);
            if ($record) {
                $user = $record->user;
                if ($user->delete()) {
                    if ($record->delete()) {
                        // Handle profile picture and organization logo deletion
                        if ($record->profile_picture != '' && Storage::disk('public')->exists($record->profile_picture)) {
                            Storage::disk('public')->delete($record->profile_picture);
                        }
                        if ($record->organization_logo != '' && Storage::disk('public')->exists($record->organization_logo)) {
                            Storage::disk('public')->delete($record->organization_logo);
                        }
                        $default_language = get_default_language();
                        $allData = Employees::select('employees.id', 'employees.emp_id', 'working_regions.region_name_' . $default_language, 'employees.organization_name', 'users.username', 'employees.organization_phone')
                            ->join('working_regions', 'employees.working_region_id', '=', 'working_regions.id')
                            ->join('users', 'employees.user_id', '=', 'users.id')
                            ->whereHas('user', function ($query) use ($emp_con) {
                                $query->where($emp_con);
                            })
                            ->with(['user', 'working_region'])
                            ->get();

                        foreach ($allData as $key => $allDataRow) {
                            $html = '<a href="' . route('employees.editemployee', $allDataRow->id) . '" class="btn btn-warning btn-circle btn-sm" ><i class="fas fa-edit"></i></a>
                                    <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="delete-rdc" data-id="' . $allDataRow->id . '"><i class="fas fa-trash"></i></button>';
                            $allDataRow->action = $html;
                        }

                        return response()->json(['data' => $allData, 'message' => 'Record deleted successfully.'], 200);
                    } else {
                        return response()->json(['error' => 'Invalid request.'], 400);
                    }
                } else {
                    return response()->json(['error' => 'Invalid request.'], 400);
                }
            } else {
                return response()->json(['error' => 'User not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
    //========================End Regional Distribution Center===========================//
}
