<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
        $this->middleware('permission:role-list|role-create|role-edit|role-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:role-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:role-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:role-delete', ['only' => ['destroy']]);
        $this->middleware('permission:role-show', ['only' => ['show']]);
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $roles = Role::get();
        $page_title = "Role Management";
        return view('roles.index', compact('roles', 'page_title'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $permission =  Permission::select('Slug')->distinct()->whereNotNull('Slug')->where('Slug', '<>', '')->get()->toArray();
        $permissionData = [];
        foreach ($permission as $key => $value['Slug']) {
            $permissionData[] = Permission::where('Slug', $value['Slug'])->get(['Slug', 'name', 'id'])->toArray();
        }

        return view('roles.create', compact('permissionData'));
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|unique:roles,name',
            'permissions' => 'required',
        ], [
            'name.required' => 'The name field is required.',
            'name.unique' => 'The name has already been taken.',
            'permissions.required' => 'At least one permission must be selected.',
        ]);
         $filteredPermissions = array_filter($request->input('permissions'), function ($value) {
            return $value !== "0";
        });
        $role = Role::create(['name' => $request->input('name')]);
        $role->syncPermissions($filteredPermissions);

    return redirect()->route('roles.index')
                    ->with('message', 'Role created successfully');
}
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $role = Role::find($id);
        $rolePermissions = Permission::join("role_has_permissions","role_has_permissions.permission_id","=","permissions.id")
            ->where("role_has_permissions.role_id",$id)
            ->get();
    
        return view('roles.show',compact('role','rolePermissions'));
    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $role = Role::find($id);
       $permission =  Permission::select('Slug')->distinct()->whereNotNull('Slug')->where('Slug', '<>', '')->get()->toArray();
        $permissionData = [];
        foreach ($permission as $key => $value['Slug']) {
            $permissionData[] = Permission::where('Slug', $value['Slug'])->get(['Slug', 'name', 'id'])->toArray();
        }

        $rolePermissions = DB::table("role_has_permissions")
            ->where("role_has_permissions.role_id", $id)
            ->pluck('permission_id')
            ->toArray();
  


        return view('roles.edit', compact('role', 'permissionData', 'rolePermissions'));
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $name = $request['name'];
        $adminid = $request->input('role_id');
        $this->validate($request, [
            'name' => 'required|unique:roles,name,'.$id,
            'permissions' => 'required',
        ], [
            'name.required' => 'The name field is required.',
            'name.unique' => 'The Role has already been taken.',
            'permissions.required' => 'At least one permission must be selected.',

        ]);

        $filteredPermissions = array_filter($request->input('permissions'), function ($value) {
            return $value !== "0";
        });
       
        $role = Role::find($id);



        $role->name = $name;
        $role->save();
        $role->syncPermissions($filteredPermissions);



        return redirect()->route('roles.index')
                        ->with('message','Role updated successfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        if (isset($request->status)) {
            $record = Role::find($request->status);
            if ($record) {
                $record->delete();
                $allData = Role::select('id', 'name')->get();
                foreach ($allData as $key => $allDataRow) {
                    $html = '<a class="btn btn-primary btn-circle btn-sm" title="Show" href="' . route('roles.show', $allDataRow->id) . '"><i class="fas fa-eye"></i></a>
                             <a class="btn btn-warning btn-circle btn-sm" title="Edit" href="' . route('roles.edit', $allDataRow->id) . '"><i class="fas fa-edit"></i></a>
                             <button class="btn btn-danger btn-circle btn-sm deletedata" title="Delete" data-module="roles" data-id="' . $allDataRow->id . '" data-url="' . route('roles.destroy', $allDataRow->id) . '"><i class="fas fa-trash"></i></button>';
                    $allDataRow->action = $html;
                }

                return response()->json(['data' => $allData, 'message' => 'Role deleted successfully.'], 200);
            } else {
                return response()->json(['error' => 'Role not found'], 404);
            }
        } else {
            return response()->json(['error' => 'Invalid request'], 400);
        }
    }
}
