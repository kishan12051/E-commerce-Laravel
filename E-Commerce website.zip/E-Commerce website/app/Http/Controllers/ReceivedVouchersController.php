<?php

namespace App\Http\Controllers;

use App\Models\Employees;
use App\Models\ShiftPetrolSales;
use App\Models\ShiftReport;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ReceivedVouchersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     function __construct(){
        $this->middleware('manage-received-vouchers-list', ['only' => ['index','show']]);
    }
    public function index()
    {
        if (auth()->user()->type == 1) {
            $adminIdArr = ["0"];

            if (auth()->user()->sub_emp_id == 0) {
                $adminId = auth()->user()->id;
            } else {
                $adminId = auth()->user()->sub_emp_id;
                $findEmpDetails = Employees::where('user_id', auth()->user()->id)->first();

                if ($findEmpDetails && !empty($findEmpDetails->assign_petrol_pump)) {
                    $adminIdArr = json_decode($findEmpDetails->assign_petrol_pump, true);
                }
            }

            $petrolPumpCon['users.type'] = 3;
            $petrolPumpCon['users.sub_emp_id'] = 0;
            $petrolPumpCon['users.id_parent_organisation'] = $adminId;
            $petrolPumpCon['users.status'] = 'Y';

            if (auth()->user()->sub_emp_id == 0) {
                $assignedPetrolPump = User::where($petrolPumpCon)
                    ->selectRaw('GROUP_CONCAT(DISTINCT(id)) as petrol_station_ids')
                    ->first();

                if (!empty($assignedPetrolPump->petrol_station_ids) && auth()->user()->sub_emp_id == 0) {
                    $adminIdArr = explode(",", $assignedPetrolPump->petrol_station_ids);
                }
            }

            $petrolPumpCon['user_id'] = $adminIdArr;
            $petrolPump = Employees::whereHas('user', function ($query) use ($petrolPumpCon) {

                foreach ($petrolPumpCon as $field => $value) {
                    if (is_array($value)) {
                        // Handle special cases where the value is an array, e.g., for 'IN' conditions
                        $query->whereIn($field, $value);
                    } else {
                        $query->where($field, $value);
                    }
                }
            })
                ->orderBy('organization_name', 'ASC')
                ->pluck('organization_name', 'user_id');

            $vouchertype = ShiftPetrolSales::whereNotNull('voucher_type')
                ->whereHas('shiftReport', function ($query) use ($adminIdArr) {
                    $query->whereIn('user_id', $adminIdArr)
                        ->whereIn('status', ['A', 'R', 'C']);
                })
                ->distinct('voucher_type')
                ->pluck('voucher_type')
                ->toArray();

            $vouchervolumn = ShiftPetrolSales::whereNotNull('voucher_volumn')
                ->whereHas('shiftReport', function ($query) use ($adminIdArr) {
                    $query->whereIn('user_id', $adminIdArr)
                        ->whereIn('status', ['A', 'R', 'C']);
                })
                ->distinct('voucher_volumn')
                ->pluck('voucher_volumn')
                ->toArray();


            return view('received-vouchers.index', compact('petrolPump', 'vouchertype', 'vouchervolumn'));

        } else {
            return redirect()->route('dashboard')
                ->with('error', 'You are not authorized to view this record.');
        }

    }



    public function ajaxReceivedVoucherData(Request $request)
    {

        $response['draw'] = $request->draw;
        $offset = $request->start;
        $length = $request->length;
        $order = $request->order;

        if (request()->ajax()) {

            if (auth()->user()->type == 1) {
                $admin_id_arr = ["0"];
                $admin_id = auth()->user()->sub_emp_id == 0 ? auth()->user()->id : auth()->user()->sub_emp_id;

                if (auth()->user()->sub_emp_id != 0) {
                    $find_emp_details = Employees::where('user_id', auth()->user()->id)->first();

                    if ($find_emp_details && !is_null($find_emp_details->assign_petrol_pump)) {
                        $admin_id_arr = json_decode($find_emp_details->assign_petrol_pump, true);
                    }
                }

                $petrol_pump_con['users.type'] = 3;
                $petrol_pump_con['users.sub_emp_id'] = 0;
                $petrol_pump_con['users.id_parent_organisation'] = $admin_id;
                $petrol_pump_con['users.status'] = 'Y';

                if (auth()->user()->sub_emp_id == 0) {
                    $assigned_petrol_pump = User::selectRaw('GROUP_CONCAT(DISTINCT(id)) as petrol_station_ids')
                        ->where($petrol_pump_con)
                        ->first();

                    if (!empty($assigned_petrol_pump->petrol_station_ids)) {
                        $admin_id_arr = explode(",", $assigned_petrol_pump->petrol_station_ids);

                    }
                }

                $petrol_pump_con['users.id'] = $admin_id_arr;

                $petrol_pump = Employees::whereHas('user', function ($query) use ($petrol_pump_con) {
                    foreach ($petrol_pump_con as $field => $value) {
                        if (is_array($value)) {
                            // Handle special cases where the value is an array, e.g., for 'IN' conditions
                            $query->whereIn($field, $value);
                        } else {
                            $query->where($field, $value);
                        }
                    }
                })
                    ->orderBy('organization_name', 'ASC')
                    ->get();

                $data['petrol_pump'] = $petrol_pump;

                $condition['shift_report.user_id'] = $admin_id_arr;
                $condition['shift_report.status'] = ['A', 'R', 'C'];

                $sales_condition = ShiftPetrolSales::join('shift_report', 'shift_petrol_sales.shift_report_id', '=', 'shift_report.id')
                    ->whereIn('shift_report.user_id', $admin_id_arr)
                    ->whereIn('shift_report.status', ['A', 'R', 'C'])
                    ->whereNotNull('shift_petrol_sales.voucher_type')
                    ->select('shift_petrol_sales.*', 'shift_report.*');



                if (!empty($request->start_date_time)) {
                    $sales_condition->whereDate('shift_petrol_sales.sales_date', '>=', $request->start_date_time);
                }

                if (!empty($request->end_date_time)) {
                    $sales_condition->whereDate('shift_petrol_sales.sales_date', '<=', $request->end_date_time);
                }

                if ($request->petrol_station_id && $request->petrol_station_id !== '') {
                    $petrol_station_ids = $request->petrol_station_id;

                    if (is_array($petrol_station_ids)) {
                        $sales_condition->whereIn('shift_report.user_id', $petrol_station_ids);
                    }
                }

                if (!empty($request->voucher_type)) {
                    $sales_condition->where('shift_petrol_sales.voucher_type', $request->voucher_type);
                }

                if (!empty($request->voucher_volumn)) {
                    $sales_condition->where('shift_petrol_sales.voucher_volumn', $request->voucher_volumn);
                }

                if (!empty($request->search['value'])) {
                    $searchValue = $request['search']['value'];
                    $date_arr = explode('/', $searchValue);
                    $formattedDate = '%';
                    if (isset($date_arr[2]) && $date_arr[2] != "") {
                        $formattedDate .= $date_arr[2] . "-";
                    }
                    if (isset($date_arr[1]) && $date_arr[1] != "") {
                        $formattedDate .= $date_arr[1] . "-";
                    }
                    if (isset($date_arr[0]) && $date_arr[0] != "") {
                        $formattedDate .= $date_arr[0];
                    }
                    $formattedDate .= '%';

                    $sales_condition->where(function ($query) use ($searchValue, $formattedDate) {
                        $query->where('shift_petrol_sales.voucher_type', 'LIKE', "%$searchValue%")
                            ->orWhere('shift_petrol_sales.voucher_volumn', '=', intval($searchValue))
                            ->orWhere('shift_petrol_sales.voucher_quantity', '=', intval($searchValue))
                            ->orWhere('shift_petrol_sales.sales_date', 'LIKE', $formattedDate);

                        $query->orWhereHas('shiftReport', function ($subquery) use ($searchValue) {
                            $subquery->where('shiftid', 'like', "%$searchValue%");
                        });


                        $findSearchedPetrolPump = Employees::where(function ($subsubquery) use ($searchValue) {
                            $subsubquery->where('organization_name', 'LIKE', "%$searchValue%")
                                ->orWhere('name', 'LIKE', "%$searchValue%");
                        })->selectRaw('GROUP_CONCAT(DISTINCT(user_id)) as petrol_pump_admin_ids')->first();

                        if ($findSearchedPetrolPump && $findSearchedPetrolPump->petrol_pump_admin_ids) {
                            $petrolPumpAdminIds = explode(",", $findSearchedPetrolPump->petrol_pump_admin_ids);

                            $query->orWhereIn('shift_report.user_id', $petrolPumpAdminIds);
                        }
                    });


                }

                $shiftPetrolSale = $sales_condition->with('shiftReport')
                    ->orderBy('shift_petrol_sales.sales_date', 'DESC');

                $count = $shiftPetrolSale->count();

                $filteredCount = $count; 
                // Get the data for the current page
                $shiftPetrolSales = $shiftPetrolSale->skip($offset)->take($length)->get();

                $records_data = [];

                if (isset($shiftPetrolSales) && $shiftPetrolSales && !$shiftPetrolSales->isEmpty()) {

                    foreach ($shiftPetrolSales as $key => $report) {
                        $find_petrol_pump = '';


                        if ($report->shiftReport && $report->shiftReport->user_id > 0) {
                            $admin_conditions['users.status'] = 'Y';
                            $admin_conditions['users.id'] = $report->shiftReport->user_id;

                            $admin = User::where($admin_conditions)
                                ->join('employees as e', 'e.user_id', '=', 'users.id')
                                ->select('users.id', 'e.name', 'e.id as e_id', 'e.organization_name')
                                ->first();

                            if ($admin) {
                                $find_petrol_pump = ($admin->name ?: ($admin->organization_name ?: ""));

                            }

                        }

                        $records_data[] = [
                            'shift_report_id' => $report->shiftReport->shiftid ?? '',
                            'user_id' => $find_petrol_pump,
                            'sales_date' => $report->sales_date,
                            'voucher_type' => $report->voucher_type,
                            'voucher_volumn' => $report->voucher_volumn,
                            'voucher_quantity' => $report->voucher_quantity,
                        ];
                    }
                }

                $formattedData = [
                    'draw' => $request->draw,
                    'recordsTotal' => $count,
                    'recordsFiltered' => $filteredCount,
                    'data' => $records_data,
                ];

                return response()->json($formattedData);
            }

        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}