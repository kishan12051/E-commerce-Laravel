<?php

use App\Models\ShiftTankReadings;
use App\Models\Reservoirs;
use App\Models\ShiftPetrolSales;
use App\Models\ShiftFillingReadings;
use App\Models\PetrolPrice;
use App\Models\ShiftPumpReadings;
use Carbon\Carbon;
use App\Models\User;
use App\Models\ShiftBottledOilSales;
use App\Models\GeneralSettings;
use App\Models\ShiftReport;
use App\Models\Shifts;
use Illuminate\Support\Facades\DB;

if (!function_exists('get_default_language')) {
    function get_default_language() {
        $default_language = '';
        if (auth()->check()) {
            $find_user = \App\Models\User::where('id', auth()->id())->first();
            if ($find_user && $find_user->default_language != '') {
                $default_language = $find_user->default_language;
            }
        }

        if ($default_language == '') {
            $find_default_language = \App\Models\Language::where('status', 'Y')
                ->where('is_default', 'Y')
                ->first();

            if ($find_default_language && $find_default_language->short_code != '') {
                $default_language = $find_default_language->short_code;
            } else {
                $find_first_language = \App\Models\Language::where('status', 'Y')
                    ->orderBy('serial_no', 'ASC')
                    ->first();

                if ($find_first_language && $find_first_language->short_code != '') {
                    $default_language = $find_first_language->short_code;
                } else {
                    $default_language = 'en';
                }
            }
        }

        return $default_language;
    }
}

if (!function_exists('sumShiftTankReading')) {
    function sumShiftTankReading($petrolTypeId, $shiftId)
    {

    $findCurrentFillingData = ShiftTankReadings::selectRaw('SUM(start_shift_fuel) AS total_sum')
        ->where('shift_report_id', $shiftId)
        ->where('petrol_typeid', $petrolTypeId)
        ->groupBy('petrol_typeid')
        ->first();

        return $findCurrentFillingData->total_sum > 0 ? $findCurrentFillingData->total_sum : "0";
    }
}
if (!function_exists('reservoirs')) {
    function reservoirs($petrolTypeId, $userId)
    {
        $findReservoirs = Reservoirs::where('user_id', $userId)
            ->where('petrol_type_id', $petrolTypeId)
            ->where('status', 1)
            ->get();
        return $findReservoirs;
    }
}

if (!function_exists('findShiftPumpTotalSoldInLiter')) {
    function findShiftPumpTotalSoldInLiter($shiftReportId = null, $petrolPumpId = null)
    {
        $findShiftPumpTotalSoldInLiter = ShiftPetrolSales::selectRaw(('SUM(total_sold) as total_sum'))
            ->where('shift_report_id', $shiftReportId)
            ->where('petrol_pump_id', $petrolPumpId)
            ->groupBy('petrol_pump_id')
            ->first();

        return $findShiftPumpTotalSoldInLiter;
    }
}

if (!function_exists('findCurrentFuelData')) {

    function findCurrentFuelData($petrolTypeId = null, $shiftId = null)
    {
        $findCurrentFillingData = ShiftFillingReadings::selectRaw('SUM(filling_volumn) as total_sum')
            ->where('shift_report_id', $shiftId)
            ->where('petrol_typeid', $petrolTypeId)
            ->groupBy('petrol_typeid')
            ->first();

        if (isset($findCurrentFillingData) && $findCurrentFillingData->total_sum > 0) {
            return $findCurrentFillingData->total_sum;
        } else {
            return $findCurrentFillingData = 0;
        }

        // return $findCurrentFillingData->total_sum > 0 ? $findCurrentFillingData->total_sum : "0";
    }
}

if (!function_exists('paymentMethod')) {
    function paymentMethod()
    {
        $paymentMethod = array('0' => 'Cash', '1' => 'Bank Card - TurkmenBank', '2' => 'Bank Card - HalkBank');
        return $paymentMethod;
    }
}

if (!function_exists('paymentVoucher')) {
    function paymentVoucher()
    {
        $paymentVoucher = array('0' => 'State Voucher', '1' => 'Commercial Voucher');
        return $paymentVoucher;
    }
}

if (!function_exists('shiftPaymentMethod')) {
    function shiftPaymentMethod()
    {
        $shiftPaymentMethod = array('Cash' => 'Cash', 'Bank Card - TurkmenBank' => 'Bank Card - TurkmenBank', 'Bank Card - HalkBank' => 'Bank Card - HalkBank');
        return $shiftPaymentMethod;
    }
}

if (!function_exists('petrolPrice')) {
    function petrolPrice($petrolTypeId = null)
    {
        $currentDate = Carbon::now()->toDateString();
        $petrolPrice = PetrolPrice::select()
            ->where('petrol_type_id', $petrolTypeId)
            ->whereDate('start_date_time', '<=', $currentDate)
            ->whereDate('end_date_time', '>=', $currentDate)
            ->where('status', 'Y')
            ->orderBy('id', 'DESC')
            ->first();

        return $petrolPrice;
    }
}

if (!function_exists('findTotalSoldLiterPerPetrolType')) {
    function findTotalSoldLiterPerPetrolType($petrolTypeId = null, $shiftReportId = null)
    {
    $findTotalSoldLiterPerPetrolType = ShiftPumpReadings::selectRaw('SUM(total_sales) as total_sum')
    ->where('shift_report_id', $shiftReportId)
    ->where('petrol_typeid', $petrolTypeId)
    ->groupBy('petrol_typeid')
    ->first();
        // return $findTotalSoldLiterPerPetrolType;


        if (isset($findTotalSoldLiterPerPetrolType) && $findTotalSoldLiterPerPetrolType->total_sum > 0) {
            return $findTotalSoldLiterPerPetrolType->total_sum;
        } else {
            return $findTotalSoldLiterPerPetrolType = 0;
        }

    }
}

if (!function_exists('findAlreadyAddedTotalSoldLiterPerPetrolType')) {
    function findAlreadyAddedTotalSoldLiterPerPetrolType($petrolTypeId = null, $shiftReportId = null)
    {
        $findAlreadyAddedTotalSoldLiterPerPetrolType = ShiftPetrolSales::selectRaw('SUM(total_sold) as total_sum')
            ->where('shift_report_id', $shiftReportId)
            ->where('petrol_typeid', $petrolTypeId)
            ->groupBy('petrol_typeid')
            ->first();

        if (isset($findAlreadyAddedTotalSoldLiterPerPetrolType) && $findAlreadyAddedTotalSoldLiterPerPetrolType->total_sum > 0) {
            return $findAlreadyAddedTotalSoldLiterPerPetrolType->total_sum;
        } else {
            return $findAlreadyAddedTotalSoldLiterPerPetrolType = 0;
        }

    }
}
if (!function_exists('findReservoirPetrolType')) {
    function findReservoirPetrolType($userId = null)
    {
        $findReservoirPetrolType = '';

        if ($userId > 0) {
            $findData = Reservoirs::where('user_id', $userId)
                ->where('status', 1)
                ->selectRaw('GROUP_CONCAT(DISTINCT petrol_type_id) as petrol_type_ids')
                ->first();
            $findReservoirPetrolType = $findData->petrol_type_ids != "" ? $findData->petrol_type_ids : "";
        }
        return $findReservoirPetrolType;
    }
}

if (!function_exists('find_admin_name')) {
    function find_admin_name($userId = null)
    {
        $findAdminName = '';
        if ($userId > 0) {

            $user = User::join('employees', 'users.id', '=', 'employees.user_id')
                ->where('users.status', 'Y')
                ->where('users.id', $userId)
                ->first();

            if ($user) {
                $findAdminName = ($user->name ?: ($user->organization_name ?: ""));
            }
        }
        return $findAdminName;
    }
}

if (!function_exists('findTankReadingData')) {
    function findTankReadingData($petrolTypeid = null, $shiftReportId = null)
    {
        $findTankReadingData = ShiftTankReadings::where('petrol_typeid', $petrolTypeid)->where('shift_report_id', $shiftReportId)->get();
        return $findTankReadingData;
    }
}

if (!function_exists('findPumpTotalSoldData')) {
    function findPumpTotalSoldData($petrolTypeId = null, $shiftId = null)
    {
        $findPumpTotalSoldData = ShiftPetrolSales::selectRaw(('SUM(total_sold) as total_sum'))
            ->where('shift_petrol_sales.shift_report_id', $shiftId)
            ->where('shift_petrol_sales.petrol_typeid', $petrolTypeId)
            ->first();

        return $findPumpTotalSoldData;

    }
}
if (!function_exists('findBottledOilTotalSoldData')) {
    function findBottledOilTotalSoldData($shiftId = null, $bottledOilTypeId = null)
    {

        $findBottledOilTotalSoldData = ShiftBottledOilSales::select(
            'bottled_oil_type_id',
            DB::raw('SUM(service_charge) as total_sum_service_charge'),
            DB::raw('SUM(amount_received) as total_sum_amount_received'),
            DB::raw('SUM(calculated_quantity) as total_sum_calculated_quantity'),
            'each_bottle_price'
        )
            ->where('shift_report_id', $shiftId)
            ->where('bottled_oil_type_id', $bottledOilTypeId)
            ->groupBy('bottled_oil_type_id', 'each_bottle_price')
            ->first();

        return $findBottledOilTotalSoldData;
    }
}

if (!function_exists('findPetrolSalesPaymentMethod')) {
    function findPetrolSalesPaymentMethod($shiftId = null, $bottledOilTypeId = null)
    {
        $findPetrolSalesPaymentMethod = ShiftPetrolSales::select('payment_method')
        ->where('shift_report_id', $shiftId)
            ->whereNotNull('payment_method')
            ->groupBy('payment_method')
            ->orderByRaw('MIN(id) ASC')
            ->get();

        return $findPetrolSalesPaymentMethod;
    }
}

if(!function_exists('findPumpTotalPaymentMethodSoldData')){
    function findPumpTotalPaymentMethodSoldData ($shiftReportId = null, $petrolTypeid = null, $paymentMethod = null){

        $findPumpTotalPaymentMethodSoldData = ShiftPetrolSales::select(
            'petrol_typeid',
            'price_per_liter',
            DB::raw('SUM(amount_received) as total_sum_amount'),
            DB::raw('SUM(total_petrol_sold_payment) as total_sum_liter')
        )
        ->where('shift_report_id', $shiftReportId)
        ->where('petrol_typeid', $petrolTypeid)
        ->where('payment_method', $paymentMethod)
        ->groupBy('petrol_typeid', 'price_per_liter')
        ->first();
        return $findPumpTotalPaymentMethodSoldData;
    }
}

if (!function_exists('findStateVoucherQty')) {
    function findStateVoucherQty($shiftReportId = null, $petrolTypeid = null, $voucherVolumn = null)
    {
        $findStateVoucherQty = ShiftPetrolSales::select(
            DB::raw('SUM(voucher_quantity) as total_sum_qry'),
            'petrol_typeid'
        )
        ->where('shift_report_id', $shiftReportId)
        ->where('petrol_typeid', $petrolTypeid)
        ->where('voucher_volumn', $voucherVolumn)
        ->where('state_voucher', 1)
        ->groupBy('petrol_typeid')
        ->first();
        return $findStateVoucherQty;


    }
}
if (!function_exists('findCommercialVoucherQty')) {
    function findCommercialVoucherQty($shiftReportId = null, $petrolTypeid = null, $voucherVolumn = null)
    {
        $findCommercialVoucherQty = ShiftPetrolSales::select(
            'petrol_typeid',
            DB::raw('SUM(voucher_quantity) as total_sum_qry')
        )
        ->where('shift_report_id', $shiftReportId)
        ->where('petrol_typeid', $petrolTypeid)
        ->where('voucher_volumn', $voucherVolumn)
        ->where('commercial_voucher', 1)
        ->groupBy('petrol_typeid')
        ->first();

        return $findCommercialVoucherQty;

    }
}
if (!function_exists('findAllPumpData')) {
    function findAllPumpData($shiftReportId = null, $petrolTypeId = null)
    {
        $findAllPumpData = ShiftPumpReadings::where('shift_report_id', $shiftReportId)->where('petrol_typeid', $petrolTypeId)->get();
        return $findAllPumpData;
    }
}

if (!function_exists('findAllTotalSalesAmountData')) {
    function findAllTotalSalesAmountData($shift_report_id = null)
    {

        $findAllTotalSalesAmountData = ShiftPetrolSales::where('shift_report_id', $shift_report_id)->get();
        $totalAmount = 0;

        foreach ($findAllTotalSalesAmountData as $pval) {
            $each_amount = number_format(($pval->total_sold * $pval->price_per_liter), 2, ".", "");
            $totalAmount += $each_amount;
        }
        $findAllBottledOilSalesAmountData = ShiftBottledOilSales::select(
            DB::raw('SUM(service_charge) as total_sum_service_charge'),
            DB::raw('SUM(amount_received) as total_sum_amount_received')
        )
            ->where('shift_report_id', $shift_report_id)
            ->first();
        if ($findAllBottledOilSalesAmountData) {
            $totalAmount += $findAllBottledOilSalesAmountData->total_sum_service_charge + $findAllBottledOilSalesAmountData->total_sum_amount_received;
        }

        return $totalAmount;
    }
}


if (!function_exists('getShiftDetails')) {
    function getShiftDetails($shiftId = null)
    {
        $findData = array();

        if ($shiftId > 0) {
            $findData = Shifts::where('id', $shiftId)->first();
        }
        return $findData;
    }
}

function find_total_each_day_sale($shift_date = null, $admin_id = null, $petrol_typeid = null, $type = null)
{

    $findTotalEachDaySale = [
        'liter' => 0,
        'amount' => 0,
    ];

    if ($shift_date && $admin_id && $petrol_typeid && $type) {
        $shiftPetrolSales = DB::table('shift_petrol_sales')
            ->join('shift_report', 'shift_petrol_sales.shift_report_id', '=', 'shift_report.id')
            ->selectRaw('SUM(shift_petrol_sales.amount_received) as total_amount, SUM(shift_petrol_sales.total_sold) as total_liter')
            ->where('shift_petrol_sales.petrol_typeid', $petrol_typeid)
            ->where('shift_report.user_id', $admin_id)
            ->where('shift_report.shift_date', $shift_date)
            ->whereIn('shift_report.status', ['A', 'C'])->get();

//     ->join('shift_report', 'shift_petrol_sales.shift_report_id', '=', 'shift_report.id')
//     ->selectRaw('SUM(shift_petrol_sales.amount_received) as total_amount, SUM(shift_petrol_sales.total_sold) as total_liter')
//     ->where('shift_petrol_sales.petrol_typeid', $petrol_typeid)
//     ->where('shift_report.user_id', $admin_id)
//     ->where('shift_report.shift_date', $shift_date)
//     ->whereIn('shift_report.status', ['A', 'C']);

// $sql = $query->toSql(); // This will return the SQL query as a string

// $result = $query->get();

        if ($type === "Bank") {
            $shiftPetrolSales->where(function ($query) use ($admin_id) {
                $query = DB::table('shift_petrol_sales');
                $query->where('shift_petrol_sales.payment_method', 'LIKE', '%Bank%')
                    ->orWhereIn('shift_petrol_sales.bank_id', function ($query) use ($admin_id) {
                        $query->select(DB::raw('DISTINCT(bank_id)'))
                            ->from('payment_terminals')
                            ->where('user_id', $admin_id);
                    });
            });

        } else {
            $shiftPetrolSales->where('shift_petrol_sales.payment_method', 'Cash');
        }

        $findTotalEachDayCashSaleData = $shiftPetrolSales->first();

        if ($findTotalEachDayCashSaleData) {
            $findTotalEachDaySale = [
                'liter' => $findTotalEachDayCashSaleData->total_liter,
                'amount' => $findTotalEachDayCashSaleData->total_amount,
            ];
        }
    }

    return $findTotalEachDaySale;
}

function find_each_bank_bag_number($startDate, $adminId)
{

    $bankBagNumber = '';

    if ($startDate && $adminId) {
        $shiftReports = DB::table('shift_report')
            ->select('bank_bag_number')
            ->where('shift_date', $startDate)
            ->where('user_id', $adminId)
            ->whereIn('status', ['A', 'C'])
            ->get();

        $bankBagNumbers = $shiftReports->pluck('bank_bag_number')->filter();

        if (!$bankBagNumbers->isEmpty()) {
            $bankBagNumber = implode(" / ", $bankBagNumbers->all());
        }
    }

    return $bankBagNumber;
}

function find_total_period_day_sale($startDate = null, $endDate = null, $adminId = null, $petrolTypeId = null, $type = null)
{
    $findTotalPeriodDaySale = [
        'liter' => 0,
        'amount' => 0,
    ];

    if ($startDate && $endDate && $adminId && $petrolTypeId && $type) {
        $shiftPetrolSales = DB::table('shift_petrol_sales')
            ->join('shift_report', 'shift_petrol_sales.shift_report_id', '=', 'shift_report.id')
            ->selectRaw('SUM(shift_petrol_sales.amount_received) as total_amount, SUM(shift_petrol_sales.total_sold) as total_liter')
            ->where('shift_petrol_sales.petrol_typeid', $petrolTypeId)
            ->where('shift_report.user_id', $adminId)
            ->whereBetween('shift_report.shift_date', [$startDate, $endDate])
            ->whereIn('shift_report.status', ['A', 'C']);

        if ($type === "Bank") {
            $shiftPetrolSales->where(function ($query) use ($adminId) {
                $query->where('shift_petrol_sales.payment_method', 'LIKE', '%Bank%')
                    ->orWhereIn('shift_petrol_sales.bank_id', function ($query) use ($adminId) {
                        $query->select(DB::raw('DISTINCT(bank_id)'))
                            ->from('payment_terminals')
                            ->where('user_id', $adminId);
                    });
            });
        } else {
            $shiftPetrolSales->where('shift_petrol_sales.payment_method', 'Cash');
        }

        $findTotalPeriodDaySaleData = $shiftPetrolSales->first();

        if ($findTotalPeriodDaySaleData) {
            $findTotalPeriodDaySale = [
                'liter' => $findTotalPeriodDaySaleData->total_liter,
                'amount' => $findTotalPeriodDaySaleData->total_amount,
            ];
        }
    }

    return $findTotalPeriodDaySale;
}


function find_pump_total_sold_data($shift_report_id = null, $petrol_typeid = null){ 
    
    $find_pump_total_sold_data = ShiftPetrolSales::where('shift_petrol_sales.shift_report_id',$shift_report_id)
                                    ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                                    ->selectRaw('SUM(shift_petrol_sales.total_sold) as total_sum')
                                    ->first();

    return $find_pump_total_sold_data;
}


function find_reservoir_data($reservoirs_id = null){ 
    
    $find_reservoir_data = Reservoirs::where('Reservoirs.id', $reservoirs_id)
                           ->where('Reservoirs.status', 1)
                           ->select(['id', 'capacity_liter', 'status'])
                           ->first();
    return $find_reservoir_data;
}

function find_pump_total_payment_method_sold_data($shift_report_id = null, $petrol_typeid = null, $payment_method = null){ 

    $find_pump_total_payment_method_sold_data = ShiftPetrolSales::where('shift_petrol_sales.shift_report_id',$shift_report_id)
                                    ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                                    ->where('shift_petrol_sales.payment_method',$payment_method)
                                    ->select(DB::raw('SUM(shift_petrol_sales.amount_received) as total_sum_amount'),DB::raw('SUM(shift_petrol_sales.total_petrol_sold_payment) as total_sum_liter'))
                                    ->first();
    
    return $find_pump_total_payment_method_sold_data;
}

function find_pump_total_vaucher_sold_data($shift_report_id = null, $petrol_typeid = null, $payment_method = null){ 
    

    $find_pump_total_vaucher_sold_data = ShiftPetrolSales::where('shift_petrol_sales.shift_report_id',$shift_report_id)
                                                ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                                                ->where('shift_petrol_sales.voucher_type',$payment_method)
                                                ->select(DB::raw('SUM(shift_petrol_sales.total_sold) as total_sum_liter'))
                                                ->first();
    return $find_pump_total_vaucher_sold_data;
}

function price_format($price=0){
   $generalsettings = GeneralSettings::first();
   $price_format=$price.' '.$generalsettings->currency;
   return $price_format;
}

function find_total_sold_payment_method_data($petrol_typeid = null){ 

    $find_total_sold_payment_method_data = ShiftPetrolSales::where('shift_petrol_sales.payment_method','!=','')
                                            ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                                            ->select(DB::raw('SUM(shift_petrol_sales.amount_received) as total,shift_petrol_sales.payment_method,shift_petrol_sales.petrol_typeid'))
                                            ->groupBy('shift_petrol_sales.payment_method')
                                            ->get()->toArray();
    return $find_total_sold_payment_method_data;
}

function find_total_sold_payment_vaucher_data($petrol_typeid = null){ 

    $find_total_sold_payment_vaucher_data = ShiftPetrolSales::where('shift_petrol_sales.voucher_type','!=','')
                                            ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                                            ->select(DB::raw('SUM(shift_petrol_sales.amount_received) as total,shift_petrol_sales.voucher_type,shift_petrol_sales.petrol_typeid'))
                                            ->groupBy('shift_petrol_sales.voucher_type')
                                            ->get()->toArray();
    return $find_total_sold_payment_vaucher_data;
}

function find_total_sold_payment_method_previous_month_data($petrol_typeid = null){ 
    $currentMonth = date('F');
    $month=Date('F', strtotime($currentMonth . " last month"));
    $nmonth = date("m", strtotime($month));
    $find_total_sold_payment_method_data = ShiftPetrolSales::where('shift_petrol_sales.payment_method','!=','')
                                           ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                                           ->whereMonth('shift_petrol_sales.creation_date', '=', $nmonth)
                                           ->select(DB::raw('SUM(shift_petrol_sales.amount_received) as total,shift_petrol_sales.payment_method,shift_petrol_sales.petrol_typeid'))
                                           ->groupBy('shift_petrol_sales.payment_method')
                                           ->get()->toArray();
    return $find_total_sold_payment_method_data;
}

function find_all_payment_method(){ 

    $find_all_payment_method = ShiftPetrolSales::where('shift_petrol_sales.payment_method','!=','')
                                ->select('shift_petrol_sales.payment_method','shift_petrol_sales.petrol_typeid')
                                ->groupBy('shift_petrol_sales.payment_method')
                                ->get()->toArray();
    return $find_all_payment_method;
}

function find_shift_previous_month_data(){ 
    $currentMonth = date('F');
    $month=Date('F', strtotime($currentMonth . " last month"));
    $nmonth = date("m", strtotime($month));
    
    $find_shift_previous_month_data = ShiftReport::whereMonth('shift_report.shift_date', '=', $nmonth)->select('shift_report.id','shift_report.shift_start_at_midnight','shift_report.shift_end_at_midnight','shift_report.shift_name','shift_report.shift_name_en','shift_report.shift_name_ru','shift_report.shift_name_tu','shift_report.shift_date','shift_report.shift_start_date_time','shift_report.shift_end_date_time','shift_report.status')->get()->toArray();
    return $find_shift_previous_month_data;
}

function default_date_format($date_from_db){
    if($date_from_db !="")
        {

            return date("d/m/Y", strtotime($date_from_db));
        }
}

function find_total_sold_payment_method_total_data($petrol_typeid, $shift_id, $payment_method){ 

    $find_total_sold_payment_method_total_data = ShiftPetrolSales::where('shift_petrol_sales.payment_method','!=','')
                                                 ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                                                 ->where('shift_petrol_sales.shift_report_id',$shift_id)
                                                 ->select(DB::raw('SUM(shift_petrol_sales.total_sold) as total,shift_petrol_sales.payment_method'))
                                                 ->groupBy('shift_petrol_sales.payment_method')
                                                 ->first();
    //dd($find_total_sold_payment_method_total_data);
    return $find_total_sold_payment_method_total_data;
}

function find_all_voucher_type(){ 
    
    $find_all_voucher_type = ShiftPetrolSales::where('shift_petrol_sales.voucher_type','!=','')
                             ->groupBy('shift_petrol_sales.voucher_type')  
                             ->select('shift_petrol_sales.voucher_type')  
                             ->get()->toArray();

    return $find_all_voucher_type;
}

function find_total_sold_voucher_type_total_data($petrol_typeid = null, $shift_id = null, $voucher_type = null){ 

    $find_total_sold_voucher_type_total_data = ShiftPetrolSales::where('shift_petrol_sales.voucher_type',$voucher_type)
                             ->where('shift_petrol_sales.petrol_typeid',$petrol_typeid)
                             ->where('shift_petrol_sales.shift_report_id',$shift_id)
                             ->select(DB::raw('SUM(shift_petrol_sales.total_sold) as total,shift_petrol_sales.voucher_type'))
                             ->groupBy('shift_petrol_sales.voucher_type')
                             ->first();
    //dd($find_total_sold_voucher_type_total_data);
    return $find_total_sold_voucher_type_total_data;
}

function find_shift_current_month_data(){ 
    $nmonth = date('m');
    $find_shift_current_month_data =  ShiftReport::whereMonth('shift_report.shift_date', '=', $nmonth)->select('shift_report.id','shift_report.shift_start_at_midnight','shift_report.shift_end_at_midnight','shift_report.shift_name','shift_report.shift_name_en','shift_report.shift_name_ru','shift_report.shift_name_tu','shift_report.shift_date','shift_report.shift_start_date_time','shift_report.shift_end_date_time','shift_report.status')->get()->toArray();
    return $find_shift_current_month_data;
}

