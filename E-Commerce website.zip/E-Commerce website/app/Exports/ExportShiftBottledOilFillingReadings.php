<?php

namespace App\Exports;

use App\Models\ShiftBottledOilFillingReadings;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;


class ExportShiftBottledOilFillingReadings implements FromCollection, WithHeadings, WithMapping, ShouldAutoSize
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
    	$data =  DB::table('shift_bottled_oil_filling_readings')
                        ->join('shift_report', 'shift_report.id', '=', 'shift_bottled_oil_filling_readings.shift_report_id')
                        ->join('bottled_oil_types', 'bottled_oil_types.id', '=', 'shift_bottled_oil_filling_readings.bottled_oil_type_id')
                        ->get();
        return $data;
    }

    public function headings(): array
    {
        return [
            'Shift Details',
            'Distribution Center',
            'Bottled Oil Type',
            'Delivery Document No',
            'Date On The Delivery Document',
            'Delivery Date',
            'Vehicle Plate Number',
            'Volume in Liters',
            'Quantity'
        ];
    }

    public function map($shiftbottledoil): array
    {
        return [
            $shiftbottledoil->shiftid.' '.$shiftbottledoil->shift_name.' '.Carbon::createFromFormat('Y-m-d', $shiftbottledoil->shift_date)->format('d/m/Y'),
            $shiftbottledoil->rdc_organization_name,
            $shiftbottledoil->bottled_oil_en,
            $shiftbottledoil->filling_doc_number,
            $shiftbottledoil->filling_delivery_doc_date,
            $shiftbottledoil->filling_delivery_date,
            $shiftbottledoil->filling_vehicle_plate_number,
            $shiftbottledoil->bottled_oil_volumn,
            $shiftbottledoil->filling_quantity
        ];
    }
}
