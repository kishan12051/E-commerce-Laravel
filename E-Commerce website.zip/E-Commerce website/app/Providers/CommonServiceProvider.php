<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\GeneralSettings;
use App\Models\Language;

class CommonServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $generalSettings = GeneralSettings::first();
        $activeLanguages = Language::query()
            ->where('status', 'Y')
            ->get(); 

        // Share the data with all views
        view()->share('generalSettings', $generalSettings);
        view()->share('activeLanguages', $activeLanguages);
    }
}
