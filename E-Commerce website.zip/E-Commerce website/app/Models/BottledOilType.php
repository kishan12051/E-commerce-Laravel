<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BottledOilType extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'bottled_oil_types';
    
    protected $fillable = [
        'bottled_oil_en',
        'bottled_oil_ru',
        'bottled_oil_tu',
        'volumn',
        'price',
    ];
}
