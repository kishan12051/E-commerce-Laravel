<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\BottledOilType;
use App\Models\ShiftReport;
use Illuminate\Database\Eloquent\SoftDeletes;

class ShiftBottledOilFillingReadings extends Model
{
    use HasFactory;
    use SoftDeletes;
  
    protected $table = 'shift_bottled_oil_filling_readings';

    protected $fillable = [
        'shift_report_id',
        'user_id',
        'bottled_oil_type_id',
        'bottled_oil_type_name',
        'bottled_oil_volumn',
        'bottled_oil_price',
        'rdc_user_id',
        'rdc_employee_id',
        'rdc_organization_name',
        'rdc_organization_phone',
        'rdc_organization_address',
        'filling_doc_number',
        'filling_delivery_doc_date',
        'filling_delivery_date',
        'filling_vehicle_plate_number',
        'filling_quantity',
        'feeling_temperature',
        'filling_mass',
    ];

    public function bottledOiltype()
    {
        return $this->belongsTo(BottledOilType::class, 'bottled_oil_type_id');
    }

    public function shiftReport()
    {
        return $this->belongsTo(ShiftReport::class, 'shift_report_id');
    }
}