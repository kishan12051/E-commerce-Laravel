<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TimeZone extends Model
{
    use HasFactory;

    protected $table = 'timezone';
    protected $fillable = [
        'id',
        'country_code',
        'country_name',
        'time_zone',
        'gmt_offset'
    ];
}
