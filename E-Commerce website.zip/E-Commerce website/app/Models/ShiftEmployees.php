<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ShiftEmployees extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $fillable = [
        'shift_report_id',
        'employee_id',
        'employeeid',
        'employee_name',
        'employee_phone',
        'employee_email',
        'is_manager',
        'petrol_pump_id',
        'pumpid',
        'pump_name',
        'creation_date',
        'status',
        'created',
        'modified'
    ];
}