<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentTerminals extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $fillable = [
        'user_id',
        'employee_id',
        'terminal_name',
        'bank_id',
        'bank_name',
        'terminal_number',
        'petrol_types',
        'petrol_type_details',
        'status',
        'created_by',
        'created_at',
        'modified_by',
        'modified_at'
    ];
}
