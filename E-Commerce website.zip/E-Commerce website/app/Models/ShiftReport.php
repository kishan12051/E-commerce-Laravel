<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ShiftEmployees;
use App\Models\ShiftTankReadings;
use App\Models\ShiftBottledOilReadings;
use App\Models\ShiftPumpReadings;
use App\Models\ShiftFillingReadings;
use App\Models\ShiftBottledOilFillingReadings;
use Illuminate\Database\Eloquent\SoftDeletes;
  
class ShiftReport extends Model
{
    use HasFactory;
    use SoftDeletes;
  
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $table = 'shift_report';
    protected $fillable = [
        'user_id',
        'employee_id',
        'shiftid',
        'end_date',
        'shift_timeid',
        'shift_start_at_midnight',
        'shift_end_at_midnight',
        'shift_name',
        'shift_name_en',
        'shift_name_ru',
        'shift_name_tu',
        'shift_date',
        'shift_start_date_time',
        'shift_end_date_time',
        'assigned_pump_ids',
        'assigned_pump_data',
        'employee_group',
        'notes',
        'last_report_id',
        'assign_rac_emplyee_details',
        'status ',
        'comment',
        'is_step2_complete',
        'is_step3_complete',
        'is_step4_complete',
        'is_step5_complete',
        'is_step6_complete',
        'is_step7_complete',
        'created',
        'modified',
        'created_admin_id',
        'modified_admin_id',
        'is_active_tab',
        'unscheduled_audit',
        'previously_shift_was_audit',
        'audit_date_time',
        'bank_bag_number',
        'ShiftTankReadings',
    ];

    public function shiftEmployees()
    {
        return $this->hasMany(ShiftEmployees::class, 'shift_report_id');
    }


    public function ShiftTankReadings()
    {
        return $this->hasMany(ShiftTankReadings::class, 'shift_report_id')->select('id','shift_report_id','reservoir_id','reservoir_name', 'petrol_typeid', 'petrol_type_name', 'start_shift_height', 'start_shift_fuel', 'filling_volumn', 'end_shift_fuel');
    }

    public function shiftBottledOilReadings()
    {
        return $this->hasMany(ShiftBottledOilReadings::class);
    }

    public function shiftPumpReadings()
    {
        return $this->hasMany(ShiftPumpReadings::class);
    }

    public function shiftFillingReadings()
    {
        return $this->hasMany(ShiftFillingReadings::class);
    }

    public function shiftBottledOilFillingReadings()
    {
        return $this->hasMany(ShiftBottledOilFillingReadings::class);
    }
}