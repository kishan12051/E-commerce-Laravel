<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ShiftTankReadings extends Model
{
    use HasFactory;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $fillable = [
        'shift_report_id',
        'reservoir_id',
        'reservoir_name',
        'petrol_typeid',
        'petrol_type_name',
        'start_shift_height',
        'start_shift_fuel',
        'filling_doc_number',
        'filling_delivery_doc_date',
        'filling_vehicle_plate_number',
        'filling_volumn',
        'filling_ppd_value',
        'feeling_temperature',
        'filling_mass',
        'before_filling_height',
        'before_filling_fuel',
        'filling_newly_added',
        'present_fuel',
        'end_shift_height',
        'end_shift_fuel',
        'remark',
        'creation_date',
        'reading_type',
        'created',
        'modified',
    ];
}
