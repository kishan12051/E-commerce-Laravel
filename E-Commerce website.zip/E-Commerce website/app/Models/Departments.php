<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Departments extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'departments';
    
    protected $fillable = [
        'department_code',
         'title_en',
         'title_ru',
         'title_tu',
         'is_parent',
         'parentDepartment'
    ];
    public function parentDepartment()
    {
        return $this->belongsTo(Departments::class, 'is_parent');
    }
    
}
