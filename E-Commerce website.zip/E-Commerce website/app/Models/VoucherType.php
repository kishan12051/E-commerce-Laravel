<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VoucherType extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $table = 'voucher_type';

    protected $fillable = [
        'user_id', 
        'employee_id',
        'voucher_type_en',
        'voucher_type_ru',
        'voucher_type_tu',
        'status',
    ];
}