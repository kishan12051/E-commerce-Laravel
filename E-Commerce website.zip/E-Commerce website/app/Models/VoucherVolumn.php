<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\VoucherType;

class VoucherVolumn extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $table = 'voucher_volumn';

    protected $fillable = [
        'user_id', 
        'employee_id',
        'voucher_type',
        'volumn'
    ];

    public function VoucherType()
    {
        return $this->belongsTo(VoucherType::class, 'voucher_type');
    }
}
