<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
  
class Shifts extends Model
{
    use HasFactory;

    protected $table = 'shifts';
  
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $fillable = [
        'user_id',
        'employee_id',
        'start_date',
        'end_date',
        'shift1_title_en',
        'shift1_title_ru',
        'shift1_title_tu',
        'shift1_time',
        'shift2_title_en',
        'shift2_title_ru',
        'shift2_title_tu',
        'shift2_time',
        'shift_start_time',
        'shift_end_time',
        'status',
        'created_at',
        'updated_at',
    ];
}