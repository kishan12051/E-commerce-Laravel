<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Reservoirs;
use App\Models\PetrolType;
use Illuminate\Database\Eloquent\SoftDeletes;
  
class MainMatrixCalculations extends Model
{
    use HasFactory;
    use SoftDeletes;
  
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $table = 'main_matrix_calculations';
    protected $fillable = [
        'user_id',
        'employee_id',
        'reservoir_id',
        'petrol_type_id',
        'document_details_en',
        'document_details_ru',
        'document_details_tu',
        'reservoir_height',
        'error_rate',
        'issued_date',
        'valid_through'
    ];

    public function petrolType()
    {
        return $this->belongsTo(PetrolType::class, 'petrol_type_id');
    }

    public function reservoir()
    {
        return $this->belongsTo(Reservoirs::class, 'reservoir_id');
    }
}