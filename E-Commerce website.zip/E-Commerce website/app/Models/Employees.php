<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Employees extends Model
{
    use SoftDeletes;
    use HasFactory;
    protected $fillable = [
        'emp_id',
        'user_id',
        'organization_name',
        'organization_phone',
        'organization_address',
        'department_id',
        'designation_id',
        'working_region_id',
        'functional_role',
        'name',
        'profile_picture',
        'joining_date',
        'date_of_birth',
        'phone_number',
        'adresss',
        'assign_petrol_pump',
        'deleted_at',
    ];
    public function petrolPrice()
    {
        return $this->hasMany(PetrolPrice::class, 'created_employee_id');
    }
    public function department()
    {
        return $this->belongsTo(Departments::class, 'department_id');
    }
    
    public function designation()
    {
        return $this->belongsTo(Designations::class, 'designation_id');
    }
    
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function working_region()
    {
        return $this->belongsTo(WorkingRegion::class, 'working_region_id');
    }

}