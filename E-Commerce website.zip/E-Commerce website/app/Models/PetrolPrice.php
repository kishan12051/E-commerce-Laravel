<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\PetrolType;
use App\Models\Employees;

class PetrolPrice extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'petrol_price';
    
    protected $fillable = [
        'petrol_type_id',
        'price',
        'start_date_time',
        'end_date_time',
        'status',
        'created_admin_id',
        'created_employee_id',
        'created_date',
        'updated_admin_id',
        'updated_employee_id',
        'updated_date',
    ];
    public function petrolType()
    {
        return $this->belongsTo(PetrolType::class, 'petrol_type_id');
    }
    public function createdDateWithOrganization()
    {
        $employee = Employees::find($this->created_employee_id);

        if ($employee) {
            return $employee->organization_name . '</br>' . $this->created_date;
        } else {
            return '';
        }
    }
    public function updatedDateWithOrganization()
    {
        $employee = Employees::find($this->updated_employee_id);

        if ($employee) {
            return $employee->organization_name . '<br>' . $this->updated_date;
        } else {
            return '';
        }
    }
}
