<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WorkingRegion extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'working_regions';

    protected $fillable = [
        'region_name_en',
        'region_name_ru',
        'region_name_tu',
        'region_code',
        'status',
    ];

    public function employees()
    {
        return $this->hasMany(Employees::class, 'working_region_id');
    }
}
