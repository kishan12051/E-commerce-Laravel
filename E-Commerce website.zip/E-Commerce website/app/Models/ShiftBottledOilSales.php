<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
  
class ShiftBottledOilSales extends Model
{
    use HasFactory;
    use SoftDeletes;
  
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $fillable = [
        'shift_report_id',
        'employee_id',
        'employeeid',
        'employee_name',
        'bottled_oil_type_id',
        'bottle_type',
        'volumn',
        'amount_received',
        'each_bottle_price',
        'service_charge_included',
        'payment_method',
        'calculated_quantity',
        'service_charge',
        'remark',
        'creation_date',
        'created',
        'modified'
    ];
}