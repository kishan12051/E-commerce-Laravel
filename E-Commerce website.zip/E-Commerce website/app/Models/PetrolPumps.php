<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\PetrolType;
use App\Models\Reservoirs;
class PetrolPumps extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'petrol_pumps';
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $fillable = [
        'user_id', 
        'employee_id',
        'reservoir_id',
        'petrol_type_id',
        'pumpid',
        'pump_name_en',
        'pump_name_ru',
        'pump_name_tu',
        'status',
    ];

    public function petrolType()
    {
        return $this->belongsTo(PetrolType::class, 'petrol_type_id');
    }

    public function reservoirs()
    {
        return $this->belongsTo(Reservoirs::class, 'reservoir_id');
    }
}