<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GeneralSettings extends Model
{
    use HasFactory;
    protected $table = 'general_settings';
    
    protected $fillable = [
        'website_title',
        'address',
        'email',
        'phone_no',
        'favicon_icon',
        'website_logo',
        'language',
        'time_zone',
        'currency',
        'footer_text',
        'login_page_title'
    ];
}
