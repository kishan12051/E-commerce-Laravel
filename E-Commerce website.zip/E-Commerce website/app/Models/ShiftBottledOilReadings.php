<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ShiftBottledOilReadings extends Model
{
    use HasFactory;
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $fillable = [
        'shift_report_id',
        'bottled_oil_type_id',
        'bottled_oil_title',
        'bottled_oil_volumn',
        'start_shift_quantity',
        'end_shift_quantity',
        'filling_quantity',
        'present_quantity',
        'remark',
        'creation_date',
        'created',
        'modified'
    ];
}