<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PetrolType extends Model
{
    use HasFactory;

    protected $table = 'petrol_types';

    protected $fillable = [
        'type_code',
        'petrol_type_en',
        'petrol_type_ru',
        'petrol_type_tu',
        'status',
    ];

    // public function mainMatrixCalculations()
    // {
    //     return $this->hasMany(MainMatrixCalculations::class, 'petrol_type_id', 'id');
    // }
}
