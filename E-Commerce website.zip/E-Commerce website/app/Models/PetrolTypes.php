<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PetrolTypes extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'petrol_types';

    protected $fillable = [
        'type_code',
        'petrol_type_en',
        'petrol_type_ru',
        'petrol_type_tu',
        'status'
    ];
}
