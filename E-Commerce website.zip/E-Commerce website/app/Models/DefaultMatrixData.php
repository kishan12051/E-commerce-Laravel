<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DefaultMatrixData extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'default_matrix_records';
    
    protected $fillable = [
        'user_id',
        'employee_id',
        'matrix_name_tu',
        'matrix_template_id',
        'height',
        'volumn_liter',
        'volumn_ml'
    ];
}
