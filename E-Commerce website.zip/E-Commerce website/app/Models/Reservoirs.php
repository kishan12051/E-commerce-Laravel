<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\PetrolType;
use App\Models\MatrixTemplates;
use Illuminate\Database\Eloquent\SoftDeletes;

class Reservoirs extends Model
{
    use HasFactory;
    use SoftDeletes;
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $table = 'reservoirs';
    protected $fillable = [
        'user_id',
        'employee_id',
        'matrix_template_id',
        'reservoir_type_en',
        'reservoir_type_ru',
        'reservoir_type_tu',
        'petrol_type_id',
        'capacity_kg',
        'capacity_liter',
        'status'
    ];

    public function petrolType()
    {
        return $this->belongsTo(PetrolType::class, 'petrol_type_id');
    }
    public function matrixTemplates()
    {
        return $this->belongsTo(MatrixTemplates::class, 'matrix_template_id');
    }
}