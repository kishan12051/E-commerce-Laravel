<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class MatrixTemplates extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'matrix_templates';
    protected $fillable = [
        'admin_id',
        'employee_id',
        'template_name_en',
        'template_name_ru',
        'template_name_tu',
        'created_at',
        'updated_at'
    ];
}
