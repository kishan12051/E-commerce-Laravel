<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ShiftPumpReadings extends Model
{
    use HasFactory;
    use SoftDeletes;
  
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $fillable = [
        'shift_report_id',
        'reservoir_id',
        'petrol_pump_id',
        'pumpid',
        'pump_name',
        'petrol_typeid',
        'petrol_type_name',
        'employee_id',
        'employeeid',
        'employee_name',
        'start_reading',
        'end_reading',
        'total_sales',
        'remark',
        'creation_date'
    ];
}