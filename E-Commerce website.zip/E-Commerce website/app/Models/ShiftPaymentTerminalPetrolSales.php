<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ShiftPaymentTerminalPetrolSales extends Model
{
    use HasFactory;
    use SoftDeletes;
    
    protected $fillable = [
        'shift_report_id',
        'shift_petrol_sale_id',
        'user_id',
        'employee_id',
        'petrol_typeid',
        'petrol_type_name',
        'price_per_liter',
        'amount_received',
        'payment_terminal_id',
        'payment_terminal_name',
        'payment_terminal_number',
        'bank_id',
        'bank_name',
        'total_petrol_sold_payment',
        'total_sold',
        'sales_date',
        'creation_date',
        'created',
        'modified'
    ];
}