<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Admins extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'admins';
    
    protected $fillable = [
        'type',
        'sub_emp_id',
        'id_parent_organisation',
        'username',
        'email',
        'password',
        'default_language',
        'status'
    ];

    public function employees()
    {
        return $this->hasMany(Employees::class, 'user_id');
    }
}
