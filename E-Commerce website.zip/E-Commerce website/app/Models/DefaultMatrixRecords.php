<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DefaultMatrixRecords extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'default_matrix_records';
    protected $_accessible = [
        'admin_id', 
        'employee_id',
        'matrix_template_id',
        'height',
        'volumn_liter',
        'volumn_ml',
        'deleted_at'
    ];
}