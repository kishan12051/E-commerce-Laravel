<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ShiftReport;
use App\Models\PetrolType;
use Illuminate\Database\Eloquent\SoftDeletes;

  
class ShiftFillingReadings extends Model
{
    use HasFactory;
    use SoftDeletes;
  
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
	protected $table = 'shift_filling_readings';
    protected $fillable = [
		'shift_report_id',
		'user_id',
		'petrol_typeid',
		'petrol_type_name',
		'rdc_user_id',
		'rdc_employee_id',
		'rdc_organization_name',
		'rdc_organization_phone',
		'rdc_organization_address',
		'filling_doc_number',
		'filling_delivery_doc_date',
		'filling_delivery_date',
		'filling_vehicle_plate_number',
		'filling_volumn',
		'filling_ppd_value',
		'feeling_temperature',
		'filling_mass',
		'filled_in_reservoir',
		'filled_in_reservoir_name',
		'created',
		'modified',
		'deleted_at',
    ];
	public function shiftReport()
    {
        return $this->belongsTo(ShiftReport::class, 'shift_report_id');
    }
	public function petrolType()
    {
        return $this->belongsTo(PetrolType::class, 'petrol_type_name');
    }
}




