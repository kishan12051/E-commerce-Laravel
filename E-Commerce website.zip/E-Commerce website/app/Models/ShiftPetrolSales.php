<?php
  
namespace App\Models;
  
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
  
class ShiftPetrolSales extends Model
{
    use HasFactory;
  
    /**
     * The attributes that are mass assignable.
     *	
     * @var array
     */
    protected $fillable = [
        'shift_report_id',
        'petrol_pump_id',
        'pumpid',
        'pump_name',
        'petrol_typeid',
        'petrol_type_name',
        'employee_id',
        'employeeid',
        'employee_name',
        'price_per_liter',
        'amount_received',
        'bank_id',
        'payment_method',
        'voucher_type',
        'voucher_volumn',
        'voucher_quantity',
        'state_voucher',
        'commercial_voucher',
        'total_petrol_sold_voucher',
        'total_petrol_sold_payment',
        'total_sold',
        'sales_date',
        'remarks',
        'creation_date',
        'created',
        'modified'
    ];

    public function shiftReport()
    {
        return $this->belongsTo(ShiftReport::class, 'shift_report_id');
    }
}