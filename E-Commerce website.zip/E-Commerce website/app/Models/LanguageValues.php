<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LanguageValues extends Model
{
    use HasFactory;
    use SoftDeletes;
    protected $table = 'language_values';
    
    protected $fillable = [
        'lang_key',
        'lang_values',
        'created_at',
    ];
}
