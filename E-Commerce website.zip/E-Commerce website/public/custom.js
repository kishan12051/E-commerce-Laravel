$(document).ready(function() {
  var $table = $(this);
  // Find the index of the "Action" column based on the column header text
  var actionColumnIndex = -1;
  $table.find('thead th').each(function(index) {
    if ($(this).text() === 'Action') {
      actionColumnIndex = index;
      return false; // Exit the loop when the "Action" column is found
    }
  });

//   $("#reservoir-select").change(function(){
//     var selectedReservoirId = $(this).val();
//     console.log(selectedReservoirId);
//     $.ajax({
//         url: '{{ route("changereservoirs") }}',
//         type: 'POST',
//         dataType: 'json',
//         data: {
//             contryid:selectedReservoirId,
//         },
//         success: function(data){
//             console.log(data);
//         }
//     });
//   });




  $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": true,
      "autoWidth": false,
      "ordering":  true,
      "dom": "<'row'<'col-sm-12 col-md-4'l><'col-sm-12 col-md-4 text-center'B><'col-sm-12 col-md-4'f>>" +
      "<'row'<'col-sm-12'tr>>" +
      "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
      "columnDefs": [
        { "targets": [actionColumnIndex], "orderable": false }  // Disable sorting for the "Action" column
     ],
      "buttons": [
        {
          extend: 'copy',
          text: 'Copy',
          exportOptions: {
            columns: ':visible:not(.exclude-column)'
          }
        },
        {
          extend: 'csv',
          text: 'CSV',
          exportOptions: {
            columns: ':visible:not(.exclude-column)'
          }
        },
        {
          extend: 'excel',
          text: 'Excel',
          exportOptions: {
            columns: ':visible:not(.exclude-column)'
          },
          customize: function (xlsx) {
            var sheet = xlsx.xl.worksheets['sheet1.xml'];

            $('col', sheet).each(function () {
                $(this).attr('width', 40);
            });
            }
        },
        {
          extend: 'pdf',
          text: 'PDF',
          exportOptions: {
            columns: ':visible:not(.exclude-column)',
            customize: function (doc) {
              doc.content[1].table.body.forEach(function(row) {
                row.forEach(function(cell) {
                  cell.alignment = 'center';
                });
              });
            }
          }
        },
        {
          extend: 'print',
          text: 'Print',
          exportOptions: {
            columns: ':visible:not(.exclude-column)'
          }
        }
      ]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');


		$('#example2').DataTable({
			"paging": true,
			"lengthChange": false,
			"searching": false,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
		});
	});
    $(document).on("click", ".update-status", function (event) {
		var recordId = $(this).data('id');
		var recordModule = $(this).data('status-module');
		var clickedButton = $(this);
		var token = $("meta[name='csrf-token']").attr("content");

		if (recordId > 0) {
			$.ajax({
				type: 'POST',
				url: recordModule + '/change-' + recordModule + '-status',
				data: {
					_token: token,
					id: recordId
				},
				success: function (response) {
					console.log('Response:', response); // Check the response in the browser console
					if (response.success) {
						console.log('New Status:', response.newStatus); // Check the newStatus value
						if (response.newStatus === 'Active') {
							clickedButton.text('Active');
							clickedButton.removeClass('btn-danger').addClass('btn-success');
						} else {
							clickedButton.text('Inactive');
							clickedButton.removeClass('btn-success').addClass('btn-danger');
						}

                        toastr.success(response.message);
					}
				},
				error: function (response) {
					console.error('Error:', response);
				}
			});
			// alert("data not found");
		}
	});



       $(document).on("click", ".deletedata", function (event) {
        event.preventDefault();
        let deleterecordId = $(this).data('id');
        let deleterecordModule = $(this).data('module');
        let deleteUrl = $(this).data('url');
        let finalUrl = "";
        var allData= "";

        swal.fire({
            title: `Are you sure you want to delete this record?`,
            text: "If you delete this, it will be gone forever.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!",
        }).then((result) => {
            if (result.isConfirmed) {
                let token = $("meta[name='csrf-token']").attr("content");
                if ((deleterecordId, deleterecordModule)) {
                    if (deleterecordModule == "employees") {
                        finalUrl = deleterecordModule + "/delete/" + deleterecordId;
                    } else if (deleterecordModule == "delete-rac") {
                        finalUrl = deleterecordModule + "/" + deleterecordId;
                    } else if (deleterecordModule == "delete-ps") {
                        finalUrl = deleterecordModule + "/" + deleterecordId;
                    } else if (deleterecordModule == "delete-rdc") {
                        finalUrl = deleterecordModule + "/" + deleterecordId;
                    } else if (deleterecordModule == "shifts") {
                        finalUrl = deleterecordModule + "/" + deleterecordId;
                    } else if (deleterecordModule == "default-matrix-records") {
                        finalUrl = deleteUrl;
                    } else if (deleterecordModule == "payment-terminals"){
                        finalUrl = 'delete-record/'+deleterecordId;
                    }else {
                        finalUrl = deleterecordModule + "/destroy";
                    }
                    dataArray = '';
                    $.ajax({
                        url: finalUrl,
                        type: 'DELETE',
                        dataType: 'JSON',
                        data: {
                            status: deleterecordId,
                            _token: token,
                        },
                        success: function (data) {
                          if (data.error) {
                            toastr.error(data.error);
                          } else {
                            toastr.success(data.message);
                          }
                            console.log(data);
                            var table = $('#example1').DataTable();
                            table.clear();
                            if (deleterecordModule !== "shifts" && deleterecordModule !== "manage-reservoirs" && deleterecordModule !== "matrix-calculation" && deleterecordModule !== "payment-terminals") {
                                var recordNumber = 1;
                            }
                            for (var i = 0; i < data.data.length; i++) {
                                var allDataRow = data.data[i];
                                var rowData = [];
                                if (deleterecordModule !== "shifts" && deleterecordModule !== "manage-reservoirs" && deleterecordModule !== "matrix-calculation" && deleterecordModule !== "payment-terminals") {
                                    rowData.push(recordNumber);
                                    recordNumber++;
                                }
                                for (var key in allDataRow) {
                                    if (allDataRow.hasOwnProperty(key) && key !== 'id') {
                                        rowData.push(allDataRow[key]);
                                    }
                                }
                                table.row.add(rowData);

                            }
                            table.draw();
                        }
                    });
                }
            }
        });
    });

  $('#shift_report_listing').on('click', '.delete-record', function (event) {
    event.preventDefault();
    var deleterecordId = $(this).data('id');
    swal.fire({
      title: `Are you sure you want to delete this record?`,
      text: "If you delete this, it will be gone forever.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        var token = $("meta[name='csrf-token']").attr("content");
        if (deleterecordId) {
          deleteroute = '../shift-report/delete/' + deleterecordId;
          $.ajax({
            url: deleteroute,
            type: 'DELETE',
            dataType: 'JSON',
            data: {
              status: deleterecordId, _token: token
            },
            success: function (data) {
              toastr.success(data.message);
              $('#shift_report_listing').DataTable().ajax.reload();

            }
          });
        }
      }
    });
  });

  $('#shift_filling_readings').on('click', '.del-shift-filling-read', function (event) {
    event.preventDefault();
    var deleterecordId = $(this).data('id');

    var row = $(this).closest('tr');
    swal.fire({
      title: `Are you sure you want to delete this record?`,
      text: "If you delete this, it will be gone forever.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        var token = $("meta[name='csrf-token']").attr("content");
        if (deleterecordId) {
          deleteroute = '../shift-filling-reading-delete/' + deleterecordId;
          $.ajax({
            url: deleteroute,
            type: 'DELETE',
            dataType: 'JSON',
            data: {
              status: deleterecordId, _token: token
            },
            success: function (data) {
              toastr.success(data.message);
              row.remove();
            }
          });
        }
      }
    });
  });

  $('#filling_bottled_oil_record').on('click', '.del-filling-bottled-oil-record', function (event) {
    event.preventDefault();

    var deleterecordId = $(this).data('id');
    var row = $(this).closest('tr');
    swal.fire({
      title: `Are you sure you want to delete this record?`,
      text: "If you delete this, it will be gone forever.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        var token = $("meta[name='csrf-token']").attr("content");
        if (deleterecordId) {
          deleteroute = '../shift-bottled-oil-filling-reading-delete/' + deleterecordId;
          $.ajax({
            url: deleteroute,
            type: 'DELETE',
            dataType: 'JSON',
            data: {
              status: deleterecordId, _token: token
            },
            success: function (data) {
              toastr.success(data.message);
              row.remove();
            }
          });
        }
      }
    });
  });

  $('#bottled_oil_sales').on('click', '.del-bottled-oil-sales', function (event) {
    event.preventDefault();

    var deleterecordId = $(this).data('id');
    var row = $(this).closest('tr');
    swal.fire({
      title: `Are you sure you want to delete this record?`,
      text: "If you delete this, it will be gone forever.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.isConfirmed) {
        var token = $("meta[name='csrf-token']").attr("content");
        if (deleterecordId) {
          deleteroute = '../bottled-oil-sales-delete/' + deleterecordId;
          $.ajax({
            url: deleteroute,
            type: 'DELETE',
            dataType: 'JSON',
            data: {
              status: deleterecordId, _token: token
            },
            success: function (data) {
              toastr.success(data.message);
              row.remove();
            }
          });
        }
      }
    });
  });


    $('.all-checkbox').click(function (e) {
        var datarow = $(this).data('row');
        var table = $(e.target).closest('table');
        $('.forcheck-' + datarow, table).prop('checked', this.checked);

    });
    const trElements = $('table tr');

    // Loop through each <tr>
    trElements.each(function () {
        const tdElements = $(this).find('td'); // Get all <td> elements inside the current <tr>
        let totalCheckboxes = 0;
        let checkedCheckboxes = 0;

        // Loop through each <td> in the current <tr>
        tdElements.each(function () {
            const checkboxesInTd = $(this).find('input[type="checkbox"]');
            totalCheckboxes += checkboxesInTd.length; // Count all checkboxes in the <td>
            checkedCheckboxes += checkboxesInTd.filter(':checked').length; // Count checked checkboxes in the <td>
        });
        console.log(totalCheckboxes, "hiii");
        if ((checkedCheckboxes === 5 && totalCheckboxes === 6) || (checkedCheckboxes === 2 && totalCheckboxes === 3) || (checkedCheckboxes === 4 &&
            totalCheckboxes === 5)) {
            tdElements.find('input[type="checkbox"]').prop('checked', true);
        }
    });


let idleTimeout;
const idleDuration = 3600000;
let redirectToConfirm = true;

const pathName = window.location.pathname;
const dynamicPart = pathName.split('/')[1];
const confirmPasswordUrl = `${window.location.origin}`+'/'+`${dynamicPart}`+'/password/confirm';

function redirectToConfirmView() {
    if (redirectToConfirm) {
        window.location.href = confirmPasswordUrl;
        createCookie('confirmpassword', 'true', 1);
        redirectToConfirm = false;
    }
}

function resetTimer() {
    clearTimeout(idleTimeout);
    idleTimeout = setTimeout(redirectToConfirmView, idleDuration);
}

document.addEventListener('mousemove', resetTimer);
document.addEventListener('keydown', resetTimer);

resetTimer();

function createCookie(name, value, days) {
    let expires = '';
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = '; expires=' + date.toGMTString();
    }
    document.cookie = name + '=' + value + expires + '; path=/';
}

function destroyCookie(name) {
    document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
}
function checkConfirmPasswordCookie() {
    const name = 'confirmpassword' + '=';
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        const c = ca[i].trim();
        if (c.indexOf(name) === 0) {
            // The 'confirmpassword' cookie is set
            if (c.substring(name.length) === 'true') {

                const current_path = window.location.pathname;
                const check_path = "/password/confirm";

                if (!current_path.includes(check_path)) {
                    destroyCookie('confirmpassword');
                    document.getElementById('logout-form').submit();
                }
            }
        }
    }
}

checkConfirmPasswordCookie();

});

/*function UpdateStatus(Id, foldername) {
    console.log(foldername);
    setStatus = Id;
    setFoldername = foldername;
    $("#confirmagentPromp").modal("show");
}

function UpdateStatusConfirm() {
    $("#confirmagentPromp").modal("hide");
    var token = $("meta[name='csrf-token']").attr("content");
    if (setStatus, setFoldername) {
        $.ajax({
            url: setFoldername + '/destroy',
            type: 'DELETE',
            dataType: 'JSON',
            data: {
                status: setStatus, _token: token
            },
            success: function (data) {
                toastr.success(data.message);
                //$("#example1").ajax.reload();
                $('#setStatus-' + setStatus).remove();
            }
        });
    }
}

function cancelStatusConfirm() {
    $('#confirmagentPromp').modal('hide');
}*/



 $('.update-status').click(function() {
            var recordId = $(this).data('id');
            var clickedButton = $(this)

            if(recordId > 0){
                $.ajax({
                    type: 'POST',
                    url: "{{ route('employee-groups.changeEmployeeGroupStatus') }}",
                    data: {
                        _token: "{{ csrf_token() }}",
                        id: recordId
                    },
                    success: function(response) {
                        console.log('Response:', response); // Check the response in the browser console

                    // Check if the response has a 'success' property
                    if (response.success) {
                    console.log('New Status:', response.newStatus); // Check the newStatus value

                    // Toggle the button text based on the response
                    if (response.newStatus === 'Active') {

                        clickedButton.text('Active');
                        clickedButton.removeClass('btn-danger').addClass('btn-success');
                    } else {
                        clickedButton.text('Inactive');
                        clickedButton.removeClass('btn-success').addClass('btn-danger');
                    }
                }
            },
            error: function (response) {
                // Handle errors if needed
                console.error('Error:', response);
            }
        });
    } else {
        // alert("data not found");
    }
});
    function UpdateStatus(Id,foldername){
        setStatus=Id;
        setFoldername=foldername;
        $("#confirmagentPromp").modal("show");
    }

    function UpdateStatusConfirm(){
        $("#confirmagentPromp").modal("hide");
        var token = $("meta[name='csrf-token']").attr("content");
        if(setStatus,setFoldername){
            $.ajax({
                url: setFoldername+'/destroy',
                type: 'DELETE',
                dataType: 'JSON',
                data:{
                   status:setStatus,_token: token
                },
                success: function (data)
                {
                    toastr.success(data.message);
                    $('#setStatus-' +setStatus).remove();
                }
            });
        }
    }

    function cancelStatusConfirm(){
        $('#confirmagentPromp').modal('hide');
   }

   function printWindowBottleOilSales(id) {
    console.log('id::--',id);
	};

$('.value-check').blur(function () {

        var inputValue = $(this).val();
        console.log(inputValue);
        var errorSpan = $('.v-error');

        if (/^[0-9]+$/.test(inputValue)) {
            errorSpan.hide();
        } else {
            errorSpan.show();
        }
});



