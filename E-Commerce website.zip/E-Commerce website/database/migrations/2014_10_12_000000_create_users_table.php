<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->integer('type')->default(0)->comment('0-Regional Head Quarter - RHQ - Super Admin Role an do anything, 1-Regional Distribution Center, 2-Regional Audit Center, 3-Petrol Station');
            $table->integer('sub_emp_id')->default(0)->comment('0=Regional Distribution Center, Regional Audit Center, Petrol Station >0=Employees');
            $table->integer('id_parent_organisation')->default(0)->comment('id from admins table. id of the upper level admin');
            $table->string('username')->nullable();
            $table->string('email');
            $table->string('password');
            $table->string('default_language')->nullable();
            $table->enum('status', ['Y','N'])->default('Y');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
};
